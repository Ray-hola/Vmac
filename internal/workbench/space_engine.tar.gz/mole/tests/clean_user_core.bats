#!/usr/bin/env bats

load helpers/common

setup_file() {
    mole_test_setup_home user-core

    # Prevent AppleScript permission dialogs during tests
    MOLE_TEST_MODE=1
    export MOLE_TEST_MODE

    # clean_browsers reaches the Chrome, Edge, and Brave old-version cleaners,
    # which default to the real /Applications bundles. Cases that stub pgrep as
    # "not running" would otherwise delete a staged browser version on the Mac
    # running the suite, including the one a live browser is still using.
    MOLE_CHROME_APP_PATHS="$HOME/Applications/Google Chrome.app"
    MOLE_EDGE_APP_PATHS="$HOME/Applications/Microsoft Edge.app"
    MOLE_BRAVE_APP_PATHS="$HOME/Applications/Brave Browser.app"
    export MOLE_CHROME_APP_PATHS MOLE_EDGE_APP_PATHS MOLE_BRAVE_APP_PATHS

    mkdir -p "$HOME"
}

teardown_file() {
    mole_test_teardown_home
}

@test "browser old-version cleaners stay inside the fixture HOME" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
_clean_chromium_old_versions() {
    shift 3
    printf 'APP:%s\n' "$@"
}
clean_chrome_old_versions
clean_edge_old_versions
clean_brave_old_versions
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"APP:$HOME/Applications/Google Chrome.app"* ]] || return 1
    [[ "$output" == *"APP:$HOME/Applications/Microsoft Edge.app"* ]] || return 1
    [[ "$output" == *"APP:$HOME/Applications/Brave Browser.app"* ]] || return 1
    [[ "$output" != *"APP:/Applications/"* ]]
}

@test "clean_user_essentials respects Trash whitelist" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
safe_clean() { echo "$2"; }
note_activity() { :; }
is_path_whitelisted() { [[ "$1" == "$HOME/.Trash" ]]; }
safe_clean_guarded() {
    local guard="$1"
    shift
    local label="${!#}"
    local -a targets=("${@:1:$#-1}")
    local -a kept=()
    local target
    for target in "${targets[@]}"; do
        if "$guard" "$target"; then
            kept+=("$target")
        fi
    done
    if [[ ${#kept[@]} -eq 0 ]]; then
        return 75
    fi
    safe_clean "${kept[@]}" "$label"
}
clean_user_essentials
EOF

    [ "$status" -eq 0 ]
    # Whitelist-protected items no longer show output (UX improvement in V1.22.0)
    [[ "$output" != *"Trash"* ]]
}

@test "incomplete downloads are kept when the open-file view is incomplete (#1471)" {
    local partial="$HOME/Downloads/pending.crdownload"
    mkdir -p "$(dirname "$partial")"
    printf 'partial\n' > "$partial"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
trace_file=$(mktemp)
lsof() {
    case " $* " in
        *" -p 1 "*) printf 'visibility\n' >> "$trace_file"; return 1 ;;
        *) printf 'target\n' >> "$trace_file"; return 1 ;;
    esac
}
run_with_timeout() { shift; "$@"; }
safe_clean() { echo "UNEXPECTED_SAFE_CLEAN:$1"; }
note_activity() { :; }
_clean_incomplete_downloads
printf 'TRACE=%s\n' "$(tr '\n' ',' < "$trace_file")"
command rm -f "$trace_file"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"open-file check unavailable"* ]] || return 1
    [[ "$output" == *"TRACE=visibility,"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_SAFE_CLEAN"* ]]
}

@test "incomplete download dry-run rechecks open handles after sizing (#1471)" {
    local partial="$HOME/Downloads/pending.part"
    mkdir -p "$(dirname "$partial")"
    printf 'partial\n' > "$partial"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" partial="$partial" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/bin/clean.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
trace_file=$(mktemp)
size_marker=$(mktemp)
command rm -f "$size_marker"
lsof() {
    printf 'LSOF:%s\n' "$(test -f "$size_marker" && echo live || echo idle)" >> "$trace_file"
    if [[ -f "$size_marker" ]]; then
        printf 'n%s\n' "$partial"
        return 0
    fi
    return 1
}
run_with_timeout() { shift; "$@"; }
get_cleanup_path_size_kb() {
    printf 'SIZE\n' >> "$trace_file"
    printf 'sized\n' > "$size_marker"
    printf '1\n'
}
record_dry_run_cleanup_target() { printf 'UNEXPECTED_REGISTER:%s\n' "$1"; }
note_activity() { :; }
DRY_RUN=true
MOLE_CURRENT_COMMAND=clean
MOLE_CLEAN_CANCEL_STATUS=0
_clean_incomplete_downloads
printf 'EXISTS=%s ORDER=%s\n' "$(test -f "$partial" && echo yes || echo no)" \
    "$(tr '\n' ',' < "$trace_file")"
command rm -f "$trace_file" "$size_marker"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"EXISTS=yes ORDER=LSOF:idle,SIZE,LSOF:live,"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_REGISTER"* ]] || return 1
}

@test "clean_user_essentials avoids Darwin runtime probes and live-log truncation" {
    mkdir -p "$HOME/Library/Caches/ordinary-app"
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
safe_clean() { echo "SAFE:${!#}"; }
clean_trash() { echo "TRASH"; }
_clean_recent_items() { :; }
_clean_mail_downloads() { :; }
getconf() { echo "WRONG:getconf"; return 99; }
lsof() { echo "WRONG:lsof"; return 99; }
mole_truncate_log_file() { echo "WRONG:truncate"; return 99; }
safe_clean_guarded() {
    local guard="$1"
    shift
    local label="${!#}"
    local -a targets=("${@:1:$#-1}")
    local -a kept=()
    local target
    for target in "${targets[@]}"; do
        if "$guard" "$target"; then
            kept+=("$target")
        fi
    done
    if [[ ${#kept[@]} -eq 0 ]]; then
        return 75
    fi
    safe_clean "${kept[@]}" "$label"
}
clean_user_essentials
EOF

    [ "$status" -eq 0 ] || return 1
    [ "$output" = $'SAFE:User app cache\nSAFE:User app logs\nTRASH' ]
    rm -rf "$HOME/Library/Caches/ordinary-app"
}

@test "clean_user_essentials preserves default Deno state from the generic cache sweep" {
    local test_home="$HOME/deno-default-home"
    mkdir -p \
        "$test_home/Library/Caches/deno/origin-data" \
        "$test_home/Library/Caches/ordinary-app/junk"

    run env -u DENO_DIR HOME="$test_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
clean_trash() { :; }
_clean_recent_items() { :; }
_clean_mail_downloads() { :; }
safe_clean() {
    local description="${!#}"
    local path
    while [[ $# -gt 1 ]]; do
        path="$1"
        shift
        printf 'CLEAN=%s|%s\n' "$description" "$path"
        rm -rf "$path"
    done
}
safe_clean_guarded() {
    local guard="$1"
    shift
    local label="${!#}"
    local -a targets=("${@:1:$#-1}")
    local -a kept=()
    local target
    for target in "${targets[@]}"; do
        if "$guard" "$target"; then
            kept+=("$target")
        fi
    done
    if [[ ${#kept[@]} -eq 0 ]]; then
        return 75
    fi
    safe_clean "${kept[@]}" "$label"
}
clean_user_essentials
[[ -d "$HOME/Library/Caches/deno/origin-data" ]] || exit 1
[[ ! -e "$HOME/Library/Caches/ordinary-app" ]]
EOF

    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" != *"User app cache|$test_home/Library/Caches/deno"* ]] || return 1
    [[ "$output" == *"User app cache|$test_home/Library/Caches/ordinary-app"* ]] || return 1
    rm -rf "$test_home"
}

@test "clean_user_essentials keeps Google identity and Clearcut state (#1607)" {
    # The generic cache sweep reaches these dotless names. Drive the real
    # safe_clean_guarded path so should_protect_path at bin/clean.sh:1002
    # decides the batch.
    local test_home="$HOME/google-identity-home"
    mkdir -p \
        "$test_home/Library/Caches/GIPPseudonymousID" \
        "$test_home/Library/Caches/CCTClearcutLogger" \
        "$test_home/Library/Caches/ordinary-app"
    printf 'id\n' > "$test_home/Library/Caches/GIPPseudonymousID/device-id"
    printf 'log\n' > "$test_home/Library/Caches/CCTClearcutLogger/queue.dat"
    printf 'junk\n' > "$test_home/Library/Caches/ordinary-app/junk"

    run env HOME="$test_home" PROJECT_ROOT="$PROJECT_ROOT" \
        MOLE_TEST_MODE=1 MOLE_TEST_NO_AUTH=1 \
        /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/bin/clean.sh"
DRY_RUN=false
start_section_spinner() { :; }
stop_section_spinner() { :; }
clean_trash() { :; }
_clean_recent_items() { :; }
_clean_mail_downloads() { :; }
clean_rc=0
clean_user_essentials || clean_rc=$?
gip="$HOME/Library/Caches/GIPPseudonymousID"
clearcut="$HOME/Library/Caches/CCTClearcutLogger"
ordinary="$HOME/Library/Caches/ordinary-app"
printf 'CLEAN_RC=%s GIP=%s CCT=%s ORD=%s\n' \
    "$clean_rc" \
    "$(test -d "$gip" && echo kept || echo gone)" \
    "$(test -d "$clearcut" && echo kept || echo gone)" \
    "$(test -e "$ordinary" && echo kept || echo gone)"
[[ -d "$gip" ]] || exit 1
[[ -d "$clearcut" ]] || exit 1
[[ ! -e "$ordinary" ]] || exit 1
EOF

    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    rm -rf "$test_home"
}

@test "clean_user_essentials preserves nested and physical Deno roots" {
    local nested_home="$HOME/deno-nested-home"
    local linked_home="$HOME/deno-linked-home"
    mkdir -p \
        "$nested_home/Library/Caches/tool-root/deno/origin-data" \
        "$nested_home/Library/Caches/ordinary-app/junk" \
        "$linked_home/Library/Caches/physical-deno/origin-data" \
        "$linked_home/Library/Caches/ordinary-app/junk"
    ln -s "$linked_home/Library/Caches/physical-deno" \
        "$linked_home/Library/Caches/deno"

    run env HOME="$nested_home" PROJECT_ROOT="$PROJECT_ROOT" \
        DENO_DIR="$nested_home/Library/Caches/tool-root/deno" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
clean_trash() { :; }
_clean_recent_items() { :; }
_clean_mail_downloads() { :; }
safe_clean() {
    while [[ $# -gt 1 ]]; do
        rm -rf "$1"
        shift
    done
}
safe_clean_guarded() {
    local guard="$1"
    shift
    local label="${!#}"
    local -a targets=("${@:1:$#-1}")
    local -a kept=()
    local target
    for target in "${targets[@]}"; do
        if "$guard" "$target"; then
            kept+=("$target")
        fi
    done
    if [[ ${#kept[@]} -eq 0 ]]; then
        return 75
    fi
    safe_clean "${kept[@]}" "$label"
}
clean_user_essentials
[[ -d "$HOME/Library/Caches/tool-root/deno/origin-data" ]] || exit 1
[[ ! -e "$HOME/Library/Caches/ordinary-app" ]]
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }

    run env -u DENO_DIR HOME="$linked_home" PROJECT_ROOT="$PROJECT_ROOT" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
clean_trash() { :; }
_clean_recent_items() { :; }
_clean_mail_downloads() { :; }
safe_clean() {
    while [[ $# -gt 1 ]]; do
        rm -rf "$1"
        shift
    done
}
safe_clean_guarded() {
    local guard="$1"
    shift
    local label="${!#}"
    local -a targets=("${@:1:$#-1}")
    local -a kept=()
    local target
    for target in "${targets[@]}"; do
        if "$guard" "$target"; then
            kept+=("$target")
        fi
    done
    if [[ ${#kept[@]} -eq 0 ]]; then
        return 75
    fi
    safe_clean "${kept[@]}" "$label"
}
clean_user_essentials
[[ -L "$HOME/Library/Caches/deno" ]] || exit 1
[[ -d "$HOME/Library/Caches/physical-deno/origin-data" ]] || exit 1
[[ ! -e "$HOME/Library/Caches/ordinary-app" ]]
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    rm -rf "$nested_home" "$linked_home"
}

@test "clean_user_essentials fails closed on a broad DENO_DIR" {
    local test_home="$HOME/deno-broad-home"
    mkdir -p "$test_home/Library/Caches/ordinary-app/junk"

    run env HOME="$test_home" PROJECT_ROOT="$PROJECT_ROOT" \
        DENO_DIR="$test_home/Library/Caches" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
clean_trash() { :; }
_clean_recent_items() { :; }
_clean_mail_downloads() { :; }
safe_clean() { printf 'CLEAN=%s\n' "${!#}"; }
safe_clean_guarded() {
    local guard="$1"
    shift
    local label="${!#}"
    local -a targets=("${@:1:$#-1}")
    local -a kept=()
    local target
    for target in "${targets[@]}"; do
        if "$guard" "$target"; then
            kept+=("$target")
        fi
    done
    if [[ ${#kept[@]} -eq 0 ]]; then
        return 75
    fi
    safe_clean "${kept[@]}" "$label"
}
clean_user_essentials
EOF

    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" != *"CLEAN=User app cache"* ]] || return 1
    [[ "$output" == *"CLEAN=User app logs"* ]] || return 1
    # Refusing silently would drop the whole category from the section with no
    # way for the user to tell cleanup from a stopped gate.
    [[ "$output" == *"User app cache · stopped (DENO_DIR unresolved)"* ]] || {
        echo "$output"
        return 1
    }
    rm -rf "$test_home"
}

@test "a Deno root retargeted inside safe_remove is refused before rm" {
    # Excluding the root while the candidate list is built only proves where
    # it pointed then, and the batch guard fires before safe_remove does its
    # own validation, sizing and identity work. The root is re-asked at the
    # last hop before rm so a swap anywhere in that span is refused.
    local test_home="$HOME/deno-race-home"
    mkdir -p "$test_home/Library/Caches/deno-old" \
        "$test_home/Library/Caches/aaa-first" \
        "$test_home/Library/Caches/ordinary-app"
    printf 'deno\n' > "$test_home/Library/Caches/deno-old/d.txt"
    printf 'first\n' > "$test_home/Library/Caches/aaa-first/f.txt"
    printf 'app\n' > "$test_home/Library/Caches/ordinary-app/a.txt"
    ln -s "$test_home/Library/Caches/deno-old" "$test_home/Library/Caches/deno"

    run env -u DENO_DIR HOME="$test_home" PROJECT_ROOT="$PROJECT_ROOT" MOLE_TEST_NO_AUTH=1 \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/bin/clean.sh"
DRY_RUN=false
start_section_spinner() { :; }
stop_section_spinner() { :; }
clean_trash() { :; }
_clean_recent_items() { :; }
_clean_mail_downloads() { :; }

# Retarget the root for the candidate that is being removed right now,
# after the batch guard already cleared it. safe_remove still runs path
# validation, process and identity checks before rm, so the only honest
# test is one that moves the root inside that span.
eval "$(declare -f safe_remove | sed '1s/safe_remove/_real_safe_remove/')"
safe_remove() {
    if [[ "$1" == *"/ordinary-app" ]]; then
        rm -f "$HOME/Library/Caches/deno"
        ln -s "$HOME/Library/Caches/ordinary-app" "$HOME/Library/Caches/deno"
    fi
    _real_safe_remove "$@"
}
clean_user_essentials
EOF

    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ -d "$test_home/Library/Caches/ordinary-app" ]] || {
        echo "sink deleted the retargeted Deno root"
        return 1
    }
    [[ -e "$test_home/Library/Caches/deno" ]] || {
        echo "Deno root left dangling"
        return 1
    }
    [[ ! -d "$test_home/Library/Caches/aaa-first" ]] || {
        echo "the ordinary candidate before the retarget was not cleaned"
        return 1
    }
    rm -rf "$test_home"
}

@test "clean_user_essentials keeps the DiagnosticReports directory (#1689)" {
    local test_home="$HOME/diag-home"
    mkdir -p "$test_home/Library/Logs/DiagnosticReports"
    touch "$test_home/Library/Logs/DiagnosticReports/App.ips"

    run env HOME="$test_home" PROJECT_ROOT="$PROJECT_ROOT" MOLE_TEST_NO_AUTH=1 \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/bin/clean.sh"
DRY_RUN=false
start_section_spinner() { :; }
stop_section_spinner() { :; }
clean_trash() { :; }
_clean_recent_items() { :; }
_clean_mail_downloads() { :; }
clean_user_essentials
EOF

    [ "$status" -eq 0 ] || return 1
    [[ -d "$test_home/Library/Logs/DiagnosticReports" ]] || return 1
    [[ ! -e "$test_home/Library/Logs/DiagnosticReports/App.ips" ]] || return 1
    rm -rf "$test_home"
}

@test "user logs retain authored files behind symlinked log roots" {
    local variant
    for variant in reports logs library; do
        local test_home="$BATS_TEST_TMPDIR/log-links-$variant"
        mkdir -p "$test_home/Library/Logs/DiagnosticReports" "$test_home/authored/Logs/DiagnosticReports"
        printf 'keep' > "$test_home/authored/report.txt"
        printf 'keep' > "$test_home/authored/Logs/report.txt"
        case "$variant" in
            reports) rmdir "$test_home/Library/Logs/DiagnosticReports"; ln -s "$test_home/authored" "$test_home/Library/Logs/DiagnosticReports" ;;
            logs) mv "$test_home/Library/Logs" "$test_home/original"; ln -s "$test_home/authored" "$test_home/Library/Logs" ;;
            library) mv "$test_home/Library" "$test_home/original"; ln -s "$test_home/authored" "$test_home/Library" ;;
        esac
        run env HOME="$test_home" PROJECT_ROOT="$PROJECT_ROOT" MOLE_TEST_NO_AUTH=1 /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/bin/clean.sh"
DRY_RUN=false
start_section_spinner() { :; }
stop_section_spinner() { :; }
clean_trash() { :; }
_clean_recent_items() { :; }
_clean_mail_downloads() { :; }
clean_user_essentials
[[ -f "$HOME/authored/report.txt" && -f "$HOME/authored/Logs/report.txt" ]] || exit 1
EOF
        [ "$status" -eq 0 ] || { echo "$variant: $output"; return 1; }
    done
}

@test "user logs recheck the DiagnosticReports root after sizing and at the final sink" {
    local phase
    for phase in sizing sink preview replacement; do
        local test_home="$BATS_TEST_TMPDIR/log-race-$phase"
        mkdir -p "$test_home/Library/Logs/DiagnosticReports" "$test_home/authored"
        printf 'old' > "$test_home/Library/Logs/DiagnosticReports/report.txt"
        printf 'keep' > "$test_home/authored/report.txt"
        run env HOME="$test_home" PHASE="$phase" PROJECT_ROOT="$PROJECT_ROOT" MOLE_TEST_NO_AUTH=1 /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/bin/clean.sh"
DRY_RUN=false
[[ "$PHASE" != preview ]] || DRY_RUN=true
record_dry_run_cleanup_target() { touch "$HOME/unsafe-preview"; }
start_section_spinner() { :; }
stop_section_spinner() { :; }
clean_trash() { :; }
_clean_recent_items() { :; }
_clean_mail_downloads() { :; }
retarget_logs() {
    if [[ ! -L "$HOME/Library/Logs/DiagnosticReports" ]]; then
        mv "$HOME/Library/Logs/DiagnosticReports" "$HOME/original-reports"
        if [[ "$PHASE" == replacement ]]; then
            mv "$HOME/authored" "$HOME/Library/Logs/DiagnosticReports"
        else
            ln -s "$HOME/authored" "$HOME/Library/Logs/DiagnosticReports"
        fi
    fi
}
if [[ "$PHASE" != sink ]]; then
    get_cleanup_path_size_kb() { retarget_logs; printf '1\n'; }
else
    eval "$(declare -f safe_remove | sed '1s/safe_remove/_original_safe_remove/')"
    safe_remove() { retarget_logs; _original_safe_remove "$@"; }
fi
clean_user_essentials
if [[ "$PHASE" == replacement ]]; then
    [[ -f "$HOME/Library/Logs/DiagnosticReports/report.txt" ]] || exit 1
else
    [[ -L "$HOME/Library/Logs/DiagnosticReports" && -f "$HOME/authored/report.txt" ]] || exit 1
fi
[[ ! -e "$HOME/unsafe-preview" ]] || exit 1
EOF
        [ "$status" -eq 0 ] || { echo "$phase: $output"; return 1; }
    done
}

@test "standalone diagnostic logs preserve redirected roots" {
    local relative=Library/DiagnosticReports mode
        for mode in link replacement ordinary; do
            local test_home="$BATS_TEST_TMPDIR/${relative//\//_}-$mode"
            mkdir -p "$test_home/$relative" "$test_home/authored"
            printf 'old' > "$test_home/$relative/report.txt"
            printf 'keep' > "$test_home/authored/report.txt"
            run env HOME="$test_home" RELATIVE="$relative" MODE="$mode" PROJECT_ROOT="$PROJECT_ROOT" MOLE_TEST_NO_AUTH=1 /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/bin/clean.sh"
DRY_RUN=false
start_section_spinner() { :; }
stop_section_spinner() { :; }
safe_clean() { :; }
_clean_incomplete_downloads() { :; }
clean_support_app_data() { :; }
clean_group_container_caches() { :; }
clean_handoff_pasteboard_cache() { :; }
if [[ "$MODE" == link ]]; then
    mv "$HOME/$RELATIVE" "$HOME/original"
    ln -s "$HOME/authored" "$HOME/$RELATIVE"
elif [[ "$MODE" == replacement ]]; then
    get_cleanup_path_size_kb() {
        mv "$HOME/$RELATIVE" "$HOME/original"
        mv "$HOME/authored" "$HOME/$RELATIVE"
        printf '1\n'
    }
fi
clean_app_caches
case "$MODE" in
    link) [[ -f "$HOME/authored/report.txt" ]] || exit 1 ;;
    replacement) [[ -f "$HOME/$RELATIVE/report.txt" ]] || exit 1 ;;
    ordinary) [[ ! -e "$HOME/$RELATIVE/report.txt" ]] || exit 1 ;;
esac
EOF
            [ "$status" -eq 0 ] || { echo "$relative $mode: $output"; return 1; }
        done
}

@test "log cleanup entrypoints preserve cancellation statuses" {
    local relative cancel_rc
    for relative in Library/Logs Library/DiagnosticReports; do
        for cancel_rc in 124 130 143; do
            local test_home="$BATS_TEST_TMPDIR/${relative//\//_}-$cancel_rc"
            mkdir -p "$test_home/$relative"
            touch "$test_home/$relative/report.txt"
            run env HOME="$test_home" RELATIVE="$relative" CANCEL_RC="$cancel_rc" PROJECT_ROOT="$PROJECT_ROOT" MOLE_TEST_NO_AUTH=1 /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/bin/clean.sh"
DRY_RUN=false
start_section_spinner() { :; }
stop_section_spinner() { :; }
safe_clean() { :; }
safe_clean_guarded() { return "$CANCEL_RC"; }
clean_trash() { touch "$HOME/continued"; }
_clean_incomplete_downloads() { touch "$HOME/continued"; }
case "$RELATIVE" in
    Library/Logs) clean_user_essentials ;;
    Library/DiagnosticReports) clean_app_caches ;;
esac
EOF
            [ "$status" -eq "$cancel_rc" ] || { echo "$relative: $output"; return 1; }
            [[ ! -e "$test_home/continued" ]] || return 1
        done
    done
}

@test "a custom whitelist still protects system caches, Poetry virtualenvs and the renv cache" {
    # clean_user_essentials sweeps every child of ~/Library/Caches, and
    # load_mole_whitelist replaces DEFAULT_WHITELIST_PATTERNS wholesale once a
    # user saves one entry of their own. Anything that breaks macOS search,
    # fonts or iCloud, or that holds live interpreters rather than downloads,
    # has to survive that replacement.
    local test_home="$HOME/custom-whitelist-home"
    mkdir -p "$test_home/.config/mole" \
        "$test_home/Library/Caches/com.apple.spotlight" \
        "$test_home/Library/Caches/com.apple.FontRegistry" \
        "$test_home/Library/Caches/CloudKit" \
        "$test_home/Library/Caches/pypoetry/virtualenvs/proj-abc123" \
        "$test_home/Library/Caches/org.R-project.R/R/renv/cache/v5/pkg" \
        "$test_home/Library/Caches/com.example.unprotected"
    printf '%s\n' "$test_home/.cache/keep-my-own-thing/*" > "$test_home/.config/mole/whitelist"

    run env HOME="$test_home" PROJECT_ROOT="$PROJECT_ROOT" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
load_mole_whitelist "$HOME"
for probe in \
    "$HOME/Library/Caches/com.apple.spotlight" \
    "$HOME/Library/Caches/com.apple.FontRegistry" \
    "$HOME/Library/Caches/CloudKit" \
    "$HOME/Library/Caches/pypoetry/virtualenvs/proj-abc123" \
    "$HOME/Library/Caches/org.R-project.R/R/renv/cache/v5/pkg" \
    "$HOME/Library/Caches/org.R-project.R" \
    "$HOME/Library/Caches/com.example.unprotected"; do
    if is_path_whitelisted "$probe"; then
        printf 'PROTECTED=%s\n' "${probe#"$HOME"/}"
    else
        printf 'EXPOSED=%s\n' "${probe#"$HOME"/}"
    fi
done
# The user's own entry must survive too.
is_path_whitelisted "$HOME/.cache/keep-my-own-thing/x" && printf 'CUSTOM_KEPT\n'
EOF

    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    # The one ordinary cache is the positive control: the sweep must still
    # reach it, or the probes above prove nothing.
    [[ "$output" == *"EXPOSED=Library/Caches/com.example.unprotected"* ]] || {
        echo "$output"
        return 1
    }
    [[ "$(grep -c "EXPOSED=" <<< "$output")" -eq 1 ]] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"PROTECTED=Library/Caches/com.apple.spotlight"* ]] || return 1
    [[ "$output" == *"PROTECTED=Library/Caches/pypoetry/virtualenvs/proj-abc123"* ]] || return 1
    [[ "$output" == *"PROTECTED=Library/Caches/org.R-project.R/R/renv/cache/v5/pkg"* ]] || return 1
    # The sweep removes top-level children of ~/Library/Caches, so the parent
    # is the path that actually has to hold.
    [[ "$output" == *"PROTECTED=Library/Caches/org.R-project.R"$'\n'* ]] || return 1
    [[ "$output" == *"CUSTOM_KEPT"* ]] || return 1
    rm -rf "$test_home"
}

@test "clean_trash dry run stays silent for compiled-model-only items" {
    mkdir -p "$HOME/.Trash/model/com.apple.e5rt.e5bundlecache"
    touch "$HOME/.Trash/model/com.apple.e5rt.e5bundlecache/weights.bin"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
note_activity() { :; }
record_dry_run_cleanup_target() { echo "UNEXPECTED_RECORD:$1"; }
get_path_size_kb() { echo "UNEXPECTED_SIZE"; return 1; }
clean_trash
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == "" ]] || return 1
    rm -rf "$HOME/.Trash/model"
}

@test "clean_user_essentials empties trash directly without Finder prompt" {
    mkdir -p "$HOME/.Trash"
    touch "$HOME/.Trash/one.tmp" "$HOME/.Trash/two.tmp"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
DRY_RUN=false
start_section_spinner() { :; }
stop_section_spinner() { :; }
start_inline_spinner() { :; }
stop_inline_spinner() { :; }
safe_clean() { :; }
note_activity() { :; }
is_path_whitelisted() { return 1; }
debug_log() { :; }
osascript() {
    echo "FAIL: osascript called, should be direct delete" >&2
    return 1
}
export -f osascript
safe_remove() {
    local target="$1"
    /bin/rm -rf "$target"
    return 0
}

safe_clean_guarded() {
    local guard="$1"
    shift
    local label="${!#}"
    local -a targets=("${@:1:$#-1}")
    local -a kept=()
    local target
    for target in "${targets[@]}"; do
        if "$guard" "$target"; then
            kept+=("$target")
        fi
    done
    if [[ ${#kept[@]} -eq 0 ]]; then
        return 75
    fi
    safe_clean "${kept[@]}" "$label"
}
clean_user_essentials
[[ ! -e "$HOME/.Trash/one.tmp" ]] || exit 1
[[ ! -e "$HOME/.Trash/two.tmp" ]] || exit 1
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Trash · emptied, 2 items"* ]] || return 1
    [[ "$output" != *"osascript called"* ]]
}

@test "clean_trash reports skipped items instead of silent partial empty (#1517)" {
    mkdir -p "$HOME/.Trash"
    touch "$HOME/.Trash/one.tmp" "$HOME/.Trash/two.tmp"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
DRY_RUN=false
start_section_spinner() { :; }
stop_section_spinner() { :; }
start_inline_spinner() { :; }
stop_inline_spinner() { :; }
note_activity() { :; }
is_path_whitelisted() { return 1; }
debug_log() { :; }
safe_remove() {
    local target="$1"
    [[ "$target" == *"/two.tmp" ]] && return 1
    rm -f "$target"
    return 0
}

clean_trash
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Trash · removed 1 items, 1 could not be removed"* ]] || return 1
    [[ -e "$HOME/.Trash/two.tmp" ]] || return 1
    [[ ! -e "$HOME/.Trash/one.tmp" ]]
}

@test "clean_trash removes input-method leftovers already in Trash (#1517)" {
    rm -rf "$HOME/.Trash" # SAFE: reset this test's temporary HOME fixture before populating it
    mkdir -p "$HOME/.Trash/Input Methods"
    touch "$HOME/.Trash/com.sogou.inputmethod.sogou.plist"
    touch "$HOME/.Trash/com.tencent.inputmethod.QQInput.plist"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
DRY_RUN=false
start_section_spinner() { :; }
stop_section_spinner() { :; }
start_inline_spinner() { :; }
stop_inline_spinner() { :; }
note_activity() { :; }
is_path_whitelisted() { return 1; }
debug_log() { :; }

clean_trash
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Trash · emptied, 3 items"* ]] || return 1
    [[ ! -e "$HOME/.Trash/com.sogou.inputmethod.sogou.plist" ]] || return 1
    [[ ! -e "$HOME/.Trash/com.tencent.inputmethod.QQInput.plist" ]] || return 1
    [[ ! -d "$HOME/.Trash/Input Methods" ]]
}

@test "clean_trash dry run previews protected-name Trash items real mode empties (#1517)" {
    rm -rf "$HOME/.Trash" # SAFE: reset this test's temporary HOME fixture before populating it
    mkdir -p "$HOME/.Trash/Input Methods"
    touch "$HOME/.Trash/com.sogou.inputmethod.sogou.plist"
    touch "$HOME/.Trash/com.tencent.inputmethod.QQInput.plist"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
eval "$(awk '/^register_dry_run_cleanup_target\(\)/,/^}/' "$PROJECT_ROOT/bin/clean.sh")"
eval "$(awk '/^record_dry_run_cleanup_target\(\)/,/^}/' "$PROJECT_ROOT/bin/clean.sh")"
append_dry_run_cleanup_target() { :; }
CLEAN_PREVIEW_LEDGER_FILE="$HOME/.ledger"
: > "$CLEAN_PREVIEW_LEDGER_FILE"
DRY_RUN=true
stop_section_spinner() { :; }
note_activity() { :; }
is_path_whitelisted() { return 1; }
clean_trash
EOF

    rm -rf "$HOME/.Trash" "$HOME/.ledger" # SAFE: test fixture HOME
    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"Trash · would empty, 3 items"* ]]
}

@test "clean_trash dry run stops when the final Trash validation times out" {
    rm -rf "$HOME/.Trash" # SAFE: reset this test's temporary HOME fixture before populating it
    mkdir -p "$HOME/.Trash"
    touch "$HOME/.Trash/one.tmp" "$HOME/.Trash/two.tmp"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" MOLE_CURRENT_COMMAND=clean /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
DRY_RUN=true
stop_section_spinner() { :; }
note_activity() { :; }
is_path_whitelisted() { return 1; }
validate_path_for_deletion() {
    echo "VALIDATE:$1"
    return 124
}
record_dry_run_cleanup_target() { echo "UNEXPECTED_RECORD:$1"; }
rc=0
clean_trash || rc=$?
printf 'RC=%s CANCEL=%s\n' "$rc" "${MOLE_CLEAN_CANCEL_STATUS:-0}"
EOF

    rm -rf "$HOME/.Trash" # SAFE: test fixture HOME
    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"RC=124 CANCEL=124"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_RECORD"* ]] || return 1
    [[ "$output" != *"would empty"* ]] || return 1
    local validate_calls
    validate_calls=$(grep -c '^VALIDATE:' <<< "$output" || true)
    [ "$validate_calls" -eq 1 ]
}

@test "clean_trash dry run lists items whose sizing timed out or failed and cancels only on a signal" {
    # The real run sizes inside safe_remove and still empties an item whose
    # size probe timed out or failed. The preview must list the same items with
    # an unknown size and keep later sections running; only a signal cancels.
    local case_home="$HOME/trash-size-failure"
    rm -rf "$case_home" # SAFE: reset this test's own fixture under the temporary HOME
    mkdir -p "$case_home/.Trash/bigdir" "$case_home/.Trash/small"
    touch "$case_home/.Trash/bigdir/blob" "$case_home/.Trash/small/note"

    run env HOME="$case_home" PROJECT_ROOT="$PROJECT_ROOT" MOLE_CURRENT_COMMAND=clean \
        /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
note_activity() { :; }
debug_log() { :; }
is_path_whitelisted() { return 1; }
validate_path_for_deletion() { return 0; }
get_path_size_kb() {
    if [[ "$1" == */bigdir || "${SIZE_FAIL_ALL:-0}" == 1 ]]; then
        return "$SIZE_RC"
    fi
    echo 8
}
record_dry_run_cleanup_target() {
    printf '%s:%s:%s\n' "${1##*/}" "$2" "$4" >> "$HOME/recorded"
}
safe_remove() {
    printf '%s\n' "${1##*/}" >> "$HOME/removed"
    return 0
}

for scenario in 124:0 1:0 130:1 143:1; do
    SIZE_RC="${scenario%%:*}"
    SIZE_FAIL_ALL="${scenario##*:}"
    MOLE_CLEAN_CANCEL_STATUS=0
    MOLE_CLEAN_SIZING_TIMEOUTS=0
    : > "$HOME/recorded"
    : > "$HOME/removed"
    DRY_RUN=true
    rc=0
    clean_trash > "$HOME/dry.out" || rc=$?
    rows=$(grep -c 'would empty, 2 items' "$HOME/dry.out" || true)
    printf 'SCENARIO=%s RC=%s CANCEL=%s PARTIAL=%s ROWS=%s RECORDED=[%s]\n' \
        "$scenario" "$rc" "$MOLE_CLEAN_CANCEL_STATUS" "$MOLE_CLEAN_SIZING_TIMEOUTS" "$rows" \
        "$(sort "$HOME/recorded" | tr '\n' ',')"
    if [[ "$rc" -eq 0 ]]; then
        DRY_RUN=false
        clean_trash > /dev/null
        previewed=$(cut -d: -f1 "$HOME/recorded" | sort | tr '\n' ',')
        removed=$(sort "$HOME/removed" | tr '\n' ',')
        [[ "$previewed" == "$removed" ]] || exit 1
        printf 'PARITY=%s\n' "$removed"
    fi
done
EOF

    rm -rf "$case_home" # SAFE: test fixture under the temporary HOME
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" == *"SCENARIO=124:0 RC=0 CANCEL=0 PARTIAL=1 ROWS=1 RECORDED=[bigdir:0:false,small:8:true,]"* ]] || { echo "$output"; return 1; }
    [[ "$output" == *"SCENARIO=1:0 RC=0 CANCEL=0 PARTIAL=1 ROWS=1 RECORDED=[bigdir:0:false,small:8:true,]"* ]] || { echo "$output"; return 1; }
    [ "$(grep -c '^PARITY=bigdir,small,$' <<< "$output")" -eq 2 ] || { echo "$output"; return 1; }
    [[ "$output" == *"SCENARIO=130:1 RC=130 CANCEL=130 PARTIAL=0 ROWS=0 RECORDED=[]"* ]] || { echo "$output"; return 1; }
    [[ "$output" == *"SCENARIO=143:1 RC=143 CANCEL=143 PARTIAL=0 ROWS=0 RECORDED=[]"* ]] || { echo "$output"; return 1; }
}

@test "clean_trash dry run lists an item whose size probe skipped an unreadable child" {
    # du exits 1 when a child directory is unreadable, and get_path_size_kb
    # refuses to call that partial number a size. The preview used to return
    # silently and drop the whole Trash row while the real run emptied it.
    local case_home="$HOME/trash-unreadable-child"
    chmod -R u+rwx "$case_home" 2> /dev/null || true
    rm -rf "$case_home" # SAFE: reset this test's own fixture under the temporary HOME
    mkdir -p "$case_home/.Trash/locked/inner" "$case_home/.Trash/plain"
    touch "$case_home/.Trash/locked/inner/secret" "$case_home/.Trash/plain/note"
    chmod 000 "$case_home/.Trash/locked/inner"

    run env HOME="$case_home" PROJECT_ROOT="$PROJECT_ROOT" MOLE_CURRENT_COMMAND=clean \
        /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
DRY_RUN=true
stop_section_spinner() { :; }
note_activity() { :; }
is_path_whitelisted() { return 1; }
size_rc=0
get_path_size_kb "$HOME/.Trash/locked" > /dev/null 2>&1 || size_rc=$?
printf 'PROBE_RC=%s\n' "$size_rc"
rc=0
clean_trash || rc=$?
printf 'RC=%s CANCEL=%s\n' "$rc" "${MOLE_CLEAN_CANCEL_STATUS:-0}"
EOF

    chmod -R u+rwx "$case_home"
    rm -rf "$case_home" # SAFE: test fixture under the temporary HOME
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" == *"PROBE_RC=1"* ]] || { echo "$output"; return 1; }
    [[ "$output" == *"Trash · would empty, 2 items"* ]] || { echo "$output"; return 1; }
    [[ "$output" == *"RC=0 CANCEL=0"* ]] || { echo "$output"; return 1; }
}

@test "clean_user_essentials keeps Mole runtime logs while cleaning other user logs" {
    mkdir -p "$HOME/Library/Logs/mole"
    mkdir -p "$HOME/Library/Logs/OtherApp"
    touch "$HOME/Library/Logs/mole/operations.log"
    touch "$HOME/Library/Logs/OtherApp/old.log"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
DRY_RUN=false
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
is_path_whitelisted() { return 1; }
safe_clean() {
    local path=""
    for path in "${@:1:$#-1}"; do
        if should_protect_path "$path"; then
            continue
        fi
        /bin/rm -rf "$path"
    done
}

safe_clean_guarded() {
    local guard="$1"
    shift
    local label="${!#}"
    local -a targets=("${@:1:$#-1}")
    local -a kept=()
    local target
    for target in "${targets[@]}"; do
        if "$guard" "$target"; then
            kept+=("$target")
        fi
    done
    if [[ ${#kept[@]} -eq 0 ]]; then
        return 75
    fi
    safe_clean "${kept[@]}" "$label"
}
clean_user_essentials

[[ -d "$HOME/Library/Logs/mole" ]] || exit 1
[[ -f "$HOME/Library/Logs/mole/operations.log" ]] || exit 1
[[ ! -e "$HOME/Library/Logs/OtherApp/old.log" ]]
EOF

    [ "$status" -eq 0 ]
}

@test "clean_app_caches includes macOS system caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
start_section_spinner() { :; }
safe_clean() { echo "$2"; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_app_caches
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Saved application states"* ]] || [[ "$output" == *"App caches"* ]]
}

@test "clean_app_caches does not clean Autosave Information" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
start_section_spinner() { :; }
safe_clean() { echo "$2|$1"; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_app_caches
EOF

    [ "$status" -eq 0 ]
    [[ "$output" != *"Autosave information"* ]] || return 1
    [[ "$output" != *"Library/Autosave Information"* ]]
}

@test "clean_app_caches does not clean Calendar cache (#1508)" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
start_section_spinner() { :; }
safe_clean() { echo "$2|$1"; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_app_caches
EOF

    [ "$status" -eq 0 ]
    [[ "$output" != *"Calendar cache"* ]] || return 1
    [[ "$output" != *"Library/Calendars/Calendar Cache"* ]]
}

@test "clean_app_caches includes additional Apple cache families" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
start_section_spinner() { :; }
safe_clean() { echo "$2"; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_app_caches
EOF

    [ "$status" -eq 0 ] || return 1
    # The E5RT bundle cache is deliberately no longer a cleanup target: see
    # holds_compiled_model_cache(). Assert it first so the check cannot pass
    # vacuously on empty output.
    [[ "$output" != *"Apple Intelligence runtime cache"* ]] || return 1
    [[ "$output" == *"Apple Media Services cache"* ]] || return 1
    [[ "$output" == *"Duet Expert cache"* ]] || return 1
    [[ "$output" == *"Parsecd cache"* ]] || return 1
    [[ "$output" == *"Apple Python cache"* ]] || return 1
}

@test "clean_app_caches shows spinner during initial app cache scan" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { echo "SPIN_START:$1"; }
stop_section_spinner() { echo "SPIN_STOP"; }
safe_clean() { :; }
clean_support_app_data() { :; }
clean_group_container_caches() { :; }

clean_app_caches
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"SPIN_START:Scanning app caches..."* ]]
}

@test "clean_support_app_data targets crash reports and messages preview caches only" {
    local support_home="$HOME/support-cache-home-1"
    run env HOME="$support_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
mkdir -p "$HOME"
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
safe_clean() { echo "$2"; }
safe_find_delete() { echo "FIND:$1:$3:$4"; }
pgrep() { return 1; }

mkdir -p "$HOME/Library/Application Support/CrashReporter"
mkdir -p "$HOME/Library/Application Support/com.apple.idleassetsd"

clean_support_app_data

rm -rf "$HOME/Library/Application Support/CrashReporter"
rm -rf "$HOME/Library/Application Support/com.apple.idleassetsd"
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"FIND:$support_home/Library/Application Support/CrashReporter:30:f"* ]] || return 1
    [[ "$output" != *"com.apple.idleassetsd"* ]] || return 1
    [[ "$output" != *"Aerial wallpaper videos"* ]] || return 1
    [[ "$output" == *"Messages sticker cache"* ]] || return 1
    [[ "$output" == *"Messages preview attachment cache"* ]] || return 1
    [[ "$output" == *"Messages preview sticker cache"* ]] || return 1
    [[ "$output" != *"Messages attachments"* ]]
}

@test "clean_support_app_data always cleans messages preview caches" {
    local support_home="$HOME/support-cache-home-2"
    run env HOME="$support_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
mkdir -p "$HOME"
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
safe_clean() { echo "$2"; }
safe_find_delete() { :; }
pgrep() { return 0; }

clean_support_app_data
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Messages sticker cache"* ]] || return 1
    [[ "$output" == *"Messages preview attachment cache"* ]] || return 1
    [[ "$output" == *"Messages preview sticker cache"* ]]
}

@test "clean_app_caches never hands a third-party container to safe_clean" {
    # The previous version mocked safe_clean to a no-op and asserted only that
    # "App caches" was absent from empty output, so it could not fail. It also
    # could not test what its name claimed: clean_app_caches walks a fixed list of
    # Apple container paths and never enumerates arbitrary bundle ids, so the
    # com.example.app fixture was never in scope either way.
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
safe_clean() { echo "CLEAN:$1"; }
files_cleaned=0
total_size_cleaned=0
total_items=0
mkdir -p "$HOME/Library/Containers/com.example.app/Data/Library/Caches"
touch "$HOME/Library/Containers/com.example.app/Data/Library/Caches/test.cache"
clean_app_caches
EOF

    [ "$status" -eq 0 ]
    # Positive control: without it every assertion below is true on empty output.
    [[ "$output" == *"CLEAN:"*"Containers/com.apple."* ]] || return 1
    [[ "$output" != *"com.example.app"* ]] || return 1
    [[ "$output" != *"Containers/com.example"* ]]
}

@test "clean_app_caches preserves nested E5RT caches in sandboxed apps" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
DRY_RUN=false
should_protect_data() { return 1; }
is_critical_system_component() { return 1; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
safe_remove() {
    /bin/rm -rf "$1"
}

container="$HOME/Library/Containers/com.example.ocr"
cache_dir="$container/Data/Library/Caches"
e5rt_parent="$cache_dir/com.example.ocr"
mkdir -p "$e5rt_parent/com.apple.e5rt.e5bundlecache" "$cache_dir/disposable"
touch "$e5rt_parent/com.apple.e5rt.e5bundlecache/model.e5" "$cache_dir/disposable/data.tmp"

total_size=0
total_size_partial=false
cleaned_count=0
found_any=false
precise_size_limit=64
precise_size_used=0
process_container_cache "$container"

# Report state instead of asserting here: this script is fed to bash on stdin,
# and a child that drains the heredoc truncates whatever follows, so trailing
# in-script assertions can silently never run. Assert on $output below.
printf 'E5RT_KEPT=%s\n' "$([[ -f "$e5rt_parent/com.apple.e5rt.e5bundlecache/model.e5" ]] && echo yes || echo no)"
printf 'SIBLING_REMOVED=%s\n' "$([[ -e "$cache_dir/disposable" ]] && echo no || echo yes)"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"E5RT_KEPT=yes"* ]] || return 1
    [[ "$output" == *"SIBLING_REMOVED=yes"* ]] || return 1
}

@test "clean_app_caches skips expensive size scans for large sandboxed caches" {
    local large_home
    large_home=$(mktemp -d "${BATS_TEST_DIRNAME}/tmp-large-container.XXXXXX")
    run env HOME="$large_home" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
safe_clean() { :; }
should_protect_data() { return 1; }
is_critical_system_component() { return 1; }
get_path_size_kb() {
    printf 'SIZE:%s\n' "$1" >> "$size_trace"
    printf '7\n'
}
safe_remove() { return 0; }
files_cleaned=0
total_size_cleaned=0
total_items=0

size_trace="$HOME/size-trace"
mkdir -p "$HOME/Library/Containers/com.example.large/Data/Library/Caches"
for i in $(seq 1 101); do
    touch "$HOME/Library/Containers/com.example.large/Data/Library/Caches/file-$i.tmp"
done

clean_app_caches
printf 'SIZE_CALLS=%s\n' "$(wc -l < "$size_trace" 2> /dev/null || printf '0')"
EOF

    rm -rf "$large_home"
    [ "$status" -eq 0 ]
    [[ "$output" == *"Sandboxed app caches"* ]] || return 1
    [[ "$output" == *"SIZE_CALLS=0"* ]]
}

@test "clean_application_support_logs counts nested directory contents in dry-run size summary" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
safe_remove() { :; }
update_progress_if_needed() { return 1; }
should_protect_data() { return 1; }
is_critical_system_component() { return 1; }
files_cleaned=0
total_size_cleaned=0
total_items=0

mkdir -p "$HOME/Library/Application Support/TestApp/Code Cache/nested"
dd if=/dev/zero of="$HOME/Library/Application Support/TestApp/Code Cache/nested/data.bin" bs=1024 count=2 2> /dev/null

clean_application_support_logs
echo "TOTAL_KB=$total_size_cleaned"
rm -rf "$HOME/Library/Application Support"
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Application Support logs/caches"* ]] || return 1
    local total_kb
    total_kb=$(printf '%s\n' "$output" | sed -n 's/.*TOTAL_KB=\([0-9][0-9]*\).*/\1/p' | tail -1)
    [[ -n "$total_kb" ]] || return 1
	[[ "$total_kb" -ge 2 ]]
}

@test "clean_application_support_logs reuses exact item sizes at removal" {
	run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
update_progress_if_needed() { return 1; }
should_protect_data() { return 1; }
is_critical_system_component() { return 1; }
app_support_item_size_bytes() { printf '2048\n'; }
safe_remove() { printf 'REMOVE=%s SILENT=%s SIZE=%s\n' "$1" "$2" "${3:-missing}" >> "$HOME/remove-calls"; }
files_cleaned=0
total_size_cleaned=0
total_items=0

app_item="$HOME/Library/Application Support/TestApp/Code Cache/nested"
group_item="$HOME/Library/Group Containers/group.com.apple.contentdelivery/Logs/event.log"
mkdir -p "$app_item" "${group_item%/*}"
printf 'log\n' > "$group_item"

clean_application_support_logs
grep -Fx "REMOVE=$app_item SILENT=true SIZE=2" "$HOME/remove-calls"
grep -Fx "REMOVE=$group_item SILENT=true SIZE=2" "$HOME/remove-calls"
command rm -rf "$HOME/Library/Application Support/TestApp" \
    "$HOME/Library/Group Containers/group.com.apple.contentdelivery" \
    "$HOME/remove-calls"
EOF

	[ "$status" -eq 0 ] || return 1
	[[ "$output" == *"REMOVE=$HOME/Library/Application Support/TestApp/Code Cache/nested SILENT=true SIZE=2"* ]] || return 1
	[[ "$output" == *"REMOVE=$HOME/Library/Group Containers/group.com.apple.contentdelivery/Logs/event.log SILENT=true SIZE=2"* ]] || return 1
}

@test "clean_application_support_logs uses bulk clean for large Application Support directories" {
    local support_home="$HOME/support-appsupport-bulk"
    run env HOME="$support_home" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
mkdir -p "$HOME"
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { echo "SPIN:$1"; }
stop_section_spinner() { :; }
note_activity() { :; }
safe_remove() { echo "REMOVE:$1"; }
update_progress_if_needed() { return 1; }
should_protect_data() { return 1; }
is_critical_system_component() { return 1; }
bytes_to_human() { echo "0B"; }
files_cleaned=0
total_size_cleaned=0
total_items=0

mkdir -p "$HOME/Library/Application Support/adspower_global/Crashpad/completed"
for i in $(seq 1 101); do
    touch "$HOME/Library/Application Support/adspower_global/Crashpad/completed/file-$i.dmp"
done

clean_application_support_logs
rm -rf "$HOME/Library/Application Support"
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"SPIN:Scanning Application Support... 1/1 [adspower_global, bulk clean]"* ]] || return 1
    [[ "$output" == *"Application Support logs/caches"* ]] || return 1
    [[ "$output" != *"151250 items"* ]] || return 1
    [[ "$output" != *"REMOVE:"* ]]
}

@test "clean_application_support_logs does not clean generic Application Support logs" {
    local support_home="$HOME/support-appsupport-generic-logs"
    run env HOME="$support_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
mkdir -p "$HOME"
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
safe_remove() { echo "REMOVE:$1"; }
update_progress_if_needed() { return 1; }
should_protect_data() { return 1; }
is_critical_system_component() { return 1; }
files_cleaned=0
total_size_cleaned=0
total_items=0

mkdir -p "$HOME/Library/Application Support/TestApp/logs"
touch "$HOME/Library/Application Support/TestApp/logs/runtime.log"

clean_application_support_logs
test -f "$HOME/Library/Application Support/TestApp/logs/runtime.log"
rm -rf "$HOME/Library/Application Support"
EOF

    [ "$status" -eq 0 ]
    [[ "$output" != *"REMOVE:"* ]]
}

@test "clean_application_support_logs cleans Electron-style Cache only when cache markers exist" {
    local support_home="$HOME/support-appsupport-electron-cache"
    run env HOME="$support_home" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
mkdir -p "$HOME"
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
update_progress_if_needed() { return 1; }
should_protect_data() { return 1; }
is_critical_system_component() { return 1; }
WHITELIST_PATTERNS=()
files_cleaned=0
total_size_cleaned=0
total_items=0

mkdir -p "$HOME/Library/Application Support/ElectronLike/Code Cache"
mkdir -p "$HOME/Library/Application Support/ElectronLike/Cache"
mkdir -p "$HOME/Library/Application Support/ElectronLike/CachedData"
touch "$HOME/Library/Application Support/ElectronLike/Code Cache/runtime.bin"
touch "$HOME/Library/Application Support/ElectronLike/Cache/http-cache"
touch "$HOME/Library/Application Support/ElectronLike/CachedData/v8-data"

mkdir -p "$HOME/Library/Application Support/PlainApp/Cache"
touch "$HOME/Library/Application Support/PlainApp/Cache/keep.db"

clean_application_support_logs

test ! -e "$HOME/Library/Application Support/ElectronLike/Code Cache/runtime.bin"
test ! -e "$HOME/Library/Application Support/ElectronLike/Cache/http-cache"
test ! -e "$HOME/Library/Application Support/ElectronLike/CachedData/v8-data"
test -e "$HOME/Library/Application Support/PlainApp/Cache/keep.db"
rm -rf "$HOME/Library/Application Support"
EOF

    [ "$status" -eq 0 ]
}

@test "clean_application_support_logs skips whitelisted application support directories" {
    local support_home="$HOME/support-appsupport-whitelist"
    run env HOME="$support_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
mkdir -p "$HOME"
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
safe_remove() { echo "REMOVE:$1"; }
update_progress_if_needed() { return 1; }
should_protect_data() { return 1; }
is_critical_system_component() { return 1; }
WHITELIST_PATTERNS=("$HOME/Library/Application Support/io.github.clash-verge-rev.clash-verge-rev")
files_cleaned=0
total_size_cleaned=0
total_items=0

mkdir -p "$HOME/Library/Application Support/io.github.clash-verge-rev.clash-verge-rev/Code Cache"
touch "$HOME/Library/Application Support/io.github.clash-verge-rev.clash-verge-rev/Code Cache/runtime.bin"

clean_application_support_logs
test -f "$HOME/Library/Application Support/io.github.clash-verge-rev.clash-verge-rev/Code Cache/runtime.bin"
rm -rf "$HOME/Library/Application Support"
EOF

    [ "$status" -eq 0 ]
    [[ "$output" != *"REMOVE:"* ]]
}

@test "app_support_entry_count_capped stops at cap without failing under pipefail" {
    local support_home="$HOME/support-appsupport-cap"
    run env HOME="$support_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
mkdir -p "$HOME"
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"

mkdir -p "$HOME/Library/Application Support/adspower_global/logs"
for i in $(seq 1 150); do
    touch "$HOME/Library/Application Support/adspower_global/logs/file-$i.log"
done

count=$(app_support_entry_count_capped "$HOME/Library/Application Support/adspower_global/logs" 1 101)
echo "COUNT=$count"
rm -rf "$HOME/Library/Application Support"
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"COUNT=101"* ]]
}

@test "clean_group_container_caches keeps protected caches and cleans non-protected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() { shift; "$@"; }
files_cleaned=0
total_size_cleaned=0
total_items=0

mkdir -p "$HOME/Library/Group Containers/group.com.microsoft.teams/Library/Logs"
mkdir -p "$HOME/Library/Group Containers/group.com.microsoft.teams/Library/Caches"
mkdir -p "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches"
echo "log" > "$HOME/Library/Group Containers/group.com.microsoft.teams/Library/Logs/log.txt"
echo "cache" > "$HOME/Library/Group Containers/group.com.microsoft.teams/Library/Caches/cache.db"
echo "cache" > "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches/cache.db"

clean_group_container_caches

if [[ ! -e "$HOME/Library/Group Containers/group.com.microsoft.teams/Library/Logs/log.txt" ]] \
    && [[ -e "$HOME/Library/Group Containers/group.com.microsoft.teams/Library/Caches/cache.db" ]] \
    && [[ ! -e "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches/cache.db" ]]; then
    echo "PASS"
else
    echo "FAIL"
    exit 1
fi
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Group Containers logs/caches"* ]] || return 1
	[[ "$output" == *"PASS"* ]]
}

@test "clean_group_container_caches reuses exact item sizes at removal" {
	run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
should_protect_data() { return 1; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
get_path_size_kb() { printf '77\n'; }
safe_remove() { printf 'REMOVE=%s SILENT=%s SIZE=%s\n' "$1" "$2" "$3"; }
files_cleaned=0
total_size_cleaned=0
total_items=0

item="$HOME/Library/Group Containers/group.com.example.tool/Library/Caches/cache.db"
mkdir -p "${item%/*}"
printf 'cache\n' > "$item"
clean_group_container_caches
EOF

	[ "$status" -eq 0 ] || return 1
	[[ "$output" == *"REMOVE=$HOME/Library/Group Containers/group.com.example.tool/Library/Caches/cache.db SILENT=true SIZE=77"* ]] || return 1
}

@test "clean_group_container_caches dry run omits a live nested non-SQLite cache (#1471)" {
    local live_target="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/ComputerUse"
    local idle_target="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/IdleCache"
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true \
        live_target="$live_target" idle_target="$idle_target" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
should_protect_data() { return 1; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() {
    printf '%s\n' "$*" >> "$lsof_trace"
    case "$*" in
        *"+D $live_target"*)
            printf 'p901\nf5\nn%s\n' "$live_file"
            return 0
            ;;
        *"+D $idle_target"*) return 1 ;;
        *) return 2 ;;
    esac
}
run_with_timeout() { shift; "$@"; }
get_path_size_kb() { printf '77\n'; }
record_dry_run_cleanup_target() { printf 'PREVIEW=%s\n' "$1"; }
files_cleaned=0
total_size_cleaned=0
total_items=0

live_file="$live_target/segments/current/events.jsonl"
lsof_trace="$HOME/container-lsof-trace"
mkdir -p "${live_file%/*}"
mkdir -p "$idle_target"
printf 'event\n' > "$live_file"
printf 'idle\n' > "$idle_target/state.json"
clean_group_container_caches
test -f "$live_file" || exit 1
grep -qF "+D $live_target" "$lsof_trace" || exit 1
grep -qF "+D $idle_target" "$lsof_trace" || exit 1
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" != *"PREVIEW=$live_target"* ]] || return 1
    [[ "$output" == *"PREVIEW=$idle_target"* ]] || return 1
}

@test "clean_group_container_caches dry run omits compiled model cache parents (#1471)" {
    local model_home
    model_home=$(mktemp -d "${BATS_TEST_DIRNAME}/tmp-model-group.XXXXXX")
    local model_parent="$model_home/Library/Group Containers/TEAM.com.example.shared/Library/Caches/Vision"
    local idle_target="$model_home/Library/Group Containers/TEAM.com.example.shared/Library/Caches/ZIdle"
    run env HOME="$model_home" PROJECT_ROOT="$PROJECT_ROOT" MOLE_DRY_RUN=1 \
        model_parent="$model_parent" idle_target="$idle_target" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/bin/clean.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
should_protect_data() { return 1; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
_mole_timeout_with_deadline() {
    [[ ! -f "$exhausted_marker" ]] || return 1
    printf '2\n'
}
lsof() {
    case "$*" in
        *"+D $model_parent"*)
            touch "$exhausted_marker"
            return 1
            ;;
        *"+D $idle_target"*) return 1 ;;
        *) return 2 ;;
    esac
}
run_with_timeout() { shift; "$@"; }
get_path_size_kb() { printf '7\n'; }
register_dry_run_cleanup_target() { printf 'REGISTER=%s\n' "$1"; }
append_dry_run_cleanup_target() { printf 'APPEND=%s\n' "$1"; }
files_cleaned=0
total_size_cleaned=0
total_items=0

exhausted_marker="$HOME/compiled-probe-spent-budget"
mkdir -p "$model_parent/com.apple.e5rt.e5bundlecache"
mkdir -p "$idle_target"
printf 'model\n' > "$model_parent/com.apple.e5rt.e5bundlecache/model.bin"
printf 'idle\n' > "$idle_target/state.json"
clean_group_container_caches
printf 'FILES=%s SIZE=%s ITEMS=%s EXISTS=%s\n' \
    "$files_cleaned" "$total_size_cleaned" "$total_items" \
    "$(test -d "$model_parent" && echo yes || echo no)"
EOF

    rm -rf "$model_home"
    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"FILES=1 SIZE=7 ITEMS=1 EXISTS=yes"* ]] || return 1
    [[ "$output" != *"REGISTER=$model_parent"* ]] || return 1
    [[ "$output" != *"APPEND=$model_parent"* ]] || return 1
    [[ "$output" == *"REGISTER=$idle_target"* ]] || return 1
    [[ "$output" == *"APPEND=$idle_target"* ]] || return 1
    [[ "$output" == *"Group Containers logs/caches"* ]] || return 1
}

@test "explicit App Container cleanup families expose one cumulative probe deadline (#1471)" {
    local fixture_home="$HOME/container-probe-deadline"
    run env HOME="$fixture_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
pgrep() {
    printf '%s\n' "$*" >> "$HOME/process-trace"
    return 1
}
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
bytes_to_human() { printf '0B\n'; }
directory_has_entries() { return 1; }
clean_support_app_data() { :; }
safe_clean() {
    case "${*: -1}" in
        "Wallpaper agent cache" | "Microsoft Word container cache" | "UTM sandbox cache")
            [[ -n "${_MOLE_CONTAINER_CACHE_PROBE_DEADLINE+x}" ]] || {
                printf 'MISSING=%s\n' "${*: -1}"
                return 99
            }
            if [[ -z "$_MOLE_CONTAINER_CACHE_PROBE_DEADLINE" ]]; then
                _MOLE_CONTAINER_CACHE_PROBE_DEADLINE=4242
            elif [[ "$_MOLE_CONTAINER_CACHE_PROBE_DEADLINE" != "4242" ]]; then
                printf 'RESET=%s:%s\n' "${*: -1}" "$_MOLE_CONTAINER_CACHE_PROBE_DEADLINE"
                return 99
            fi
            printf 'SCOPED=%s\n' "${*: -1}"
            ;;
    esac
}
files_cleaned=0
total_size_cleaned=0
total_items=0
# The wallpaper row only reaches its sink with an old render of another picture.
renders="$HOME/Library/Containers/com.apple.wallpaper.agent/Data/Library/Caches/com.apple.wallpaper.caches/extension-com.apple.wallpaper.extension.image"
mkdir -p "$renders"
hex=0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef
echo x > "$renders/${hex}-5120-2880-0-1.bmp"
touch -t "$(date -v-30d +%Y%m%d%H%M)" "$renders/${hex}-5120-2880-0-1.bmp"
echo x > "$renders/${hex//0/f}-5120-2880-0-1.bmp"
# clean_utm_caches only reaches its sinks when a UTM target exists.
mkdir -p "$HOME/Library/Containers/com.utmapp.UTM/Data/Library/Caches"
echo x > "$HOME/Library/Containers/com.utmapp.UTM/Data/Library/Caches/blob"

clean_app_caches
clean_office_applications
clean_utm_caches
grep -qxF -- '-x UTM' "$HOME/process-trace" || exit 1
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"SCOPED=Wallpaper agent cache"* ]] || return 1
    [[ "$output" == *"SCOPED=Microsoft Word container cache"* ]] || return 1
    [[ "$output" == *"SCOPED=UTM sandbox cache"* ]] || return 1
    [[ "$output" != *"MISSING="* ]] || return 1
    [[ "$output" != *"RESET="* ]] || return 1
}

@test "process_container_cache counts only items safe_remove actually removed (#1471)" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
should_protect_data() { return 1; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
holds_compiled_model_cache() { return 1; }
get_path_size_kb() { printf '7\n'; }
safe_remove() { return 1; }

container="$HOME/Library/Containers/com.example.Failed"
target="$container/Data/Library/Caches/Live"
mkdir -p "$target"
printf 'live\n' > "$target/state.json"
total_size=0
total_size_partial=false
cleaned_count=0
found_any=false
precise_size_limit=64
precise_size_used=0
process_container_cache "$container"
printf 'FOUND=%s CLEANED=%s SIZE=%s EXISTS=%s\n' \
    "$found_any" "$cleaned_count" "$total_size" \
    "$(test -d "$target" && echo yes || echo no)"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"FOUND=false CLEANED=0 SIZE=0 EXISTS=yes"* ]] || return 1
}

@test "clean_group_container_caches does not report or count an all-refused large candidate (#1471)" {
    local refused_home
    refused_home=$(mktemp -d "${BATS_TEST_DIRNAME}/tmp-refused-group.XXXXXX")
    run env HOME="$refused_home" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
should_protect_data() { return 1; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
safe_remove() { return 1; }
get_path_size_kb() { printf 'UNEXPECTED_SIZE\n'; return 99; }
files_cleaned=0
total_size_cleaned=0
total_items=0

candidate="$HOME/Library/Group Containers/group.com.example.refused/Library/Caches"
mkdir -p "$candidate"
for i in $(seq 1 101); do
    printf 'live\n' > "$candidate/item-$i.jsonl"
done
clean_group_container_caches
remaining=$(find "$candidate" -type f | wc -l | tr -d ' ')
printf 'FILES=%s SIZE=%s ITEMS=%s REMAINING=%s\n' \
    "$files_cleaned" "$total_size_cleaned" "$total_items" "$remaining"
EOF

    rm -rf "$refused_home"
    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"FILES=0 SIZE=0 ITEMS=0 REMAINING=101"* ]] || return 1
    [[ "$output" != *"Group Containers logs/caches"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_SIZE"* ]] || return 1
}

@test "clean_handoff_pasteboard_cache removes stale items and keeps fresh ones (#1178)" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0

pb="$HOME/Library/Group Containers/group.com.apple.coreservices.useractivityd/shared-pasteboard"
mkdir -p "$pb/stale-item" "$pb/fresh-item"
echo "payload" > "$pb/stale-item/data"
echo "payload" > "$pb/fresh-item/data"
touch -t 202001010000 "$pb/stale-item"

clean_handoff_pasteboard_cache

# Stale item is removed, the in-flight (fresh) item and the container root
# survive. If path protection ever tightens over group.com.apple.* the stale
# item would survive too and this test must fail loudly.
if [[ ! -e "$pb/stale-item" ]] && [[ -e "$pb/fresh-item" ]] && [[ -d "$pb" ]]; then
    echo "PASS"
else
    echo "FAIL"
    exit 1
fi
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Handoff clipboard cache"* ]] || return 1
    [[ "$output" == *"PASS"* ]] || return 1
}

@test "clean_handoff_pasteboard_cache dry run reports without deleting" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0

pb="$HOME/Library/Group Containers/group.com.apple.coreservices.useractivityd/shared-pasteboard"
mkdir -p "$pb/stale-item"
echo "payload" > "$pb/stale-item/data"
touch -t 202001010000 "$pb/stale-item"

clean_handoff_pasteboard_cache

if [[ -e "$pb/stale-item/data" ]]; then
    echo "PASS"
else
    echo "FAIL"
    exit 1
fi
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Handoff clipboard cache"* ]] || return 1
    [[ "$output" == *"dry"* ]] || return 1
    [[ "$output" == *"PASS"* ]] || return 1
}

@test "jetbrains_stale_version_dirs reports only superseded IDE version dirs (#1179)" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"

jb="$HOME/Library/Application Support/JetBrains"
mkdir -p "$jb/GoLand2024.3" "$jb/GoLand2025.1" "$jb/GoLand2025.2" \
    "$jb/PyCharm2025.1" "$jb/IntelliJIdea2024.2" "$jb/IntelliJIdea2024.10" \
    "$jb/Toolbox"

jetbrains_stale_version_dirs "$jb" | sort
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"GoLand2024.3"* ]] || return 1
    [[ "$output" == *"GoLand2025.1"* ]] || return 1
    # Minor version 10 outranks 2: 2024.2 is stale, 2024.10 is the newest.
    [[ "$output" == *"IntelliJIdea2024.2"* ]] || return 1
    [[ "$output" != *"GoLand2025.2"* ]] || return 1
    [[ "$output" != *"PyCharm"* ]] || return 1
    [[ "$output" != *"IntelliJIdea2024.10"* ]] || return 1
    [[ "$output" != *"Toolbox"* ]] || return 1
}

@test "clean_group_container_caches skips Apple Notes group container" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0

notes_cache="$HOME/Library/Group Containers/group.com.apple.notes/Library/Caches"
mkdir -p "$notes_cache"
echo "notes" > "$notes_cache/NoteStore.sqlite"

clean_group_container_caches

if [[ -e "$notes_cache/NoteStore.sqlite" ]]; then
    echo "PASS"
else
    echo "FAIL"
    exit 1
fi
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"PASS"* ]]
}

@test "clean_group_container_caches respects whitelist entries" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() { shift; "$@"; }
files_cleaned=0
total_size_cleaned=0
total_items=0

mkdir -p "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches"
echo "protected" > "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches/keep.db"
echo "remove" > "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches/drop.db"

is_path_whitelisted() {
    [[ "$1" == *"/group.com.example.tool/Library/Caches/keep.db" ]]
}

clean_group_container_caches

if [[ -e "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches/keep.db" ]] \
    && [[ ! -e "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches/drop.db" ]]; then
    echo "PASS"
else
    # A bare FAIL cannot be told apart from a size-probe timeout under a
    # loaded parallel run, which is how this case reports when the suite is
    # busy. Print what actually survived.
    echo "FAIL"
    echo "keep.db present: $([[ -e "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches/keep.db" ]] && echo yes || echo no)"
    echo "drop.db present: $([[ -e "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches/drop.db" ]] && echo yes || echo no)"
    ls -la "$HOME/Library/Group Containers/group.com.example.tool/Library/Caches" 2> /dev/null || true
    exit 1
fi
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"PASS"* ]]
}

@test "clean_group_container_caches skips systemgroup apple containers" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0

mkdir -p "$HOME/Library/Group Containers/systemgroup.com.apple.example/Library/Caches"
echo "system-data" > "$HOME/Library/Group Containers/systemgroup.com.apple.example/Library/Caches/cache.db"

clean_group_container_caches

if [[ -e "$HOME/Library/Group Containers/systemgroup.com.apple.example/Library/Caches/cache.db" ]]; then
    echo "PASS"
else
    echo "FAIL"
    exit 1
fi
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"PASS"* ]]
}

@test "clean_group_container_caches does not report when only whitelisted items exist" {
    local whitelist_home="$HOME/group-only-whitelisted"
    mkdir -p "$whitelist_home"

    run env HOME="$whitelist_home" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0

mkdir -p "$HOME/Library/Group Containers/group.com.example.onlywhite/Library/Caches"
echo "whitelisted" > "$HOME/Library/Group Containers/group.com.example.onlywhite/Library/Caches/keep.db"

is_path_whitelisted() {
    [[ "$1" == *"/group.com.example.onlywhite/Library/Caches/keep.db" ]]
}

clean_group_container_caches

if [[ -e "$HOME/Library/Group Containers/group.com.example.onlywhite/Library/Caches/keep.db" ]]; then
    echo "PASS"
else
    echo "FAIL"
    exit 1
fi
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"PASS"* ]] || return 1
    [[ "$output" != *"Group Containers logs/caches"* ]]
}

@test "clean_group_container_caches skips per-item size scans for large candidates" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() { shift; "$@"; }
get_path_size_kb() {
    echo "SHOULD_NOT_SIZE_SCAN"
    return 0
}
files_cleaned=0
total_size_cleaned=0
total_items=0

mkdir -p "$HOME/Library/Group Containers/group.com.example.large/Library/Caches"
for i in $(seq 1 101); do
    touch "$HOME/Library/Group Containers/group.com.example.large/Library/Caches/file-$i.tmp"
done

clean_group_container_caches
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Group Containers logs/caches"* ]] || return 1
    [[ "$output" != *"SHOULD_NOT_SIZE_SCAN"* ]]
}

@test "container cache counters run in the caller's shell and restore glob options" {
    # Own HOME: earlier cases leave Group Containers fixtures in the shared one,
    # and every extra candidate adds a counter call.
    local counter_home
    counter_home=$(mktemp -d "${BATS_TEST_DIRNAME}/tmp-counter-home.XXXXXX")
    run env HOME="$counter_home" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
should_protect_data() { return 1; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
holds_compiled_model_cache() { return 1; }
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() { shift; "$@"; }
get_path_size_kb() { printf '7\n'; }
record_dry_run_cleanup_target() { return 0; }
files_cleaned=0
total_size_cleaned=0
total_items=0

# A call made through $(...) increments this counter in a subshell, so the
# owning shell sees zero: the count only survives a direct call.
eval "$(declare -f cache_top_level_entry_count_capped | sed '1s/^cache_top_level_entry_count_capped/_counted_entry_count_capped/')"
COUNTER_CALLS=0
cache_top_level_entry_count_capped() {
    COUNTER_CALLS=$((COUNTER_CALLS + 1))
    _counted_entry_count_capped "$@"
}

probe="$HOME/counter-probe"
mkdir -p "$probe"
touch "$probe/.hidden" "$probe/a" "$probe/b"
shopt -u nullglob dotglob
cache_top_level_entry_count_capped "$probe" 101
printf 'DIRECT_COUNT=%s\n' "$CACHE_TOP_LEVEL_ENTRY_COUNT"
cache_top_level_entry_count_capped "$probe" 2
printf 'CAPPED_COUNT=%s\n' "$CACHE_TOP_LEVEL_ENTRY_COUNT"
printf 'OFF_AFTER=%s%s\n' "$(shopt -q nullglob && echo N || echo n)" "$(shopt -q dotglob && echo D || echo d)"
shopt -s nullglob dotglob
cache_top_level_entry_count_capped "$probe" 101
printf 'ON_AFTER=%s%s\n' "$(shopt -q nullglob && echo N || echo n)" "$(shopt -q dotglob && echo D || echo d)"
shopt -u nullglob dotglob
COUNTER_CALLS=0

container="$HOME/Library/Containers/com.example.counter"
mkdir -p "$container/Data/Library/Caches/one"
touch "$container/Data/Library/Caches/one/data.tmp"
total_size=0
total_size_partial=false
cleaned_count=0
found_any=false
precise_size_limit=64
precise_size_used=0
process_container_cache "$container"
printf 'CONTAINER_CALLS=%s\n' "$COUNTER_CALLS"

mkdir -p "$HOME/Library/Group Containers/group.com.example.counter/Library/Caches"
for i in $(seq 1 101); do
    touch "$HOME/Library/Group Containers/group.com.example.counter/Library/Caches/file-$i.tmp"
done
clean_group_container_caches
printf 'TOTAL_CALLS=%s\n' "$COUNTER_CALLS"
printf 'GLOBS_AFTER=%s%s\n' "$(shopt -q nullglob && echo N || echo n)" "$(shopt -q dotglob && echo D || echo d)"
EOF

    rm -rf "$counter_home" # SAFE: this test's own mktemp HOME
    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"DIRECT_COUNT=3"* ]] || return 1
    [[ "$output" == *"CAPPED_COUNT=2"* ]] || return 1
    [[ "$output" == *"OFF_AFTER=nd"* ]] || return 1
    [[ "$output" == *"ON_AFTER=ND"* ]] || return 1
    [[ "$output" == *"CONTAINER_CALLS=1"* ]] || return 1
    [[ "$output" == *"Group Containers logs/caches"* ]] || return 1
    [[ "$output" == *"TOTAL_CALLS=2"* ]] || return 1
    [[ "$output" == *"GLOBS_AFTER=nd"* ]]
}

@test "clean_finder_metadata respects protection flag" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" PROTECT_FINDER_METADATA=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
note_activity() { :; }
clean_finder_metadata
EOF

    [ "$status" -eq 0 ]
    # Whitelist-protected items no longer show output (UX improvement in V1.22.0)
    [[ "$output" == "" ]]
}

@test "clean_browsers calls expected cache paths" {
    local fixture_home="$HOME/browser-cache-paths"
    run env HOME="$fixture_home" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
mkdir -p "$HOME/Library/Caches/Firefox"
touch "$HOME/Library/Caches/Firefox/candidate"
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
pgrep() {
    printf '%s\n' "$*" >> "$HOME/process-trace"
    return 1
}
safe_clean() { echo "$2"; }
clean_service_worker_cache() { :; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_browsers
grep -qxF -- '-x Firefox' "$HOME/process-trace" || exit 1
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"Safari cache"* ]] || return 1
    [[ "$output" == *"Firefox cache"* ]] || return 1
    [[ "$output" == *"Puppeteer browser cache"* ]]
}

@test "clean_browsers never enters Firefox cleanup while Firefox is running" {
    mkdir -p "$HOME/Library/Caches/Firefox" \
        "$HOME/Library/Application Support/Firefox/Profiles/default/cache2"
    touch "$HOME/Library/Caches/Firefox/candidate" \
        "$HOME/Library/Application Support/Firefox/Profiles/default/cache2/candidate"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
pgrep() { [[ "$*" == "-x Firefox" ]]; }
safe_clean() { echo "SAFE_CLEAN:${!#}"; }
clean_service_worker_cache() { :; }
note_activity() { :; }
clean_browsers
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" != *"SAFE_CLEAN:Firefox cache"* ]] || return 1
    [[ "$output" != *"SAFE_CLEAN:Firefox profile cache"* ]]
}

@test "clean_browsers fails closed when the Chrome process probe errors" {
    local chrome_support="$HOME/Library/Application Support/Google/Chrome"
    rm -rf "$chrome_support"
    mkdir -p "$chrome_support/Default/Code Cache"
    touch "$chrome_support/Default/Code Cache/candidate"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
pgrep() { return 2; }
safe_clean() { echo "SAFE_CLEAN:${!#}"; }
clean_service_worker_cache() { :; }
note_activity() { :; }
clean_browsers
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"Chrome profile caches · skipped (process state unknown)"* ]] || return 1
    [[ "$output" != *"SAFE_CLEAN:Chrome code cache"* ]]
}

@test "clean_browsers does not defer empty Chrome and Firefox roots" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
rm -rf "$HOME/Library/Application Support/Google/Chrome" \
    "$HOME/Library/Caches/Firefox" \
    "$HOME/Library/Application Support/Firefox/Profiles"
mkdir -p "$HOME/Library/Application Support/Google/Chrome/Default/Code Cache" \
    "$HOME/Library/Caches/Firefox" \
    "$HOME/Library/Application Support/Firefox/Profiles/default/cache2"
pgrep() { return 0; }
defer_cleanup_family() { echo "UNEXPECTED_DEFER:$1"; }
safe_clean() { :; }
clean_service_worker_cache() { :; }
clean_browsers
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" != *"UNEXPECTED_DEFER:Chrome"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_DEFER:Firefox"* ]] || return 1
    [[ "$output" != *"process state unknown"* ]]
}

@test "clean_browsers does not defer broken-symlink-only Chrome and Firefox roots" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
rm -rf "$HOME/Library/Application Support/Google/Chrome" \
    "$HOME/Library/Caches/Firefox" \
    "$HOME/Library/Application Support/Firefox/Profiles"
mkdir -p "$HOME/Library/Application Support/Google/Chrome/Default/Code Cache" \
    "$HOME/Library/Caches/Firefox" \
    "$HOME/Library/Application Support/Firefox/Profiles/default/cache2"
ln -s "$HOME/missing-chrome-cache" \
    "$HOME/Library/Application Support/Google/Chrome/Default/Code Cache/broken"
ln -s "$HOME/missing-firefox-cache" "$HOME/Library/Caches/Firefox/broken"
ln -s "$HOME/missing-firefox-profile-cache" \
    "$HOME/Library/Application Support/Firefox/Profiles/default/cache2/broken"
mkdir -p "$HOME/Library/Application Support/Google/Chrome/Default/Code Cache/compiled/com.apple.e5rt.e5bundlecache"
mkdir -p "$HOME/Library/Caches/Firefox/compiled/com.apple.e5rt.e5bundlecache"
pgrep() { return 0; }
defer_cleanup_family() { echo "UNEXPECTED_DEFER:$1"; }
safe_clean() { echo "UNEXPECTED_CLEAN:${!#}"; }
clean_service_worker_cache() { :; }
clean_browsers
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" != *"UNEXPECTED_DEFER:Chrome"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_DEFER:Firefox"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_CLEAN:Chrome code cache"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_CLEAN:Firefox cache"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_CLEAN:Firefox profile cache"* ]]
}

@test "clean_browsers ignores active whitelist-only Chrome profile caches" {
    local chrome_support="$HOME/Library/Application Support/Google/Chrome"
    rm -rf "$chrome_support"
    mkdir -p "$chrome_support/Default/Code Cache"
    touch "$chrome_support/Default/Code Cache/whitelisted"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
target="$HOME/Library/Application Support/Google/Chrome/Default/Code Cache/whitelisted"
is_path_whitelisted() { [[ "$1" == "$target" ]]; }
pgrep() { return 0; }
defer_cleanup_family() { echo "UNEXPECTED_DEFER:$1"; }
safe_clean() { :; }
clean_service_worker_cache() { :; }
clean_browsers
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" != *"UNEXPECTED_DEFER:Chrome"* ]]
}

@test "clean_cloud_storage never enters active provider cleanup when caches are absent" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
pgrep() {
    case "$*" in
        "-x Dropbox" | "-x Google Drive" | "-x OneDrive") return 0 ;;
        *) return 1 ;;
    esac
}
safe_clean() { echo "SAFE_CLEAN:${!#}"; }
clean_cloud_storage
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" != *"SAFE_CLEAN:Dropbox cache"* ]] || return 1
    [[ "$output" != *"SAFE_CLEAN:Google Drive cache"* ]] || return 1
    [[ "$output" != *"SAFE_CLEAN:OneDrive cache"* ]]
}

@test "clean_cloud_storage fails closed when provider probes error" {
    local cache_root="$HOME/Library/Caches"
    mkdir -p "$cache_root/com.getdropbox.dropbox" \
        "$cache_root/com.google.GoogleDrive" \
        "$cache_root/com.microsoft.OneDrive"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
pgrep() { return 2; }
should_protect_path() { return 1; }
safe_clean() { echo "SAFE_CLEAN:${!#}"; }
clean_cloud_storage
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"Dropbox cache · skipped (process state unknown)"* ]] || return 1
    [[ "$output" == *"Google Drive cache · skipped (process state unknown)"* ]] || return 1
    [[ "$output" == *"OneDrive cache · skipped (process state unknown)"* ]] || return 1
    [[ "$output" != *"SAFE_CLEAN:Dropbox cache"* ]] || return 1
    [[ "$output" != *"SAFE_CLEAN:Google Drive cache"* ]] || return 1
    [[ "$output" != *"SAFE_CLEAN:OneDrive cache"* ]]
}

@test "clean_browsers keeps all Chrome AI model stores when whitelisted" {
    local chrome_support="$HOME/Library/Application Support/Google/Chrome"
    mkdir -p "$chrome_support/OptGuideOnDeviceModel/2026"
    mkdir -p "$chrome_support/OptGuideOnDeviceClassifierModel/2026"
    mkdir -p "$chrome_support/optimization_guide_model_store/2026"
    mkdir -p "$chrome_support/Default/Code Cache/js"
    touch "$chrome_support/OptGuideOnDeviceModel/2026/model.bin"
    touch "$chrome_support/OptGuideOnDeviceClassifierModel/2026/classifier.bin"
    touch "$chrome_support/optimization_guide_model_store/2026/model.bin"
    touch "$chrome_support/Default/Code Cache/js/cache.bin"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
WHITELIST_PATTERNS=(
    "$HOME/Library/Application Support/Google/Chrome/OptGuideOnDevice*/*"
    "$HOME/Library/Application Support/Google/Chrome/optimization_guide_model_store/*"
)
pgrep() { return 1; }
# The fixture HOME carries Library/Caches/com.apple.Safari from a sibling
# test, and validate_path_for_deletion refuses a cache whose owner is live.
# Pin an empty process table so this whitelist test does not depend on
# whether Safari happens to be running on the machine (#1390).
ps() { printf '  PID  PPID COMM ARGS\n'; }
clean_service_worker_cache() { :; }
note_activity() { :; }
safe_clean() {
    local count=$#
    local label="${!count}"
    local index item
    for ((index = 1; index < count; index++)); do
        item="${!index}"
        if is_path_whitelisted "$item"; then
            printf 'KEEP:%s:%s\n' "$label" "$item"
        else
            safe_remove "$item" true
        fi
    done
}
clean_browsers
EOF

    [ "$status" -eq 0 ] || return 1
    [[ -f "$chrome_support/OptGuideOnDeviceModel/2026/model.bin" ]] || return 1
    [[ -f "$chrome_support/OptGuideOnDeviceClassifierModel/2026/classifier.bin" ]] || return 1
    [[ -f "$chrome_support/optimization_guide_model_store/2026/model.bin" ]] || return 1
    [[ ! -e "$chrome_support/Default/Code Cache/js/cache.bin" ]] || return 1
    [[ "$output" == *"KEEP:Chrome on-device model cache"* ]] || return 1
    [[ "$output" == *"KEEP:Chrome on-device classifier cache"* ]] || return 1
    [[ "$output" == *"KEEP:Chrome optimization guide models"* ]] || return 1
}

@test "clean_browsers preserves Brave Service Worker ScriptCache" {
    mkdir -p "$HOME/Library/Application Support/BraveSoftware/Brave-Browser/Default/Service Worker/ScriptCache"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
safe_clean() { echo "$2"; }
clean_service_worker_cache() { echo "Brave SW $1"; }
note_activity() { :; }
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_browsers
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Brave SW Brave"* ]] || return 1
    [[ "$output" != *"Brave Service Worker ScriptCache"* ]] || return 1

    rm -rf "$HOME/Library"
}

@test "clean_browsers covers Arc User Data layout" {
    mkdir -p "$HOME/Library/Application Support/Arc/User Data/Default/Service Worker/ScriptCache"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
safe_clean() { echo "$2|$1"; }
clean_service_worker_cache() { echo "Arc SW $2"; }
note_activity() { :; }
pgrep() { return 1; }
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_browsers
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Arc code cache|$HOME/Library/Application Support/Arc/User Data/"* ]] || return 1
    [[ "$output" == *"Arc component CRX cache|$HOME/Library/Application Support/Arc/User Data/component_crx_cache/"* ]] || return 1
    [[ "$output" == *"Arc extensions CRX cache|$HOME/Library/Application Support/Arc/User Data/extensions_crx_cache/"* ]] || return 1
    [[ "$output" == *"Arc SW $HOME/Library/Application Support/Arc/User Data/Default/Service Worker/CacheStorage"* ]] || return 1
    [[ "$output" != *"Arc Service Worker ScriptCache|$HOME/Library/Application Support/Arc/User Data/Default/Service Worker/ScriptCache/"* ]] || return 1

    rm -rf "$HOME/Library"
}

@test "clean_browsers always preserves Chromium Service Worker ScriptCache (#785 #964 #968)" {
    mkdir -p "$HOME/Library/Application Support/Google/Chrome/Default/Service Worker/ScriptCache"
    mkdir -p "$HOME/Library/Application Support/Arc/User Data/Default/Service Worker/ScriptCache"
    mkdir -p "$HOME/Library/Application Support/BraveSoftware/Brave-Browser/Default/Service Worker/ScriptCache"
    mkdir -p "$HOME/Library/Application Support/Vivaldi/Default/Service Worker/ScriptCache"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
safe_clean() { echo "$2"; }
clean_service_worker_cache() { echo "SW-CALL $1"; }
note_activity() { :; }
pgrep() { return 1; }
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_browsers
EOF

    [ "$status" -eq 0 ]
    # CacheStorage cleanup still runs (it has its own protection logic).
    [[ "$output" == *"SW-CALL Chrome"* ]] || return 1
    # ScriptCache cleanup must NOT run at all: wiping V8 bytecode can break
    # Chromium MV3 extension service workers even after the browser exits.
    [[ "$output" != *"Chrome Service Worker ScriptCache"* ]] || return 1
    [[ "$output" != *"Arc Service Worker ScriptCache"* ]] || return 1
    [[ "$output" != *"Brave Service Worker ScriptCache"* ]] || return 1
    [[ "$output" != *"Vivaldi Service Worker ScriptCache"* ]] || return 1

    rm -rf "$HOME/Library"
}

@test "clean_browsers preserves Arc User Data ScriptCache regardless of running state" {
    mkdir -p "$HOME/Library/Application Support/Arc/User Data/Default/Service Worker/ScriptCache"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
safe_clean() { echo "$2|$1"; }
clean_service_worker_cache() { echo "Arc SW $2"; }
note_activity() { :; }
pgrep() {
    [[ "${2:-}" == "Arc" ]]
}
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_browsers
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Arc SW $HOME/Library/Application Support/Arc/User Data/Default/Service Worker/CacheStorage"* ]] || return 1
    [[ "$output" != *"Arc Service Worker ScriptCache|$HOME/Library/Application Support/Arc/User Data/Default/Service Worker/ScriptCache/"* ]] || return 1

    rm -rf "$HOME/Library"
}

@test "clean_browsers covers QQ Browser 3 caches when not running" {
    mkdir -p "$HOME/Library/Application Support/QQBrowser3/Default/Code Cache"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
safe_clean() { echo "$2|$1"; }
clean_service_worker_cache() { :; }
note_activity() { :; }
pgrep() { return 1; }
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_browsers
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"QQ Browser cache|$HOME/Library/Caches/com.tencent.QQBrowser3/"* ]] || return 1
    [[ "$output" == *"QQ Browser code cache|$HOME/Library/Application Support/QQBrowser3/"* ]] || return 1
    [[ "$output" == *"QQ Browser component cache|$HOME/Library/Application Support/QQBrowser3/component_crx_cache/"* ]] || return 1

    rm -rf "$HOME/Library"
}

@test "clean_browsers skips QQ Browser 3 profile caches while running" {
    mkdir -p "$HOME/Library/Application Support/QQBrowser3/Default/Code Cache"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
safe_clean() { echo "$2|$1"; }
clean_service_worker_cache() { :; }
note_activity() { :; }
pgrep() {
    [[ "${2:-}" == "QQBrowser3" ]]
}
files_cleaned=0
total_size_cleaned=0
total_items=0
clean_browsers
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"QQ Browser cache|$HOME/Library/Caches/com.tencent.QQBrowser3/"* ]] || return 1
    [[ "$output" != *"QQ Browser code cache"* ]] || return 1
    [[ "$output" != *"QQ Browser GPU cache"* ]] || return 1

    rm -rf "$HOME/Library"
}

@test "user cleanup process guards keep caches when pgrep cannot tell" {
    # These guards used `pgrep -x App && running=true` or `if pgrep; then
    # skip`, so a pgrep error (exit 2/3, or no pgrep) read as "not running"
    # and the cleanup ran against a possibly live app. Each case runs with
    # pgrep reporting a clean miss first, proving the fixture reaches the
    # sink, then with pgrep failing, where the sink must not run.
    local row case_name sink display_name pgrep_rc case_home failures=""
    for row in \
        "mail|Mail Downloads/old.bin|Mail Downloads" \
        "arc|Arc code cache|Arc profile caches" \
        "brave|Brave code cache|Brave profile caches" \
        "vivaldi|Vivaldi code cache|Vivaldi profile caches" \
        "qqbrowser|QQ Browser code cache|QQ Browser profile caches" \
        "utm|UTM app cache|UTM caches"; do
        IFS='|' read -r case_name sink display_name <<< "$row"
        for pgrep_rc in 1 2; do
            case_home="$HOME/pgrep-unknown-$case_name-$pgrep_rc"
            mkdir -p "$case_home"
            run env HOME="$case_home" PROJECT_ROOT="$PROJECT_ROOT" \
                CASE="$case_name" PGREP_RC="$pgrep_rc" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
pgrep() { return "$PGREP_RC"; }
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
clean_service_worker_cache() { :; }
get_path_size_kb() { echo 6000; }
safe_clean() { local n=$#; echo "SINK:${!n}"; }
safe_remove() { echo "SINK:$1"; }
support="$HOME/Library/Application Support"
case "$CASE" in
    mail)
        mkdir -p "$HOME/Library/Mail Downloads"
        echo x > "$HOME/Library/Mail Downloads/old.bin"
        touch -t 202401010000 "$HOME/Library/Mail Downloads/old.bin"
        _clean_mail_downloads
        ;;
    arc)
        mkdir -p "$support/Arc/User Data/Default/Code Cache"
        clean_browsers
        ;;
    brave)
        mkdir -p "$support/BraveSoftware/Brave-Browser/Default/Code Cache"
        clean_browsers
        ;;
    vivaldi)
        mkdir -p "$support/Vivaldi/Default/Code Cache"
        clean_browsers
        ;;
    qqbrowser)
        mkdir -p "$support/QQBrowser3/Default/Code Cache"
        clean_browsers
        ;;
    utm)
        mkdir -p "$HOME/Library/Caches/com.utmapp.UTM"
        echo x > "$HOME/Library/Caches/com.utmapp.UTM/blob"
        clean_utm_caches
        ;;
esac
EOF
            rm -rf "$case_home"
            if [[ "$status" -ne 0 ]]; then
                failures+="$case_name pgrep=$pgrep_rc exited $status: $output"$'\n'
            elif [[ $pgrep_rc -eq 1 ]]; then
                if [[ "$output" != *"SINK:"*"$sink"* ]]; then
                    failures+="$case_name positive control never reached the sink: $output"$'\n'
                fi
            else
                if [[ "$output" == *"SINK:"*"$sink"* ]]; then
                    failures+="$case_name cleaned while pgrep could not tell"$'\n'
                fi
                if [[ "$output" != *"$display_name · stopped (process state unknown)"* ]]; then
                    failures+="$case_name did not report the unknown process state"$'\n'
                fi
            fi
        done
    done
    # Every row runs before failing, so one red run names every broken guard.
    [ -z "$failures" ] || {
        printf '%s' "$failures"
        return 1
    }
}

@test "clean_application_support_logs skips when no access" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
note_activity() { :; }
clean_application_support_logs
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Skipped: No permission"* ]]
}

@test "clean_apple_silicon_caches exits when not M-series" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" IS_M_SERIES=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
safe_clean() { echo "$2"; }
clean_apple_silicon_caches
EOF

    [ "$status" -eq 0 ]
    [[ -z "$output" ]]
}

@test "clean_user_essentials includes dotfiles in Trash cleanup" {
    mkdir -p "$HOME/.Trash"
    touch "$HOME/.Trash/.hidden_file"
    touch "$HOME/.Trash/.DS_Store"
    touch "$HOME/.Trash/regular_file.txt"
    mkdir -p "$HOME/.Trash/.hidden_dir"
    mkdir -p "$HOME/.Trash/regular_dir"

    run /bin/bash << 'EOF'
set -euo pipefail
count=0
while IFS= read -r -d '' item; do
    ((count++)) || true
    echo "FOUND: $(basename "$item")"
done < <(command find "$HOME/.Trash" -mindepth 1 -maxdepth 1 -print0 2> /dev/null || true)
echo "COUNT: $count"
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"COUNT: 5"* ]] || return 1
    [[ "$output" == *"FOUND: .hidden_file"* ]] || return 1
    [[ "$output" == *"FOUND: .DS_Store"* ]] || return 1
    [[ "$output" == *"FOUND: .hidden_dir"* ]] || return 1
    [[ "$output" == *"FOUND: regular_file.txt"* ]]
}

@test "validate_external_volume_target canonicalizes root before comparing target" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"

mock_bin="$HOME/bin"
mkdir -p "$mock_bin"
cat > "$mock_bin/diskutil" <<'MOCK'
#!/bin/bash
exit 0
MOCK
chmod +x "$mock_bin/diskutil"
export PATH="$mock_bin:$PATH"

real_root="$(mktemp -d "$HOME/ext-real.XXXXXX")"
link_root="$HOME/ext-link"
ln -s "$real_root" "$link_root"
mkdir -p "$link_root/USB"
export MOLE_EXTERNAL_VOLUMES_ROOT="$link_root"

resolved=$(validate_external_volume_target "$link_root/USB")
echo "RESOLVED=$resolved"
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"RESOLVED="*"/USB"* ]] || return 1
    [[ "$output" != *"must be under"* ]]
}

@test "clean_app_caches caps precise sandbox size scans when many containers exist" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true MOLE_CONTAINER_CACHE_PRECISE_SIZE_LIMIT=2 /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
safe_clean() { :; }
clean_support_app_data() { :; }
clean_group_container_caches() { :; }
bytes_to_human() { echo "0B"; }
note_activity() { :; }
should_protect_data() { return 1; }
is_critical_system_component() { return 1; }
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() { shift; "$@"; }
files_cleaned=0
total_size_cleaned=0
total_items=0

count_file="$HOME/size-count"
get_path_size_kb() {
    local count
    count=$(cat "$count_file" 2> /dev/null || echo "0")
    count=$((count + 1))
    echo "$count" > "$count_file"
    echo "1"
}

for i in $(seq 1 5); do
    mkdir -p "$HOME/Library/Containers/com.example.$i/Data/Library/Caches"
    touch "$HOME/Library/Containers/com.example.$i/Data/Library/Caches/file-$i.tmp"
done

clean_app_caches
echo "SIZE_CALLS=$(cat "$count_file")"
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Sandboxed app caches"* ]] || return 1
    [[ "$output" == *"SIZE_CALLS=2"* ]]
}

@test "clean_app_caches stops before deleting when a container size probe times out" {
    local container="$HOME/Library/Containers/com.example.timeout/Data/Library/Caches"
    mkdir -p "$container"
    touch "$container/payload"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false \
        MOLE_CURRENT_COMMAND=clean MOLE_CLEAN_CANCEL_STATUS=0 \
        /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
safe_clean() { :; }
safe_remove() { echo "UNEXPECTED_DELETE:$1"; }
clean_support_app_data() { :; }
clean_group_container_caches() { echo "UNEXPECTED_CONTINUATION"; }
clean_handoff_pasteboard_cache() { echo "UNEXPECTED_CONTINUATION"; }
note_activity() { :; }
get_path_size_kb() { return 124; }
files_cleaned=0
total_size_cleaned=0
total_items=0

set +e
clean_app_caches
rc=$?
set -e
printf 'RC=%s CANCEL=%s\n' "$rc" "$MOLE_CLEAN_CANCEL_STATUS"
[[ $rc -eq 124 && $MOLE_CLEAN_CANCEL_STATUS -eq 124 ]]
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=124 CANCEL=124"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_DELETE"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_CONTINUATION"* ]]
}

# Regression for discussion #583: the only Dia row used to be
# ~/Library/Caches/company.thebrowser.dia, where that measurement found Sentry
# state, not Chromium caches; the directory can also contain Sparkle updates.
# The actual Chromium caches live under
# ~/Library/Caches/Dia/User Data and ~/Library/Application Support/Dia/User Data,
# so `mo clean` reclaimed 0 bytes from Dia. Paths below were measured on Dia
# 1.41.1 (bundle company.thebrowser.dia), not inferred from Chromium convention.
@test "clean_browsers covers the real Dia cache locations" {
    mkdir -p "$HOME/Library/Caches/company.thebrowser.dia/io.sentry"
    mkdir -p "$HOME/Library/Caches/Dia/User Data/Default/Cache/Cache_Data"
    mkdir -p "$HOME/Library/Caches/Dia/User Data/Default/Code Cache/js"
    mkdir -p "$HOME/Library/Application Support/Dia/User Data/GraphiteDawnCache"
    mkdir -p "$HOME/Library/Application Support/Dia/User Data/GPUPersistentCache"
    mkdir -p "$HOME/Library/Application Support/Dia/User Data/component_crx_cache"
    mkdir -p "$HOME/Library/Application Support/Dia/User Data/extensions_crx_cache"
    mkdir -p "$HOME/Library/Application Support/Dia/User Data/Default/DawnGraphiteCache"
    mkdir -p "$HOME/Library/Application Support/Dia/User Data/Default/DawnWebGPUCache"
    mkdir -p "$HOME/Library/Application Support/Dia/User Data/Default/GPUCache"
    touch "$HOME/Library/Caches/Dia/User Data/Default/Cache/Cache_Data/entry"
    touch "$HOME/Library/Application Support/Dia/User Data/component_crx_cache/blob"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
start_inline_spinner() { :; }
stop_inline_spinner() { :; }
note_activity() { :; }
clean_service_worker_cache() { :; }
# Must be mocked: an unmocked pgrep sees the maintainer's real Dia process and
# silently flips this test to the skip branch.
pgrep() { return 1; }
safe_clean() { local n=$#; echo "CLEAN:${!n}"; }
clean_browsers
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"CLEAN:Dia HTTP cache"* ]] || return 1
    [[ "$output" == *"CLEAN:Dia code cache"* ]] || return 1
    [[ "$output" == *"CLEAN:Dia component CRX cache"* ]] || return 1
    [[ "$output" == *"CLEAN:Dia extensions CRX cache"* ]] || return 1
    [[ "$output" == *"CLEAN:Dia Graphite Dawn cache"* ]] || return 1
    [[ "$output" == *"CLEAN:Dia GPU cache"* ]] || return 1
    [[ "$output" == *"CLEAN:Dia Dawn Graphite cache"* ]] || return 1
    [[ "$output" == *"CLEAN:Dia Dawn WebGPU cache"* ]] || return 1
}

@test "clean_browsers skips Dia Application Support caches while Dia runs" {
    mkdir -p "$HOME/Library/Application Support/Dia/User Data/component_crx_cache"
    mkdir -p "$HOME/Library/Caches/Dia/User Data/Default/Cache"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
start_inline_spinner() { :; }
stop_inline_spinner() { :; }
note_activity() { :; }
clean_service_worker_cache() { :; }
pgrep() { [[ "${2:-}" == "Dia" ]] && return 0; return 1; }
safe_clean() { local n=$#; echo "CLEAN:${!n}"; }
clean_browsers
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"Dia Application Support cache"* ]] || return 1
    [[ "$output" == *"skipped (Dia running)"* ]] || return 1
    [[ "$output" != *"CLEAN:Dia component CRX cache"* ]] || return 1
    [[ "$output" != *"CLEAN:Dia HTTP cache"* ]] || return 1
}

@test "clean_browsers fails closed when the Dia process probe errors" {
    mkdir -p "$HOME/Library/Application Support/Dia/User Data/component_crx_cache"
    mkdir -p "$HOME/Library/Caches/Dia/User Data/Default/Cache"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
start_inline_spinner() { :; }
stop_inline_spinner() { :; }
note_activity() { :; }
clean_service_worker_cache() { :; }
pgrep() { return 2; }
safe_clean() { local n=$#; echo "CLEAN:${!n}"; }
clean_browsers
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"skipped (process state unknown)"* ]] || return 1
    [[ "$output" != *"CLEAN:Dia component CRX cache"* ]] || return 1
    [[ "$output" != *"CLEAN:Dia HTTP cache"* ]] || return 1
}

@test "large files includes the unique System Data review targets" {
    local review_home="$HOME/large-review-targets"
    mkdir -p \
        "$review_home/Library/Developer/Xcode/DerivedData" \
        "$review_home/Library/Developer/CoreSimulator/Devices" \
        "$review_home/Library/Containers/com.docker.docker/Data" \
        "$review_home/Library/Caches/deno" \
        "$review_home/go/pkg/mod"

    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
du() { printf '2097152 %s\n' "${2:-/tmp}"; }
run_with_timeout() {
    shift
    "$@"
}
check_large_file_candidates
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"⊙"* ]] &&
        [[ "$output" == *"Xcode DerivedData"* ]] &&
        [[ "$output" == *"Simulator data"* ]] &&
        [[ "$output" == *"Docker Desktop data"* ]] &&
        [[ "$output" == *"Deno module cache"* ]] || {
        echo "$output"
        return 1
    }
    [[ "$output" != *"Go module cache"* ]] || {
        echo "$output"
        return 1
    }
}

@test "large files reviews Android, Hugging Face, mise, and Gradle payloads without deleting" {
    local review_home="$HOME/large-review-payloads"
    mkdir -p \
        "$review_home/.android/avd/Pixel_8a.avd" \
        "$review_home/Library/Android/sdk/system-images/android-35" \
        "$review_home/.cache/huggingface/hub" \
        "$review_home/.local/share/mise/installs/node/22.1.0" \
        "$review_home/.gradle/caches/modules-2"
    ln -s "$review_home/.local/share/mise/installs/node" "$review_home/.local/share/mise/installs/nodejs"

    run env -u ANDROID_AVD_HOME -u ANDROID_HOME -u ANDROID_SDK_ROOT -u HF_HOME -u MISE_DATA_DIR \
        HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
du() { printf '2097152 %s\n' "${2:-/tmp}"; }
run_with_timeout() {
    shift
    "$@"
}


check_large_file_candidates
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"Android emulators"* ]] &&
        [[ "$output" == *"Android system images"* ]] &&
        [[ "$output" == *"Hugging Face cache"* ]] &&
        [[ "$output" == *"mise node installs"* ]] &&
        [[ "$output" == *"Gradle caches"* ]] || {
        echo "$output"
        return 1
    }
    # A symlinked tool alias must not double-report the same payload.
    [[ "$output" != *"mise nodejs installs"* ]] || {
        echo "$output"
        return 1
    }
    [ -d "$review_home/.android/avd/Pixel_8a.avd" ] &&
        [ -d "$review_home/Library/Android/sdk/system-images/android-35" ] &&
        [ -d "$review_home/.cache/huggingface/hub" ] &&
        [ -d "$review_home/.local/share/mise/installs/node/22.1.0" ] &&
        [ -d "$review_home/.gradle/caches/modules-2" ]
}

@test "large files reports large E5RT caches without deleting or following links (#1631)" {
    local review_home
    review_home=$(mktemp -d "$HOME/e5rt-review.XXXXXX")
    mkdir -p "$review_home/Library/Caches/python/com.apple.e5rt.e5bundlecache" \
        "$review_home/Library/Caches/small/com.apple.e5rt.e5bundlecache" \
        "$review_home/elsewhere/com.apple.e5rt.e5bundlecache"
    ln -s "$review_home/elsewhere" "$review_home/Library/Caches/linked-owner"
    ln -s "$review_home/elsewhere/com.apple.e5rt.e5bundlecache" "$review_home/Library/Caches/python/linked-cache"
    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
defaults() { return 1; }
docker() { return 1; }
safe_clean() { printf 'UNEXPECTED_DELETE\n'; }
run_with_timeout() {
    shift
    if [[ "$1" == du ]]; then
        case "${!#}" in
            */small/*) printf '16\t%s\n' "${!#}" ;;
            *) printf '75497472\t%s\n' "${!#}" ;;
        esac
    else
        "$@"
    fi
}
check_large_file_candidates
holds_compiled_model_cache "$HOME/Library/Caches/python" || exit 1
holds_compiled_model_cache "$HOME/Library/Caches/python/com.apple.e5rt.e5bundlecache" || exit 1
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" == *"Compiled model cache (python)"* ]] || return 1
    [[ "$output" != *"Compiled model cache (small)"* ]] || return 1
    [[ "$output" != *"linked-owner"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_DELETE"* ]] || return 1
    [ -d "$review_home/Library/Caches/python/com.apple.e5rt.e5bundlecache" ]
}

@test "large files discards partial E5RT measurements and continues later review (#1631)" {
    local review_home
    review_home=$(mktemp -d "$HOME/e5rt-timeout.XXXXXX")
    mkdir -p "$review_home/Library/Caches/python/com.apple.e5rt.e5bundlecache" "$review_home/.android/avd"
    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
defaults() { return 1; }
docker() { return 1; }
run_with_timeout() {
    shift
    if [[ "$1" == du ]]; then
        printf '75497472\t%s\n' "${!#}"
        if [[ "${!#}" == */com.apple.e5rt.e5bundlecache ]]; then
            printf 'MEASURED_E5RT\n' >&3
            return 124
        fi
        return 0
    fi
    "$@"
}
check_large_file_candidates 3> "$HOME/measurement.trace"
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [ "$(cat "$review_home/measurement.trace")" = MEASURED_E5RT ] || return 1
    [[ "$output" != *"Compiled model cache"* ]] || return 1
    [[ "$output" == *"Android emulators"* ]]
}

@test "large files keeps a du total that skipped unreadable entries" {
    local review_home
    review_home=$(mktemp -d "$HOME/du-partial.XXXXXX")
    mkdir -p "$review_home/Library/Developer/CoreSimulator/Devices"
    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
defaults() { return 1; }
docker() { return 1; }
run_with_timeout() {
    shift
    if [[ "$1" == du ]]; then
        # BSD du prints the readable total and exits 1 for an unreadable entry.
        printf '12000000\t%s\n' "${!#}"
        return 1
    fi
    "$@"
}
check_large_file_candidates
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" == *"Simulator data"* ]]
}

@test "large files skips an E5RT total that missed unreadable entries (#1631)" {
    local review_home
    review_home=$(mktemp -d "$HOME/e5rt-partial.XXXXXX")
    mkdir -p "$review_home/Library/Caches/python/com.apple.e5rt.e5bundlecache" \
        "$review_home/Library/Developer/CoreSimulator/Devices"
    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
defaults() { return 1; }
docker() { return 1; }
run_with_timeout() {
    shift
    if [[ "$1" == du ]]; then
        # BSD du prints the readable total and exits 1 for an unreadable entry.
        printf '12000000\t%s\n' "${!#}"
        return 1
    fi
    "$@"
}
check_large_file_candidates
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" != *"Compiled model cache"* ]] || return 1
    [[ "$output" == *"Simulator data"* ]]
}

@test "large files continues later rows when the E5RT listing has no scratch file" {
    local review_home
    review_home=$(mktemp -d "$HOME/e5rt-scratch.XXXXXX")
    mkdir -p "$review_home/Library/Caches/python/com.apple.e5rt.e5bundlecache" "$review_home/.android/avd"
    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { echo "ACTIVITY"; }
defaults() { return 1; }
docker() { return 1; }
create_temp_file() { return 1; }
run_with_timeout() {
    shift
    if [[ "$1" == du ]]; then
        printf '75497472\t%s\n' "${!#}"
        return 0
    fi
    "$@"
}
check_large_file_candidates
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" != *"Compiled model cache"* ]] || return 1
    [[ "$output" == *"Android emulators"* ]] || return 1
    [[ "$output" == *"ACTIVITY"* ]]
}

@test "large files discards incomplete E5RT discovery and propagates measurement signals (#1631)" {
    local review_home
    review_home=$(mktemp -d "$HOME/e5rt-errors.XXXXXX")
    mkdir -p "$review_home/Library/Caches/python/com.apple.e5rt.e5bundlecache" "$review_home/.android/avd"
    local mode
    for mode in listing_failure measurement_signal spent_budget; do
        run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" CASE_MODE="$mode" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
defaults() { return 1; }
docker() { return 1; }
run_with_timeout() {
    shift
    if [[ "$1" == find && "$2" == "$HOME/Library/Caches" ]]; then
        printf 'LISTING\n' >&3
        printf '%s\0' "$HOME/Library/Caches/python/com.apple.e5rt.e5bundlecache"
        if [[ "$CASE_MODE" == listing_failure ]]; then return 1; fi
        if [[ "$CASE_MODE" == spent_budget ]]; then SECONDS=$((SECONDS + MOLE_TIMEOUT_HINT_SCAN_SEC)); fi
        return 0
    fi
    if [[ "$1" == du ]]; then
        if [[ "${!#}" == */com.apple.e5rt.e5bundlecache ]]; then
            printf 'MEASURED\n' >&3
            return 130
        fi
        printf '2097152\t%s\n' "${!#}"
        return 0
    fi
    "$@"
}
check_large_file_candidates 3> "$HOME/$CASE_MODE.trace"
EOF
        if [[ "$mode" == measurement_signal ]]; then
            [ "$status" -eq 130 ] || { echo "$output"; return 1; }
            [ "$(cat "$review_home/$mode.trace")" = $'LISTING\nMEASURED' ] || return 1
            [[ "$output" != *"Android emulators"* ]] || return 1
        else
            [ "$status" -eq 0 ] || { echo "$output"; return 1; }
            [ "$(cat "$review_home/$mode.trace")" = LISTING ] || return 1
            [[ "$output" == *"Android emulators"* ]] || return 1
        fi
        [[ "$output" != *"Compiled model cache"* ]] || return 1
    done
}

@test "large files reviews installed FVM Flutter SDKs without deleting" {
    local review_home="$HOME/large-review-fvm"
    mkdir -p "$review_home/fvm/versions/3.47.5" "$review_home/custom-fvm/versions/3.44.0"

    local fvm_env
    for fvm_env in default custom; do
        if [[ "$fvm_env" == "default" ]]; then
            run env -u FVM_CACHE_PATH HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" \
                /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
du() { printf '2097152 %s\n' "${2:-/tmp}"; }
format_path_link() { printf '%s' "$1"; }
run_with_timeout() {
    shift
    "$@"
}
check_large_file_candidates
EOF
        else
            run env FVM_CACHE_PATH="$review_home/custom-fvm" HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" \
                /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
du() { printf '2097152 %s\n' "${2:-/tmp}"; }
format_path_link() { printf '%s' "$1"; }
run_with_timeout() {
    shift
    "$@"
}
check_large_file_candidates
EOF
        fi
        [ "$status" -eq 0 ] || {
            echo "$fvm_env: $output"
            return 1
        }
        if [[ "$fvm_env" == "default" ]]; then
            [[ "$output" == *"FVM Flutter SDKs"*"$review_home/fvm/versions"* ]] || {
                echo "$fvm_env: $output"
                return 1
            }
        else
            [[ "$output" == *"FVM Flutter SDKs"*"$review_home/custom-fvm/versions"* ]] || {
                echo "$fvm_env: $output"
                return 1
            }
        fi
    done
    # Report only: both SDK folders must still exist afterwards.
    [ -d "$review_home/fvm/versions/3.47.5" ] &&
        [ -d "$review_home/custom-fvm/versions/3.44.0" ]
}

@test "large files links the full path behind a two-segment label" {
    local review_home="$HOME/large-review-short-path"
    mkdir -p "$review_home/Library/Application Support/MobileSync/Backup/00008150-DEVICE" "$review_home/.gradle/caches"

    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
format_path_link() { printf 'LINK<%s>TEXT<%s>' "$1" "${2:-}"; }
du() { printf '2097152 %s\n' "${2:-/tmp}"; }
run_with_timeout() {
    shift
    "$@"
}
check_large_file_candidates
EOF

    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" == *"LINK<$review_home/Library/Application Support/MobileSync/Backup>TEXT<…/MobileSync/Backup>"* ]] || { echo "$output"; return 1; }
    # A path that is already short keeps its full form.
    [[ "$output" == *"TEXT<~/.gradle/caches>"* ]] || { echo "$output"; return 1; }
}

@test "large files measures each row once, at most four at a time, and prints them in order" {
    local review_home="$HOME/large-review-pool"
    # path|label in queue order. Each row gets its own size, so a result read
    # from a neighbouring row's file prints a wrong size on that row.
    local -a pool_rows=(
        "Library/Developer/Xcode/DerivedData|Xcode DerivedData"
        "Library/Developer/CoreSimulator/Devices|Simulator data"
        "Library/Application Support/MobileSync/Backup|iOS backups"
        "Library/Mail|Mail data"
        "Library/Updates|macOS updates cache"
        ".lima|Lima data"
        ".m2/repository|Maven local repository"
        ".ivy2/cache|Ivy local repository"
        ".nuget/packages|NuGet packages"
        "Library/pnpm/store|pnpm store"
        ".conda/pkgs|Conda packages"
        ".gradle/caches|Gradle caches"
    )
    local entry row index=0
    mkdir -p "$review_home"
    : > "$review_home/sizes"
    for entry in "${pool_rows[@]}"; do
        row="${entry%%|*}"
        mkdir -p "$review_home/$row"
        # Row N reads as N.00GB: 976563 KB is just over 1e9 bytes.
        printf '%s\t%s\n' "$review_home/$row" "$(((index + 2) * 976563))" >> "$review_home/sizes"
        index=$((index + 1))
    done
    # Developer shells and CI runners export these; the fixture HOME must win.
    run env -u ANDROID_AVD_HOME -u ANDROID_HOME -u ANDROID_SDK_ROOT -u DENO_DIR -u FVM_CACHE_PATH -u HF_HOME -u MISE_DATA_DIR \
        HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
format_path_link() { printf '%s' "$1"; }
mkdir -p "$HOME/live"
run_with_timeout() {
    shift
    if [[ "$1" == du ]]; then
        local marker="$HOME/live/$RANDOM.$RANDOM"
        : > "$marker"
        printf '%s\n' "${!#}" >> "$HOME/du.calls"
        ls "$HOME/live" | wc -l | tr -d ' ' >> "$HOME/concurrency"
        sleep 0.3
        command rm -f "$marker"
        printf '%s\t%s\n' "$(awk -F'\t' -v p="${!#}" '$1 == p { print $2 }' "$HOME/sizes")" "${!#}"
        return 0
    fi
    "$@"
}
check_large_file_candidates
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    # One measurement per folder: a lost pool state re-measured later rows.
    local repeated
    repeated=$(sort "$review_home/du.calls" | uniq -d)
    [[ -z "$repeated" ]] || { echo "measured twice: $repeated"; return 1; }
    [[ "$(wc -l < "$review_home/du.calls" | tr -d ' ')" -eq ${#pool_rows[@]} ]] || { cat "$review_home/du.calls"; return 1; }
    local peak
    peak=$(sort -n "$review_home/concurrency" | tail -1)
    [[ "$peak" -ge 2 && "$peak" -le 4 ]] || { echo "peak=$peak"; return 1; }
    # Every row prints the size measured for its own folder.
    local plain
    plain=$(printf '%s\n' "$output" | sed "s/$(printf '\033')\[[0-9;]*m//g")
    index=0
    for entry in "${pool_rows[@]}"; do
        grep -qF -- "${entry#*|} · $((index + 2)).00GB" <<< "$plain" || { echo "wrong size for ${entry#*|}"; echo "$plain"; return 1; }
        index=$((index + 1))
    done
    # Rows keep their report order whatever order the sizes arrive in.
    local order
    order=$(printf '%s\n' "$output" | grep -oE 'Mail data|Xcode DerivedData|Simulator data|iOS backups|Maven local repository|Gradle caches' | tr '\n' ',')
    [[ "$order" == "Mail data,Xcode DerivedData,Simulator data,iOS backups,Maven local repository,Gradle caches," ]] || { echo "order=$order"; return 1; }
}

@test "large files still reports rows after slow ones use up the shared budget" {
    local review_home="$HOME/large-review-budget"
    # The first four queued rows start the pool; the other four wait behind
    # them. The budget is 6 s, so the first wave gets 4 to 6 s per row.
    mkdir -p \
        "$review_home/Library/Developer/Xcode/DerivedData" \
        "$review_home/Library/Developer/CoreSimulator/Devices" \
        "$review_home/Library/Mail" \
        "$review_home/Library/Mail Downloads" \
        "$review_home/Library/Updates" \
        "$review_home/.lima" \
        "$review_home/.m2/repository" \
        "$review_home/.gradle/caches"
    run env -u ANDROID_AVD_HOME -u ANDROID_HOME -u ANDROID_SDK_ROOT -u DENO_DIR -u FVM_CACHE_PATH -u HF_HOME -u MISE_DATA_DIR \
        HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" MOLE_TIMEOUT_HINT_SCAN_SEC=6 /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
format_path_link() { printf '%s' "$1"; }
run_with_timeout() {
    local seconds="$1"
    shift
    if [[ "$1" == du ]]; then
        printf '%s %s %s\n' "$SECONDS" "$seconds" "${!#}" >> "$HOME/du.calls"
        # A row granted more than the 3 s inline budget hangs for all of it.
        if [[ "${seconds%%.*}" -gt 3 ]]; then
            sleep "$seconds"
            return 124
        fi
        printf '2097152\t%s\n' "${!#}"
        return 0
    fi
    "$@"
}
check_large_file_candidates
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    # Positive control: the pool did start and its first wave used up the
    # shared budget, so those rows were skipped as timed out.
    [[ "$output" != *"Xcode DerivedData"* && "$output" != *"Simulator data"* &&
        "$output" != *"Mail data"* && "$output" != *"Mail downloads"* ]] || { echo "$output"; cat "$review_home/du.calls"; return 1; }
    # Rows still queued when the deadline passed keep their inline budget
    # instead of inheriting a pool budget, so these four still report.
    [[ "$output" == *"macOS updates cache"* && "$output" == *"Lima data"* &&
        "$output" == *"Maven local repository"* && "$output" == *"Gradle caches"* ]] || { echo "$output"; cat "$review_home/du.calls"; return 1; }
}

@test "large files leaves a row the pool cannot fully budget to the inline probe" {
    local review_home="$HOME/large-review-floor"
    mkdir -p \
        "$review_home/Library/Developer/Xcode/DerivedData" \
        "$review_home/Library/Developer/CoreSimulator/Devices" \
        "$review_home/Library/Application Support/MobileSync/Backup" \
        "$review_home/Library/Mail" \
        "$review_home/Library/Mail Downloads"
    run env -u ANDROID_AVD_HOME -u ANDROID_HOME -u ANDROID_SDK_ROOT -u DENO_DIR -u FVM_CACHE_PATH -u HF_HOME -u MISE_DATA_DIR \
        HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" MOLE_TIMEOUT_HINT_SCAN_SEC=4 /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
format_path_link() { printf '%s' "$1"; }
run_with_timeout() {
    local seconds="$1"
    shift
    if [[ "$1" == du ]]; then
        case "${!#}" in
            */Mail\ Downloads)
                # Needs about two seconds: a cut pool budget would time out.
                if [[ "${seconds%%.*}" -lt 2 ]]; then sleep "$seconds"; return 124; fi
                sleep 1.5
                ;;
            *) sleep 3 ;;
        esac
        printf '2097152\t%s\n' "${!#}"
        return 0
    fi
    "$@"
}
check_large_file_candidates
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" == *"Mail downloads"* ]] || { echo "$output"; return 1; }
}

@test "large files searches for agent worktrees once" {
    local review_home="$HOME/large-review-worktrees"
    # A queued row makes the size pool and the background search both run.
    mkdir -p "$review_home/www/app/.claude/worktrees/one" "$review_home/.gradle/caches"
    run env -u ANDROID_AVD_HOME -u ANDROID_HOME -u ANDROID_SDK_ROOT -u DENO_DIR -u FVM_CACHE_PATH -u HF_HOME -u MISE_DATA_DIR \
        HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
eval "real_$(declare -f agent_worktree_containers)"
agent_worktree_containers() { printf 'search\n' >> "$HOME/searches"; real_agent_worktree_containers "$@"; }
get_path_size_kb() { printf '2097152\n'; }
check_large_file_candidates
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$(wc -l < "$review_home/searches" | tr -d ' ')" -eq 1 ]] || { cat "$review_home/searches"; return 1; }
    [[ "$output" == *"AI agent worktrees"* ]] || { echo "$output"; return 1; }
}

@test "large files queues every fixed review row for early measurement" {
    local review_home="$HOME/large-review-queue"
    local -a queued_rows=(
        "Library/Mail" "Library/Mail Downloads" "Library/Updates"
        "Library/Developer/Xcode/DerivedData" "Library/Developer/Xcode/Archives"
        "Library/Developer/CoreSimulator/Devices" "Library/Containers/com.docker.docker/Data"
        "Library/Application Support/MobileSync/Backup" ".lmstudio/models"
        "Library/Group Containers/HUAQ24HBR6.dev.orbstack/data" "OrbStack" ".lima"
        ".m2/repository" ".ivy2/cache" ".nuget/packages" "Library/Caches/deno"
        "Library/pnpm/store"
        ".conda/pkgs" "anaconda3/pkgs" ".gradle/caches" ".android/avd"
        "Library/Android/sdk/system-images" ".cache/huggingface"
        ".local/share/mise/installs/node" "fvm/versions"
    )
    local row
    for row in "${queued_rows[@]}"; do
        mkdir -p "$review_home/$row"
    done
    # CI runners export ANDROID_HOME; every row must resolve under the fixture.
    run env -u ANDROID_AVD_HOME -u ANDROID_HOME -u ANDROID_SDK_ROOT -u DENO_DIR -u FVM_CACHE_PATH -u HF_HOME -u MISE_DATA_DIR \
        HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
_large_prefetch_queue_rows
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    for row in "${queued_rows[@]}"; do
        grep -Fxq -- "$review_home/$row" <<< "$output" || { echo "missing $row"; return 1; }
    done
}

@test "large files queue lists every fixed HOME row the report measures" {
    local review_home="$HOME/large-review-drift"
    # Rows spelled as a literal $HOME path in the report are the ones a new
    # row can silently miss; comment lines are skipped so this prose cannot
    # satisfy the pattern, and an empty match must fail instead of passing.
    local -a report_rows=()
    local report_row
    # shellcheck disable=SC2016  # The patterns match the literal text $HOME in user.sh.
    while IFS= read -r report_row; do
        report_rows+=("$report_row")
    done < <(grep -v '^[[:space:]]*#' "$PROJECT_ROOT/lib/clean/user.sh" |
        grep -oE '_report_large_or_stop "[^"]+" "\$HOME/[^"]+"' |
        sed -E 's/.*"\$HOME\/([^"]+)"$/\1/')
    [ "${#report_rows[@]}" -gt 10 ] || { echo "matched ${#report_rows[@]} report rows"; return 1; }
    for report_row in "${report_rows[@]}"; do
        mkdir -p "$review_home/$report_row"
    done

    run env -u ANDROID_AVD_HOME -u ANDROID_HOME -u ANDROID_SDK_ROOT -u DENO_DIR -u FVM_CACHE_PATH -u HF_HOME -u MISE_DATA_DIR \
        HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
_large_prefetch_queue_rows
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    for report_row in "${report_rows[@]}"; do
        grep -Fxq -- "$review_home/$report_row" <<< "$output" || { echo "report row not queued: $report_row"; return 1; }
    done
}

@test "large files dates the irreplaceable rows and leaves caches undated" {
    local review_home="$HOME/large-review-dates"
    mkdir -p \
        "$review_home/Library/Application Support/MobileSync/Backup/00008150-DEVICE" \
        "$review_home/Library/Developer/Xcode/Archives/2026-03-04" \
        "$review_home/Library/Developer/Xcode/DerivedData/Some-project"
    touch -t 202601021200 "$review_home/Library/Application Support/MobileSync/Backup/00008150-DEVICE"
    touch -t 202603041200 "$review_home/Library/Developer/Xcode/Archives/2026-03-04"

    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
du() { printf '2097152 %s\n' "${2:-/tmp}"; }
run_with_timeout() {
    shift
    "$@"
}
check_large_file_candidates
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    # Size alone cannot decide these two: the date separates a live phone
    # backup from a dead one, and a shipped archive from a stray export.
    [[ "$output" == *"iOS backups"*"2026-01-02"* ]] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"Xcode archives"*"2026-03-04"* ]] || {
        echo "$output"
        return 1
    }
    # Rebuildable caches stay undated on purpose; their age never changes the
    # answer, and a date on every row would bury the two that matter.
    local derived_row
    derived_row=$(printf '%s\n' "$output" | grep 'Xcode DerivedData' || true)
    [[ -n "$derived_row" ]] || {
        echo "$output"
        return 1
    }
    [[ "$derived_row" != *[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]* ]] || {
        echo "$derived_row"
        return 1
    }
}

@test "large files skip a timed-out Mail size check and keep later rows (#1576)" {
    local review_home="$HOME/large-review-mail-timeout"
    mkdir -p \
        "$review_home/Library/Mail" \
        "$review_home/Library/Developer/Xcode/DerivedData"

    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
du() { printf '2097152 %s\n' "${2:-/tmp}"; }
# Cover both the current get_path_size_kb Mail rows and the review-dir
# helper that sizes through run_with_timeout + du.
get_path_size_kb() {
    [[ "$1" == "$HOME/Library/Mail" ]] && return 124
    printf '2097152\n'
}
run_with_timeout() {
    shift
    [[ "${!#}" == "$HOME/Library/Mail" ]] && return 124
    "$@"
}
check_large_file_candidates
echo AFTER_LARGE_FILES
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"AFTER_LARGE_FILES"* ]] || {
        echo "$output"
        return 1
    }
    [[ "$output" != *"Mail data"* ]] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"Xcode DerivedData"* ]] || {
        echo "$output"
        return 1
    }
}

@test "large files still cancel when Mail sizing is interrupted (#1576)" {
    local review_home="$HOME/large-review-mail-signal"
    mkdir -p \
        "$review_home/Library/Mail" \
        "$review_home/Library/Developer/Xcode/DerivedData"

    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -uo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
docker() { return 1; }
defaults() { return 1; }
du() { printf '2097152 %s\n' "${2:-/tmp}"; }
get_path_size_kb() {
    [[ "$1" == "$HOME/Library/Mail" ]] && return 130
    printf '2097152\n'
}
run_with_timeout() {
    shift
    [[ "${!#}" == "$HOME/Library/Mail" ]] && return 130
    "$@"
}
MOLE_CURRENT_COMMAND=clean
MOLE_CLEAN_CANCEL_STATUS=0
check_large_file_candidates
echo AFTER_LARGE_FILES
EOF

    [ "$status" -eq 130 ] || {
        echo "status=$status $output"
        return 1
    }
    [[ "$output" != *"AFTER_LARGE_FILES"* ]] || {
        echo "$output"
        return 1
    }
    [[ "$output" != *"Xcode DerivedData"* ]] || {
        echo "$output"
        return 1
    }
}

# Runs Large files against a docker stub that renders whatever
# `system df --format` template production asks for, from rows of
# Type|TotalCount|Active|Size|Reclaimable. The caller reads the Docker line
# out of `output` with `_docker_row`.
_large_files_docker_row() {
    local review_home="$1"
    local rows="$2"
    mkdir -p "$review_home"

    run env HOME="$review_home" PROJECT_ROOT="$PROJECT_ROOT" DOCKER_DF_ROWS="$rows" \
        /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
defaults() { return 1; }
run_with_timeout() {
    shift
    "$@"
}
docker() {
    [[ "${1:-} ${2:-}" == "system df" && "${3:-}" == "--format" ]] || return 1
    local type total active size reclaimable line
    while IFS='|' read -r type total active size reclaimable; do
        line="$4"
        line=${line//'{{.Type}}'/$type}
        line=${line//'{{.TotalCount}}'/$total}
        line=${line//'{{.Active}}'/$active}
        line=${line//'{{.Size}}'/$size}
        line=${line//'{{.Reclaimable}}'/$reclaimable}
        line=${line//'\t'/$'\t'}
        printf '%s\n' "$line"
    done <<< "$DOCKER_DF_ROWS"
}
check_large_file_candidates
EOF
}

_docker_row() {
    printf '%s\n' "$1" | grep 'Docker storage' || true
}

@test "large files Docker row drops an in-use images reclaimable (moby#51775)" {
    # Colima on Engine 29.2 with the containerd image store: both images back
    # a container, yet the daemon calls all of them reclaimable.
    _large_files_docker_row "$HOME/large-review-docker-containerd" \
        "Images|2|2|7.093GB|7.093GB (100%)
Containers|2|1|846.3MB|3.658MB (0%)
Local Volumes|7|7|65.76MB|0B (0%)
Build Cache|0|0|0B|0B"

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    local docker_row
    docker_row=$(_docker_row "$output")
    [[ "$docker_row" == *"Images 7.093GB (2/2 in use) · Containers 846.3MB (3.658MB (0%) reclaimable) · Local Volumes 65.76MB (0B (0%) reclaimable) · Build Cache 0B (0B reclaimable)"* ]] || {
        echo "$output"
        return 1
    }
    [[ "$docker_row" != *"(100%)"* ]] || {
        echo "$docker_row"
        return 1
    }
}

@test "large files Docker row drops a 100% images reclaimable while one image is in use" {
    # Same daemon bug with only part of the images in use: 100% is still
    # impossible, because the image a container runs keeps its layers.
    _large_files_docker_row "$HOME/large-review-docker-partial" \
        "Images|3|1|4.2GB|4.2GB (100%)
Containers|1|1|12MB|0B (0%)"

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    local docker_row
    docker_row=$(_docker_row "$output")
    [[ "$docker_row" == *"Images 4.2GB (1/3 in use) · Containers 12MB (0B (0%) reclaimable)"* ]] || {
        echo "$output"
        return 1
    }
}

@test "large files Docker row drops a reclaimable figure when every item is in use" {
    # Older clients count the shared layers of in-use images as reclaimable,
    # though no prune can free them while every image backs a container.
    _large_files_docker_row "$HOME/large-review-docker-shared" \
        "Images|3|3|2.8GB|1.1GB (39%)"

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    local docker_row
    docker_row=$(_docker_row "$output")
    [[ "$docker_row" == *"Images 2.8GB (3/3 in use)"* ]] || {
        echo "$output"
        return 1
    }
    [[ "$docker_row" != *"reclaimable"* ]] || {
        echo "$docker_row"
        return 1
    }
}

@test "large files Docker row keeps reclaimable figures that agree with the active counts" {
    _large_files_docker_row "$HOME/large-review-docker-classic" \
        "Images|2|0|2.5GB|2.5GB (100%)
Containers|3|1|40MB|12MB (30%)
Local Volumes|2|1|300MB|100MB (33%)
Build Cache|12|0|1.2GB|1.2GB"

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    local docker_row
    docker_row=$(_docker_row "$output")
    [[ "$docker_row" == *"Images 2.5GB (2.5GB (100%) reclaimable) · Containers 40MB (12MB (30%) reclaimable) · Local Volumes 300MB (100MB (33%) reclaimable) · Build Cache 1.2GB (1.2GB reclaimable)"* ]] || {
        echo "$output"
        return 1
    }
}

@test "external volume cleanup discards a partial metadata scan before deletion" {
    local test_home="$HOME/external-partial-scan"
    local volume="$test_home/External"
    local metadata_file="$volume/._partial"
    mkdir -p "$volume"
    touch "$metadata_file"

    run env HOME="$test_home" PROJECT_ROOT="$PROJECT_ROOT" \
        VOLUME="$volume" METADATA_FILE="$metadata_file" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"

DRY_RUN=false
PROTECT_FINDER_METADATA=true
MOLE_CURRENT_COMMAND=clean
MOLE_CLEAN_CANCEL_STATUS=0
files_cleaned=0
total_size_cleaned=0
total_items=0
probe_mode=partial
probe_status=124

start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
clean_ds_store_tree() { :; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
get_path_size_kb() { printf '1\n'; }
mktemp_file() {
    : > "$HOME/external-scan.list"
    printf '%s\n' "$HOME/external-scan.list"
}
run_with_timeout() {
    printf '%s\n' "$*" > "$HOME/find.trace"
    printf '%s\0' "$METADATA_FILE"
    if [[ "$probe_mode" == complete ]]; then
        return 0
    fi
    return "$probe_status"
}
safe_remove() {
    printf 'REMOVE:%s\n' "$1" >> "$HOME/remove.trace"
    return 0
}

for probe_status in 7 124 130; do
    MOLE_CLEAN_CANCEL_STATUS=0
    files_cleaned=0
    total_size_cleaned=0
    total_items=0
    rm -f "$HOME/remove.trace" # SAFE: exact test-owned trace file
    set +e
    clean_external_volume_target "$VOLUME" > "$HOME/partial.output" 2>&1
    partial_rc=$?
    set -e
    expected_cancel=0
    if [[ $probe_status -eq 124 || $probe_status -ge 128 ]]; then
        expected_cancel=$probe_status
    fi
    printf 'PARTIAL_RC=%s CANCEL=%s FILES=%s\n' \
        "$partial_rc" "$MOLE_CLEAN_CANCEL_STATUS" "$files_cleaned"
    [[ $partial_rc -eq $probe_status ]] || exit 1
    [[ "$MOLE_CLEAN_CANCEL_STATUS" -eq $expected_cancel ]] || exit 1
    [[ "$files_cleaned" -eq 0 ]] || exit 1
    [[ ! -e "$HOME/remove.trace" ]] || exit 1
    [[ -f "$METADATA_FILE" ]] || exit 1
done

# Positive control: a complete producer hands the same candidate to the sink.
probe_mode=complete
MOLE_CLEAN_CANCEL_STATUS=0
clean_external_volume_target "$VOLUME" > "$HOME/complete.output" 2>&1
grep -Fq "REMOVE:$METADATA_FILE" "$HOME/remove.trace" || exit 1
[[ "$files_cleaned" -eq 1 ]] || exit 1
grep -Fq "$VOLUME/.TemporaryItems" "$HOME/find.trace" || exit 1
grep -Fq "$VOLUME/.Trashes" "$HOME/find.trace" || exit 1
grep -Fq -- '-prune' "$HOME/find.trace" || exit 1
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"PARTIAL_RC=7 CANCEL=0 FILES=0"* ]] || return 1
    [[ "$output" == *"PARTIAL_RC=124 CANCEL=124 FILES=0"* ]] || return 1
    [[ "$output" == *"PARTIAL_RC=130 CANCEL=130 FILES=0"* ]] || return 1
}

@test "external volume cleanup refuses a replacement mounted during cleanup" {
    local test_home="$HOME/external-volume-swap"
    local volume="$test_home/External"
    mkdir -p "$volume/.Trashes"
    touch "$volume/.Trashes/cache.tmp"

    run env HOME="$test_home" PROJECT_ROOT="$PROJECT_ROOT" VOLUME="$volume" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"

DRY_RUN=false
PROTECT_FINDER_METADATA=true
MOLE_CURRENT_COMMAND=clean
MOLE_CLEAN_CANCEL_STATUS=0
files_cleaned=0
total_size_cleaned=0
total_items=0
volume_generation=original

start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
clean_ds_store_tree() { :; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
get_path_size_kb() { printf '1\n'; }
mktemp_file() {
    : > "$HOME/external-scan.list"
    printf '%s\n' "$HOME/external-scan.list"
}
run_with_timeout() { return 0; }
_mole_snapshot_path_identity() {
    _MOLE_PATH_SNAPSHOT_PARENT="${1%/*}"
    _MOLE_PATH_SNAPSHOT_PARENT_ID="1:1"
    _MOLE_PATH_SNAPSHOT_TARGET_ID="2:2"
}
_mole_path_matches_identity() {
    [[ "$1" != "$VOLUME" || "$volume_generation" == original ]]
}
safe_remove() {
    volume_generation=swapped
    local guard="${_MOLE_SAFE_REMOVE_FINAL_GUARD:-}"
    [[ "$guard" == "_mole_external_volume_final_guard" ]] || exit 1
    if "$guard" "$1"; then
        printf 'REMOVE:%s\n' "$1" >> "$HOME/remove.trace"
    fi
    return 1
}

clean_external_volume_target "$VOLUME"
[[ ! -e "$HOME/remove.trace" ]] || exit 1
[[ "$files_cleaned" -eq 0 ]] || exit 1
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
}

@test "external volume scan completes past root-owned metadata trees" {
    local test_home="$HOME/external-owned-volume"
    local volume="$test_home/External"
    mkdir -p "$volume/.Spotlight-V100/Store-V2" "$volume/.fseventsd" \
        "$volume/.DocumentRevisions-V100/staging" "$volume/Photos"
    touch "$volume/Photos/._IMG_0001.jpg" "$volume/.Spotlight-V100/Store-V2/._index"
    # Ownership-enabled volumes carry these as root-owned 700 directories.
    chmod 000 "$volume/.Spotlight-V100/Store-V2" "$volume/.fseventsd" \
        "$volume/.DocumentRevisions-V100/staging"

    run env HOME="$test_home" PROJECT_ROOT="$PROJECT_ROOT" VOLUME="$volume" \
        /bin/bash --noprofile --norc <<'EOF_INNER'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"

DRY_RUN=false
PROTECT_FINDER_METADATA=true
MOLE_CURRENT_COMMAND=clean
MOLE_CLEAN_CANCEL_STATUS=0
files_cleaned=0
total_size_cleaned=0
total_items=0

start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
clean_ds_store_tree() { :; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
get_path_size_kb() { printf '1\n'; }
# The sink call discards stdout, so trace to a file.
safe_remove() { printf 'REMOVE:%s\n' "$1" >> "$HOME/remove.trace"; return 0; }

# Negative control: an unpruned walk over the same tree fails on EACCES.
control_rc=0
find -P "$VOLUME" -xdev -type f -name '._*' > /dev/null 2>&1 || control_rc=$?
echo "CONTROL_FIND_RC=$control_rc"

rc=0
clean_external_volume_target "$VOLUME" || rc=$?
echo "RC=$rc CANCEL=$MOLE_CLEAN_CANCEL_STATUS FILES=$files_cleaned"
cat "$HOME/remove.trace"
EOF_INNER
    chmod 755 "$volume/.Spotlight-V100/Store-V2" "$volume/.fseventsd" \
        "$volume/.DocumentRevisions-V100/staging"

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"CONTROL_FIND_RC=1"* ]] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"RC=0 CANCEL=0 FILES=1"* ]] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"REMOVE:$volume/Photos/._IMG_0001.jpg"* ]] || return 1
    [[ "$output" != *"REMOVE:$volume/.Spotlight-V100"* ]]
}

@test "clean_trash names a Trash it cannot list instead of skipping silently" {
    local trash_home="$BATS_TEST_TMPDIR/locked-trash-home"
    mkdir -p "$trash_home/.Trash"
    touch "$trash_home/.Trash/kept.tmp"
    chmod 000 "$trash_home/.Trash"

    run env HOME="$trash_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
note_activity() { :; }
is_path_whitelisted() { return 1; }
safe_remove() { echo "REMOVE:$1"; }
for DRY_RUN in true false; do
    clean_trash
done
EOF

    chmod 700 "$trash_home/.Trash"
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [ "$(printf '%s\n' "$output" | grep -c 'Trash · skipped, grant Full Disk Access')" -eq 2 ] || return 1
    [[ "$output" != *"REMOVE:"* ]] || return 1
    [ -e "$trash_home/.Trash/kept.tmp" ]
}

@test "wallpaper cleanup offers only old renders of pictures that are not on screen" {
    local fixture_home="$HOME/wallpaper-renders"
    run env HOME="$fixture_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
clean_support_app_data() { :; }
_clean_user_log_directory() { :; }
_clean_incomplete_downloads() { :; }
safe_clean() {
    local label="${*: -1}"
    [[ "$label" == "Wallpaper agent cache" ]] || return 0
    local path
    for path in "${@:1:$#-1}"; do printf 'OFFER=%s\n' "${path##*/}"; done
}
caches="$HOME/Library/Containers/com.apple.wallpaper.agent/Data/Library/Caches"
renders="$caches/com.apple.wallpaper.caches/extension-com.apple.wallpaper.extension.image"
mkdir -p "$renders" "$caches/com.apple.wallpaper.caches/extension-com.apple.wallpaper.extension.bad..name"
echo x > "$caches/com.apple.wallpaper.caches/extension-com.apple.wallpaper.extension.bad..name/$(printf "%064d" 0 | tr 0 a)-640-480-0-1.bmp"
touch -t "$(date -v-30d +%Y%m%d%H%M)" "$caches/com.apple.wallpaper.caches/extension-com.apple.wallpaper.extension.bad..name/$(printf "%064d" 0 | tr 0 a)-640-480-0-1.bmp"
echo x > "$caches/com.apple.wallpaper.caches/extension-com.apple.wallpaper.extension.bad..name/$(printf "%064d" 0 | tr 0 f)-640-480-0-1.bmp"
pic() { printf '%064d' 0 | tr 0 "$1"; }
make() { echo x > "$renders/$1"; touch -t "$(date -v-"$2"d +%Y%m%d%H%M)" "$renders/$1"; }
make "$(pic a)-5120-2880-0-1.bmp" 30   # old, other picture: offered
make "$(pic a)-2560-1440-0-1.bmp" 30   # same old picture, other display: offered
make "$(pic c)-5120-2880-0-1.bmp" 8    # newest 5K render: on screen
make "$(pic c)-2560-1440-0-1.bmp" 40   # same picture as the 5K one: kept
make "$(pic b)-2560-1440-0-1.bmp" 9    # newest render of that size: kept
make "$(pic e)-1920-1080-0-1.bmp" 1    # too young
make "renamed-$(pic d).bmp" 40         # not a render name
echo x > "$caches/rebuildable.bin"
ln -s "$renders/$(pic a)-5120-2880-0-1.bmp" "$renders/$(pic d)-5120-2880-0-1.bmp"
clean_app_caches
EOF

    [ "$status" -eq 0 ] || return 1
    local a c
    a=$(printf '%064d' 0 | tr 0 a)
    c=$(printf '%064d' 0 | tr 0 c)
    [[ "$output" == *"OFFER=${a}-5120-2880-0-1.bmp"* ]] || return 1
    [[ "$output" == *"OFFER=${a}-2560-1440-0-1.bmp"* ]] || return 1
    [ "$(grep -c '^OFFER=' <<< "$output")" -eq 2 ] || return 1
    [[ "$output" != *"OFFER=${c}"* ]] || return 1
    [[ "$output" != *"OFFER=com.apple.wallpaper.caches"* ]] || return 1
}

@test "wallpaper render listing keeps everything on timeout and stops on a signal" {
    local fixture_home="$HOME/wallpaper-renders-status"
    run env HOME="$fixture_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
folder="$HOME/Library/Containers/com.apple.wallpaper.agent/Data/Library/Caches/com.apple.wallpaper.caches/extension-com.apple.wallpaper.extension.image"
mkdir -p "$folder"
hex=$(printf '%064d' 0 | tr 0 a)
touch "$folder/${hex}-5120-2880-0-1.bmp" "$folder/${hex//a/b}-5120-2880-0-1.bmp"
ln -s "$folder/${hex}-5120-2880-0-1.bmp" "$folder/${hex//a/d}-5120-2880-0-1.bmp"
# A partial listing that would otherwise offer one old render; the symlink
# line stands for a listing entry that is no longer a regular file.
partial() {
    printf '%s %s\n' 1 "$folder/${hex}-5120-2880-0-1.bmp" 1 "$folder/${hex//a/d}-5120-2880-0-1.bmp" \
        "$(date +%s)" "$folder/${hex//a/b}-5120-2880-0-1.bmp"
}
run_with_timeout() { partial; return 124; }
rc=0; _wallpaper_stale_render_files || rc=$?
echo "TIMEOUT rc=$rc n=${#_MOLE_WALLPAPER_RENDERS[@]}"
run_with_timeout() { partial; return 130; }
rc=0; _wallpaper_stale_render_files || rc=$?
echo "SIGNAL rc=$rc n=${#_MOLE_WALLPAPER_RENDERS[@]}"
run_with_timeout() { partial; return 0; }
rc=0; _wallpaper_stale_render_files || rc=$?
echo "COMPLETE rc=$rc n=${#_MOLE_WALLPAPER_RENDERS[@]}"

start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
clean_support_app_data() { :; }
_clean_user_log_directory() { :; }
_clean_incomplete_downloads() { :; }
safe_clean() { printf 'CLEAN=%s\n' "${*: -1}"; }
_wallpaper_stale_render_files() { return 130; }
rc=0; clean_app_caches || rc=$?
echo "SECTION rc=$rc"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"COMPLETE rc=0 n=1"* ]] || return 1
    [[ "$output" == *"TIMEOUT rc=0 n=0"* ]] || return 1
    [[ "$output" == *"SIGNAL rc=130 n=0"* ]] || return 1
    [[ "$output" == *"SECTION rc=130"* ]] || return 1
    [[ "$output" == *"CLEAN=Saved application states"* ]] || return 1
    [[ "$output" != *"CLEAN=Media analysis cache"* ]] || return 1
}

@test "wallpaper cleanup caps a backlog, keeps its own probe budget and skips unsafe listings" {
    local fixture_home="$HOME/wallpaper-renders-bounds"
    run env HOME="$fixture_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
caches="$HOME/Library/Containers/com.apple.wallpaper.agent/Data/Library/Caches"
folder="$caches/com.apple.wallpaper.caches/extension-com.apple.wallpaper.extension.image"
mkdir -p "$folder"
for i in $(seq 1 60); do
    name="$(printf '%064x' "$i")-5120-2880-0-1.bmp"
    echo x > "$folder/$name"
    touch -t "$(date -v-$((10 + i))d +%Y%m%d%H%M)" "$folder/$name"
done
newest="$(printf '%064x' 999)-5120-2880-0-1.bmp"
echo x > "$folder/$newest"
_wallpaper_stale_render_files
echo "CAPPED n=${#_MOLE_WALLPAPER_RENDERS[@]}"
oldest="$(printf '%064x' 60)-5120-2880-0-1.bmp"
printf '%s\n' "${_MOLE_WALLPAPER_RENDERS[@]}" | grep -q "/$oldest\$" && echo "OLDEST_OFFERED"

# Each render costs one handle probe; the section budget stays untouched.
_MOLE_CONTAINER_CACHE_PROBE_DEADLINE=""
safe_clean() {
    if [[ "${*: -1}" == "Wallpaper agent cache" ]]; then
        [[ -n "${_MOLE_CONTAINER_CACHE_PROBE_DEADLINE+x}" ]] && _MOLE_CONTAINER_CACHE_PROBE_DEADLINE=spent
    fi
}
_clean_wallpaper_renders
echo "SECTION_BUDGET=[${_MOLE_CONTAINER_CACHE_PROBE_DEADLINE}]"

# A listing larger than the cap cannot show which picture is newest. Without
# the cap check the real old render below would be offered.
(
    run_with_timeout() {
        local i
        for i in $(seq 1 20001); do printf '2 %s/%s\n' "$folder" "$(printf '%064x' "$i")-640-480-0-1.bmp"; done
        printf '1 %s/%s\n%s %s/%s\n' "$folder" "$oldest" "$(date +%s)" "$folder" "$newest"
    }
    _wallpaper_stale_render_files
    echo "OVERCAP n=${#_MOLE_WALLPAPER_RENDERS[@]}"
)

mv "$caches/com.apple.wallpaper.caches" "$HOME/real-caches"
ln -s "$HOME/real-caches" "$caches/com.apple.wallpaper.caches"
declare -f run_with_timeout > /dev/null || exit 1
_wallpaper_stale_render_files
echo "SYMLINK n=${#_MOLE_WALLPAPER_RENDERS[@]}"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"CAPPED n=50"* ]] || return 1
    [[ "$output" == *"OLDEST_OFFERED"* ]] || return 1
    [[ "$output" == *"SECTION_BUDGET=[]"* ]] || return 1
    [[ "$output" == *"OVERCAP n=0"* ]] || return 1
    [[ "$output" == *"SYMLINK n=0"* ]] || return 1
}
