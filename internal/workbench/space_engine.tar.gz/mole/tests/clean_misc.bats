#!/usr/bin/env bats

load helpers/common

setup_file() {
    mole_test_setup_home clean-extras

    # Prevent AppleScript permission dialogs during tests
    MOLE_TEST_MODE=1
    export MOLE_TEST_MODE

    mkdir -p "$HOME"
}

teardown_file() {
    mole_test_teardown_home
}

@test "clean_cloud_storage calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
safe_clean() { echo "$2"; }
clean_cloud_storage
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Dropbox cache"* ]] || return 1
    [[ "$output" == *"Google Drive cache"* ]]
}

@test "clean_virtualization_tools hits cache paths" {
    mkdir -p "$HOME/Library/Caches/com.utmapp.UTM"
    printf cache > "$HOME/Library/Caches/com.utmapp.UTM/blob"
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
pgrep() { return 1; }
safe_clean() { echo "$2|$1"; }
clean_virtualization_tools
EOF

    rm -rf "$HOME/Library/Caches/com.utmapp.UTM"
    [ "$status" -eq 0 ]
    [[ "$output" == *"VMware Fusion cache"* ]] || return 1
    [[ "$output" == *"Parallels cache"* ]] || return 1
    [[ "$output" == *"UTM app cache|$HOME/Library/Caches/com.utmapp.UTM/"* ]] || return 1
    [[ "$output" == *"UTM sandbox cache|$HOME/Library/Containers/com.utmapp.UTM/Data/Library/Caches/"* ]] || return 1
    [[ "$output" == *"UTM temporary files|$HOME/Library/Containers/com.utmapp.UTM/Data/tmp/"* ]]
}

@test "clean_virtualization_tools skips UTM caches while UTM is running" {
    mkdir -p "$HOME/Library/Caches/com.utmapp.UTM"
    printf cache > "$HOME/Library/Caches/com.utmapp.UTM/blob"
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
debug_log() { :; }
pgrep() {
    [[ "${1:-}" == "-x" && "${2:-}" == "UTM" ]]
}
safe_clean() { echo "$2"; }
clean_virtualization_tools
EOF

    rm -rf "$HOME/Library/Caches/com.utmapp.UTM"
    [ "$status" -eq 0 ]
    [[ "$output" == *"VMware Fusion cache"* ]] || return 1
    [[ "$output" == *"Parallels cache"* ]] || return 1
    [[ "$output" != *"UTM app cache"* ]] || return 1
    [[ "$output" != *"UTM sandbox cache"* ]]
}

@test "clean_email_clients calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_email_clients
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Spark cache"* ]] || return 1
    [[ "$output" == *"Airmail cache"* ]]
}

@test "clean_virtualization_tools includes Lima download cache" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
stop_section_spinner() { :; }
safe_clean() { echo "$2|$1"; }
clean_virtualization_tools
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Lima download cache|$HOME/Library/Caches/lima/download/by-url-sha256/"* ]]
}

@test "clean_tart_caches runs only the native cache-only age prune" {
    rm -rf "$HOME/.tart" "$HOME/tart-args" "$HOME/tart-payload"
    mkdir -p "$HOME/.tart/cache/OCIs"
    : > "$HOME/tart-payload"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
debug_log() { :; }
pgrep() { return 1; }
is_path_whitelisted() { return 1; }
get_path_size_kb() { [[ -e "$HOME/tart-payload" ]] && echo 4096 || echo 1024; }
bytes_to_human() { echo "$1 bytes"; }
run_with_timeout() { shift; "$@"; }
tart() {
    printf '%s\n' "$*" > "$HOME/tart-args"
    rm -f "$HOME/tart-payload"
}
clean_tart_caches
EOF

    [ "$status" -eq 0 ]
    [ "$(< "$HOME/tart-args")" = "prune --entries caches --older-than 30" ] || return 1
    [[ "$output" == *"Tart caches · pruned"* ]] || return 1
    [[ "$output" != *"--entries vms"* ]] || return 1
}

@test "clean_tart_caches stops when the native prune is interrupted" {
    # Ctrl-C while `tart prune` holds the terminal reaches only the child. A
    # signal stops cleanup before the size recount; a plain failure or a
    # timeout is a reported prune failure and cleanup continues.
    local prune_status case_home
    for prune_status in 130 143 1 124; do
        case_home="$HOME/tart-prune-$prune_status"
        mkdir -p "$case_home/.tart/cache/OCIs"
        rm -f "$case_home/size-calls" # SAFE: test scratch file under the temporary HOME

        run env HOME="$case_home" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false \
            MOLE_CURRENT_COMMAND=clean MOLE_CLEAN_CANCEL_STATUS=0 PRUNE_STATUS="$prune_status" \
            /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
debug_log() { :; }
pgrep() { return 1; }
is_path_whitelisted() { return 1; }
get_path_size_kb() { echo size >> "$HOME/size-calls"; echo 4096; }
bytes_to_human() { echo "$1 bytes"; }
run_with_timeout() { shift; "$@"; }
tart() { return "$PRUNE_STATUS"; }
rc=0
clean_tart_caches || rc=$?
size_calls=$(wc -l < "$HOME/size-calls" | tr -d ' ')
printf 'RC=%s CANCEL=%s SIZE_CALLS=%s\n' "$rc" "$MOLE_CLEAN_CANCEL_STATUS" "$size_calls"
EOF

        [ "$status" -eq 0 ] || { echo "$output"; return 1; }
        case "$prune_status" in
            130 | 143)
                [[ "$output" == *"RC=$prune_status CANCEL=$prune_status SIZE_CALLS=1"* ]] || { echo "$output"; return 1; }
                [[ "$output" != *"prune failed"* ]] || { echo "$output"; return 1; }
                ;;
            *)
                [[ "$output" == *"RC=0 CANCEL=0 SIZE_CALLS=1"* ]] || { echo "$output"; return 1; }
                [[ "$output" == *"Tart caches · prune failed"* ]] || { echo "$output"; return 1; }
                ;;
        esac
    done
}

@test "clean_tart_caches dry-run shows size, policy, and exact command without execution" {
    rm -rf "$HOME/.tart" "$HOME/tart-called"
    mkdir -p "$HOME/.tart/cache/IPSWs"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
note_activity() { :; }
pgrep() { return 1; }
is_path_whitelisted() { return 1; }
get_path_size_kb() { echo 2048; }
bytes_to_human() { echo "2MB"; }
tart() { : > "$HOME/tart-called"; }
clean_tart_caches
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"would prune items older than 30 days (2MB)"* ]] || return 1
    [[ "$output" == *"tart prune --entries caches --older-than 30"* ]] || return 1
    [ ! -e "$HOME/tart-called" ] || return 1
}

@test "clean_tart_caches skips active and whitelisted caches" {
    rm -rf "$HOME/.tart"
    mkdir -p "$HOME/.tart/cache/OCIs"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
note_activity() { :; }
pgrep() { [[ "$1" == "-x" && "$2" == "tart" ]]; }
is_path_whitelisted() { return 1; }
get_path_size_kb() { echo 1024; }
bytes_to_human() { echo "1MB"; }
tart() { echo "TART_CALLED"; }
clean_tart_caches
EOF

    [ "$status" -eq 0 ]
    [[ "$output" != *"skipped (Tart running)"* ]] || return 1
    [[ "$output" != *"TART_CALLED"* ]] || return 1

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=true /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
note_activity() { :; }
is_path_whitelisted() { [[ "$1" == "$HOME/.tart/cache" ]]; }
get_path_size_kb() { echo 1024; }
tart() { echo "TART_CALLED"; }
clean_tart_caches
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"would skip (whitelist)"* ]] || return 1
    [[ "$output" != *"TART_CALLED"* ]] || return 1
}

@test "clean_tart_caches fails closed when its process probe errors" {
    rm -rf "$HOME/.tart" "$HOME/tart-called"
    mkdir -p "$HOME/.tart/cache/OCIs"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
pgrep() { return 2; }
is_path_whitelisted() { return 1; }
get_path_size_kb() { echo 1024; }
note_activity() { :; }
tart() { : > "$HOME/tart-called"; }
clean_tart_caches
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"Tart caches · skipped (process state unknown)"* ]] || return 1
    [ ! -e "$HOME/tart-called" ]
}

@test "clean_tart_caches rechecks activity before native prune" {
    rm -rf "$HOME/.tart" "$HOME/tart-called" "$HOME/tart-probes"
    mkdir -p "$HOME/.tart/cache/OCIs"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
pgrep() {
    printf 'probe\n' >> "$HOME/tart-probes"
    [[ $(wc -l < "$HOME/tart-probes" | tr -d ' ') -ge 2 ]]
}
is_path_whitelisted() { return 1; }
get_path_size_kb() { echo 1024; }
note_activity() { :; }
defer_cleanup_family() { echo "DEFER:$1"; }
tart() { : > "$HOME/tart-called"; }
clean_tart_caches
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"DEFER:Tart"* ]] || return 1
    [ ! -e "$HOME/tart-called" ]
}

@test "clean_tart_caches reports native prune failure without claiming success" {
    rm -rf "$HOME/.tart"
    mkdir -p "$HOME/.tart/cache/OCIs"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
start_section_spinner() { :; }
stop_section_spinner() { :; }
note_activity() { :; }
debug_log() { :; }
pgrep() { return 1; }
is_path_whitelisted() { return 1; }
get_path_size_kb() { echo 1024; }
bytes_to_human() { echo "1MB"; }
run_with_timeout() { shift; "$@"; }
tart() { return 7; }
clean_tart_caches
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Tart caches · prune failed"* ]] || return 1
    [[ "$output" != *"Tart caches · pruned"* ]] || return 1
}

@test "clean_tart_caches is silent without Tart or a cache" {
    rm -rf "$HOME/.tart"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" DRY_RUN=false PATH="/usr/bin:/bin" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/user.sh"
clean_tart_caches
mkdir -p "$HOME/.tart/cache/OCIs"
clean_tart_caches
EOF

    [ "$status" -eq 0 ]
    [ -z "$output" ] || return 1
}

@test "clean_note_apps calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_note_apps
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Notion cache"* ]] || return 1
    [[ "$output" == *"Obsidian cache"* ]]
}

@test "clean_task_apps calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_task_apps
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Todoist cache"* ]] || return 1
    [[ "$output" == *"Any.do cache"* ]]
}

@test "clean_video_tools calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_video_tools
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"ScreenFlow cache"* ]] || return 1
    [[ "$output" == *"Final Cut Pro cache"* ]]
}

@test "clean_video_players calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_video_players
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"IINA cache"* ]] || return 1
    [[ "$output" == *"VLC cache"* ]]
}

@test "clean_3d_tools calls expected caches" {
    # Autodesk is only swept when a cache tree exists (#1390 made the row
    # conditional on real targets), so the fixture has to provide one or the
    # assertion below passes on an empty glob and proves nothing.
    mkdir -p "$HOME/Library/Caches/com.autodesk.AcCoreConsole"
    touch "$HOME/Library/Caches/com.autodesk.AcCoreConsole/Cache.db"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
# Autodesk moved behind the live-owner guard in #1390, so a case that only
# stubs safe_clean would silently stop seeing its row. Supply the guarded
# path too, and an empty process table so the verdict does not depend on
# whether Fusion happens to be running here.
pgrep() { return 1; }
ps() { printf '  PID  PPID COMM ARGS\n'; }
safe_clean() { echo "$2"; }
safe_clean_guarded() {
    local guard="$1"
    shift
    "$guard" || return 75
    local count=$#
    echo "${!count}"
}
clean_3d_tools
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Blender cache"* ]] || return 1
    [[ "$output" == *"Cinema 4D cache"* ]] || return 1
    [[ "$output" == *"Autodesk cache"* ]] || return 1
}

@test "clean_gaming_platforms calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_gaming_platforms
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Steam cache"* ]] || return 1
    [[ "$output" == *"Epic Games cache"* ]]
}

@test "clean_translation_apps calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_translation_apps
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Youdao Dictionary cache"* ]] || return 1
    [[ "$output" == *"Eudict cache"* ]]
}

@test "clean_launcher_apps calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_launcher_apps
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Alfred cache"* ]] || return 1
    [[ "$output" == *"The Unarchiver cache"* ]]
}

@test "clean_remote_desktop calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_remote_desktop
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"TeamViewer cache"* ]] || return 1
    [[ "$output" == *"AnyDesk cache"* ]]
}

@test "clean_system_utils calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_system_utils
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Input Source Pro cache"* ]] || return 1
    [[ "$output" == *"WakaTime cache"* ]]
}

@test "clean_shell_utils calls expected caches" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/clean/app_caches.sh"
safe_clean() { echo "$2"; }
clean_shell_utils
EOF

    [ "$status" -eq 0 ]
    [[ "$output" == *"Zsh completion cache"* ]] || return 1
    [[ "$output" == *"wget HSTS cache"* ]]
}
