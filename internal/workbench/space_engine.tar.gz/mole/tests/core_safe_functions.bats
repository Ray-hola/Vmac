#!/usr/bin/env bats

load helpers/common

setup_file() {
    mole_test_setup_home safe-functions
}

teardown_file() {
    mole_test_teardown_home
}

setup() {
    # Safety: refuse to operate on a real home directory.
    if [[ "$HOME" != "${BATS_TEST_DIRNAME}/tmp-"* ]]; then
        printf 'FATAL: HOME is not a test temp dir: %s\n' "$HOME" >&2
        return 1
    fi
    source "$PROJECT_ROOT/lib/core/common.sh"
    TEST_DIR="$HOME/test_safe_functions"
    mkdir -p "$TEST_DIR"
}

teardown() {
    rm -rf "$TEST_DIR"
}

# Exercise production guards and sinks with only lsof's response scripted.
# Each case gets a separate home, and the later ordinary file is independently
# removable, so a preserved file cannot mask a sticky-cancellation regression.
check_handle_probe_outcome() {
    local kind="$1" scripted_rc="$2" stage="$3" dry_run="${4:-0}"
    local fixture="$TEST_DIR/probe-$kind-$scripted_rc-$stage-$dry_run"
    mkdir -p "$fixture"
    run env HOME="$fixture" PROJECT_ROOT="$PROJECT_ROOT" kind="$kind" \
        scripted_rc="$scripted_rc" stage="$stage" MOLE_DRY_RUN="$dry_run" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/bin/clean.sh"
[[ "$MOLE_DRY_RUN" == 0 ]] || DRY_RUN=true
case "$kind" in
    download) target="$HOME/Downloads/first.crdownload" ;;
    container) target="$HOME/Library/Containers/com.example.Probe/Data/Library/Caches/First" ;;
    group) target="$HOME/Library/Group Containers/TEAM.com.example.probe/Library/Caches/first.log" ;;
esac
mkdir -p "$(dirname "$target")"
if [[ "$kind" == container ]]; then
    mkdir -p "$target"
    printf 'keep\n' > "$target/state"
else
    printf 'keep\n' > "$target"
fi
next="$HOME/next.log"
printf 'later\n' > "$next"
: > "$HOME/probes"
: > "$HOME/sinks"
: > "$HOME/previews"
MOLE_CURRENT_COMMAND=clean
MOLE_CLEAN_CANCEL_STATUS=0
_mole_user_cache_owner_process_state() { return 1; }
[[ "$stage" == visibility ]] || _MOLE_COMPLETE_LSOF_MODE=direct
lsof() {
    printf '%s\n' "$*" >> "$HOME/probes"
    # Return a genuinely idle result until sizing completes in the final case.
    if [[ "$stage" == final && ! -f "$HOME/sized" ]]; then
        return 1
    fi
    return "$scripted_rc"
}
run_with_timeout() { shift; "$@"; }
oplog_enabled() { return 0; }
get_path_size_kb() { touch "$HOME/sized"; printf '1\n'; }
rm() {
    printf '%s\n' "$*" >> "$HOME/sinks"
    command rm "$@" # SAFE: production safe_remove validates isolated fixture paths before this mock
}
register_dry_run_cleanup_target() { printf '%s\n' "$*" >> "$HOME/previews"; }
first_rc=0
safe_remove "$target" true || first_rc=$?
second_rc=0
safe_remove "$next" true 1 || second_rc=$?
printf 'CASE=%s/%s/%s DRY=%s\n' "$kind" "$scripted_rc" "$stage" "$MOLE_DRY_RUN"
printf 'FIRST=%s SECOND=%s CANCEL=%s TARGET=%s NEXT=%s\n' \
    "$first_rc" "$second_rc" "$MOLE_CLEAN_CANCEL_STATUS" \
    "$(test -e "$target" && echo kept || echo removed)" \
    "$(test -e "$next" && echo kept || echo removed)"
[[ -s "$HOME/probes" ]] || exit 1
if [[ "$stage" == visibility ]]; then
    grep -q -- '-F pu -p 1' "$HOME/probes" || exit 1
else
    grep -qF -- "$target" "$HOME/probes" || exit 1
fi
if [[ "$stage" == final ]]; then
    [[ -f "$HOME/sized" ]] || exit 1
fi
if [[ "$MOLE_DRY_RUN" == 1 ]]; then
    [[ ! -s "$HOME/sinks" ]] || exit 1
    grep -qF -- "$next" "$HOME/previews" || exit 1
    if grep -qF -- "$target" "$HOME/previews"; then exit 1; fi
elif [[ "$scripted_rc" == 124 ]]; then
    grep -qF -- "$next" "$HOME/sinks" || exit 1
    if grep -qF -- "$target" "$HOME/sinks"; then exit 1; fi
else
    [[ ! -s "$HOME/sinks" ]] || exit 1
fi
EOF
    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    if [[ "$scripted_rc" == 124 ]]; then
        local next_state=removed
        [[ "$dry_run" == 0 ]] || next_state=kept
        [[ "$output" == *"FIRST=1 SECOND=0 CANCEL=0 TARGET=kept NEXT=$next_state"* ]] || { echo "$output"; return 1; }
    else
        [[ "$output" == *"FIRST=$scripted_rc SECOND=$scripted_rc CANCEL=$scripted_rc TARGET=kept NEXT=kept"* ]] || { echo "$output"; return 1; }
    fi
}

@test "validate_path_for_deletion rejects empty path" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion ''"
    [ "$status" -eq 1 ]
}

@test "validate_path_for_deletion rejects relative path" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion 'relative/path'"
    [ "$status" -eq 1 ]
}

@test "validate_path_for_deletion rejects path traversal" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/tmp/../etc'"
    [ "$status" -eq 1 ]

    # Test other path traversal patterns
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/var/log/../../etc'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$TEST_DIR/..'"
    [ "$status" -eq 1 ]
}

@test "validate_path_for_deletion accepts Firefox-style ..files directories" {
    # Firefox uses ..files suffix in IndexedDB directory names
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$TEST_DIR/2753419432nreetyfallipx..files'"
    [ "$status" -eq 0 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$TEST_DIR/storage/default/https+++www.netflix.com/idb/name..files/data'"
    [ "$status" -eq 0 ]

    # Directories with .. in the middle of names should be allowed
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$TEST_DIR/test..backup/file.txt'"
    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion rejects system directories" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/System'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/usr/bin'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/etc'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/Library/Apple'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/Applications/Finder.app'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/Users'"
    [ "$status" -eq 1 ]
}

@test "validate_path_for_deletion rejects aliased critical paths" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '//etc/passwd'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '///System'"
    [ "$status" -eq 1 ]
}

@test "validate_path_for_deletion rejects a target whose ancestor symlink redirects into a critical path" {
    # The deny list and the -L check both look at the literal string / leaf, so
    # a symlinked ANCESTOR used to slip through: the policy path looked like an
    # ordinary cache dir while rm followed the link into the real tree.
    local fake_caches="$TEST_DIR/redirected-Caches"
    ln -s /System "$fake_caches"

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$fake_caches/Library/Caches/victim'"
    [ "$status" -eq 1 ]
    [[ "$output" == *"resolves into a critical system path"* ]] || return 1
}

@test "validate_path_for_deletion rejects a target whose ancestor symlink redirects into protected user data" {
    local protected_home="$TEST_DIR/home"
    mkdir -p "$protected_home/Library/Keychains"
    local fake_cache_root="$TEST_DIR/cache-root"
    ln -s "$protected_home/Library" "$fake_cache_root"

    # should_protect_path is home-relative, so drive it against a fake HOME.
    run /bin/bash -c "export HOME='$protected_home'; source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$fake_cache_root/Keychains/login.keychain-db'"
    [ "$status" -eq 1 ]
}

@test "validate_path_for_deletion still accepts an ordinary path under a real directory" {
    # The ancestor guard is deny-only: it must not reject legitimate targets
    # whose ancestors merely resolve (e.g. /tmp -> /private/tmp on macOS).
    mkdir -p "$TEST_DIR/real/Caches"
    : > "$TEST_DIR/real/Caches/cache.txt"

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$TEST_DIR/real/Caches/cache.txt'"
    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion accepts valid path" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$TEST_DIR/valid'"
    [ "$status" -eq 0 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$HOME/Library/Caches/com.example.app/cache.db'"
    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion allows protected input-method names in Trash (#1517)" {
    # The verdict is string-based on HOME. The test HOME lives inside the
    # checkout, and a checkout under /private/tmp hits the temp-root allowlist
    # before the protection check, so use a synthetic home outside every
    # allowlisted root. Nothing is created there.
    local home="/Users/mole-test-home-1517"

    run env HOME="$home" /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$home/.Trash/com.sogou.inputmethod.sogou.plist'"
    [ "$status" -eq 0 ]

    run env HOME="$home" /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$home/.Trash/com.tencent.inputmethod.QQInput.plist'"
    [ "$status" -eq 0 ]

    run env HOME="$home" /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$home/Library/Preferences/com.sogou.inputmethod.sogou.plist'"
    [ "$status" -eq 1 ]
}

@test "validate_path_for_deletion rejects temp roots while allowing their children" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/private/tmp'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/private/var/tmp'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/private/var/folders'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/dev'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/private/tmp/mole-old-artifact'"
    [ "$status" -eq 0 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/private/var/tmp/mole-old-artifact'"
    [ "$status" -eq 0 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/private/var/folders/test/a/C/com.example.App/cache'"
    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion rejects case aliases of critical roots" {
    run /bin/bash -c "
        source '$PROJECT_ROOT/lib/core/common.sh'
        checked=0
        for pair in \
            '/SYSTEM|/System' \
            '/DEV|/dev' \
            '/PRIVATE/TMP|/private/tmp' \
            '/PRIVATE/VAR/FOLDERS|/private/var/folders' \
            '/USERS|/Users'; do
            alias_path=\${pair%%|*}
            canonical_path=\${pair#*|}
            if [[ -e \"\$alias_path\" && \"\$alias_path\" -ef \"\$canonical_path\" ]]; then
                checked=\$((checked + 1))
                validate_path_for_deletion \"\$alias_path\" && exit 90
            fi
        done
        [[ \$checked -gt 0 ]] || return 1
    "
    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion accepts CoreSimulator system cache children" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/Library/Developer/CoreSimulator/Caches/dyld'"
    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion allows Darwin C cache shards but rejects protected extension paths" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/private/var/folders/test/a/C/com.example.App/com.apple.metal'"
    [ "$status" -eq 0 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/Library/Extensions/com.example.driver/com.apple.metal' 2>&1"
    [ "$status" -eq 1 ]
    [[ "$output" == *"critical system path"* ]]
}

@test "validate_path_for_deletion rejects endpoint-security agent var/folders caches" {
    # Central chokepoint: every safe_remove / safe_sudo_remove caller is covered,
    # not only the cleanup sweeps that pre-check the predicate.
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/private/var/folders/9d/abc/C/com.crowdstrike.falcon.App/com.apple.metalfe'"
    [ "$status" -eq 1 ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/PRIVATE/VAR/FOLDERS/9D/ABC/C/COM.CROWDSTRIKE.FALCON.APP/com.apple.metalfe'"
    [ "$status" -eq 1 ]

    # A normal app's Darwin cache shard stays deletable.
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/private/var/folders/9d/abc/C/com.example.App/com.apple.metalfe'"
    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion rejects the active powerlog database family" {
    local db="/private/var/db/powerlog/Library/PerfPowerTelemetry/BackgroundProcessing/CurrentBackgroundProcessingDB.BGSQL"
    local path=""

    for path in "$db" "$db-wal" "$db-shm" "${db%/*}/./${db##*/}" "${db%/*}/currentbackgroundprocessingdb.bgsql"; do
        run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$path'"
        [ "$status" -eq 1 ] || return 1
    done

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '/private/var/db/powerlog/Library/PerfPowerTelemetry/BackgroundProcessing/ArchivedBackgroundProcessingDB.BGSQL'"
    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion rejects the live database of every power telemetry store" {
    local root="/private/var/db/powerlog/Library/PerfPowerTelemetry"
    local xcode_db="$root/XcodeOrganizer/CurrentXcodeOrganizerDB.XCSQL"
    local path=""

    # A user's operations.log showed the Xcode Organizer store removed as a
    # 7-day-old file; mtime never proves PerfPowerServices closed it.
    for path in "$xcode_db" "$xcode_db-wal" "$xcode_db-shm" \
        "$root/ExtendedPersistence/CurrentExtendedPersistenceDB.EPSQL" \
        "/private/var/db/powerlog/library/perfpowertelemetry/XcodeOrganizer/CurrentXcodeOrganizerDB.XCSQL"; do
        run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$path'"
        [ "$status" -eq 1 ] || {
            echo "accepted: $path"
            return 1
        }
    done

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$root/XcodeOrganizer/ArchivedXcodeOrganizerDB.XCSQL'"
    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion refuses a live SQLite database family (#1390)" {
    local db="$TEST_DIR/live-sqlite/Cache.db"
    mkdir -p "$(dirname "$db")"
    printf 'db' > "$db"
    printf 'wal' > "$db-wal"
    printf 'shm' > "$db-shm"

    for path in "$db" "$db-wal" "$db-shm"; do
        run env PROJECT_ROOT="$PROJECT_ROOT" path="$path" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 0; }
run_with_timeout() { shift; "$@"; }
validate_path_for_deletion "$path"
EOF
        [ "$status" -eq 1 ] || return 1
    done
}

@test "validate_path_for_deletion refuses an SQLite database held open by a process (#1390)" {
    local db="$TEST_DIR/open-sqlite/Cache.db"
    mkdir -p "$(dirname "$db")"
    printf 'db' > "$db"

    run env PROJECT_ROOT="$PROJECT_ROOT" db="$db" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 0; }
run_with_timeout() { shift; "$@"; }
validate_path_for_deletion "$db"
EOF

    [ "$status" -eq 1 ]
}

@test "validate_path_for_deletion allows an idle SQLite cache database (#1390)" {
    local db="$TEST_DIR/idle-sqlite/Cache.db"
    mkdir -p "$(dirname "$db")"
    printf 'db' > "$db"

    run env PROJECT_ROOT="$PROJECT_ROOT" db="$db" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() { shift; "$@"; }
validate_path_for_deletion "$db"
EOF

    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion allows stale SQLite -shm files (#1439)" {
    local db="$TEST_DIR/stale-sqlite/Cache.db"
    mkdir -p "$(dirname "$db")"
    printf 'db' > "$db"
    printf 'shm' > "$db-shm"

    for path in "$db" "$db-shm"; do
        run env PROJECT_ROOT="$PROJECT_ROOT" path="$path" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() { shift; "$@"; }
validate_path_for_deletion "$path"
EOF
        [ "$status" -eq 0 ] || return 1
    done
}

@test "validate_path_for_deletion refuses a SQLite cache directory when lsof is inconclusive (#1439)" {
    local cache_dir="$HOME/Library/Caches/com.example.UnknownSQLite"
    local db="$cache_dir/Cache.db"
    mkdir -p "$cache_dir"
    printf 'db' > "$db"
    printf 'shm' > "$db-shm"

    run env PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() { return 124; }
validation_rc=0
validate_path_for_deletion "$cache_dir" || validation_rc=$?
printf 'RC=%s\n' "$validation_rc"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == "RC=1" ]]
}

@test "validate_path_for_deletion checks every supported SQLite name inside a cache directory (#1439)" {
    local filename=""
    for filename in state.sqlite state.sqlite3 STATE.SQLITE .hidden.sqlite; do
        local cache_dir="$HOME/Library/Caches/com.example.${filename//[^A-Za-z0-9]/_}"
        mkdir -p "$cache_dir"
        printf 'db' > "$cache_dir/$filename"

        run env PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 0; }
run_with_timeout() { shift; "$@"; }
validate_path_for_deletion "$cache_dir"
EOF

        [ "$status" -eq 1 ] || return 1
    done
}

@test "SQLite cache directory guard isolates caller nullglob and failglob on Bash 3.2 (#1439)" {
    local cache_dir="$HOME/Library/Caches/com.example.EmptySQLite"
    mkdir -p "$cache_dir"

    run env PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
shopt -s nullglob failglob
validate_path_for_deletion "$cache_dir"
shopt -q nullglob
shopt -q failglob
EOF

    [ "$status" -eq 0 ]
}

@test "SQLite cache directory guard ignores and restores caller GLOBIGNORE (#1439)" {
    local cache_dir="$HOME/Library/Caches/com.example.GlobIgnoreSQLite"
    mkdir -p "$cache_dir"
    printf 'db' > "$cache_dir/state.db"

    run env PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 0; }
run_with_timeout() { shift; "$@"; }
export GLOBIGNORE='*.db'
validation_state=0
validate_path_for_deletion "$cache_dir" || validation_state=$?
# Every assertion exits explicitly. `set -e` does NOT abort a script bash reads
# from stdin, which is exactly how this heredoc is fed, so a bare `[[ ... ]]`
# here is decorative: it fails, execution continues, and the test still passes.
[[ $validation_state -eq 1 ]] || exit 1
[[ "$GLOBIGNORE" == '*.db' ]] || exit 1
[[ "$(declare -p GLOBIGNORE)" == 'declare -x GLOBIGNORE='* ]] || exit 1
shopt -q dotglob || exit 1
EOF

    [ "$status" -eq 0 ]
}

@test "SQLite cache directory guard probes each database family once (#1439)" {
    local cache_dir="$HOME/Library/Caches/com.example.OneSQLiteFamily"
    local db="$cache_dir/Cache.db"
    mkdir -p "$cache_dir"
    printf 'db' > "$db"
    printf 'wal' > "$db-wal"
    printf 'shm' > "$db-shm"

    run env PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
# Counted through a file, not a variable: the probe reads lsof's stdout, so it
# runs inside a command substitution and a subshell counter never comes back.
lsof_log=$(mktemp)
lsof() { printf 'call\n' >> "$lsof_log"; return 1; }
run_with_timeout() { shift; "$@"; }
guard_state=0
_mole_should_refuse_live_user_cache_path "$cache_dir" || guard_state=$?
[[ $guard_state -eq 1 ]] || exit 1
# One call for the whole Cache.db / -wal / -shm family. If family dedup breaks,
# each member is probed as its own family and this becomes 3.
lsof_calls=$(wc -l < "$lsof_log" | tr -d ' ')
rm -f "$lsof_log"
[[ $lsof_calls -eq 1 ]] || exit 1
EOF

    [ "$status" -eq 0 ]
}

@test "validate_path_for_deletion requires complete lsof visibility for incomplete downloads (#1471)" {
    local partial="$HOME/Downloads/session.crdownload"
    mkdir -p "$(dirname "$partial")"
    printf 'partial\n' > "$partial"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" partial="$partial" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
trace_file=$(mktemp)
lsof() {
    case " $* " in
        *" -p 1 "*) printf 'visibility\n' >> "$trace_file"; return 1 ;;
        *) printf 'target\n' >> "$trace_file"; return 1 ;;
    esac
}
run_with_timeout() { shift; "$@"; }
validation_rc=0
validate_path_for_deletion "$partial" || validation_rc=$?
printf 'RC=%s TRACE=%s\n' "$validation_rc" "$(tr '\n' ',' < "$trace_file")"
command rm -f "$trace_file"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 TRACE=visibility,"* ]]
}

@test "validate_path_for_deletion gates Homebrew partial downloads on lsof too (#1594)" {
    local partial="$HOME/Library/Caches/Homebrew/downloads/abc123--Some App.dmg.incomplete"
    mkdir -p "$(dirname "$partial")"
    printf 'partial\n' > "$partial"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" partial="$partial" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
trace_file=$(mktemp)
lsof() {
    case " $* " in
        *" -p 1 "*) printf 'visibility\n' >> "$trace_file"; return 1 ;;
        *) printf 'target\n' >> "$trace_file"; return 1 ;;
    esac
}
run_with_timeout() { shift; "$@"; }
validation_rc=0
validate_path_for_deletion "$partial" || validation_rc=$?
printf 'RC=%s TRACE=%s\n' "$validation_rc" "$(tr '\n' ',' < "$trace_file")"
command rm -f "$trace_file"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 TRACE=visibility,"* ]]
}

@test "a finished Homebrew download is not treated as a partial (#1594)" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
brew="$HOME/Library/Caches/Homebrew/downloads"
# The gate covers in-flight transfers only; a completed artifact and a nested
# path stay ordinary cache so the sweep keeps reclaiming them.
_mole_is_incomplete_download_path "$brew/abc--App.dmg.incomplete" && echo "INCOMPLETE:yes"
_mole_is_incomplete_download_path "$brew/abc--App.dmg" || echo "FINISHED:no"
_mole_is_incomplete_download_path "$brew/nested/abc--App.dmg.incomplete" || echo "NESTED:no"
_mole_is_incomplete_download_path "$HOME/Downloads/pending.crdownload" && echo "BROWSER:yes"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"INCOMPLETE:yes"* ]] || return 1
    [[ "$output" == *"FINISHED:no"* ]] || return 1
    [[ "$output" == *"NESTED:no"* ]] || return 1
    [[ "$output" == *"BROWSER:yes"* ]]
}

@test "complete lsof mode accepts only a root-owned pid 1 record (#1471)" {
    local record_state
    for record_state in root nonroot; do
        run env PROJECT_ROOT="$PROJECT_ROOT" record_state="$record_state" \
            /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
lsof() {
    printf 'p1\n'
    if [[ "$record_state" == "root" ]]; then
        printf 'u0\n'
    else
        printf 'u501\n'
    fi
}
run_with_timeout() { shift; "$@"; }
mode_rc=0
_mole_complete_lsof_mode || mode_rc=$?
printf 'RECORD=%s RC=%s MODE=%s\n' "$record_state" "$mode_rc" \
    "${_MOLE_COMPLETE_LSOF_MODE:-unset}"
EOF

        [ "$status" -eq 0 ] || return 1
        if [[ "$record_state" == "root" ]]; then
            [[ "$output" == *"RECORD=root RC=0 MODE=direct"* ]] || return 1
        else
            [[ "$output" == *"RECORD=nonroot RC=2 MODE=unknown"* ]] || return 1
        fi
    done
}

@test "validate_path_for_deletion distinguishes idle and active incomplete downloads (#1471)" {
    local partial="$HOME/Downloads/session.part"
    mkdir -p "$(dirname "$partial")"
    printf 'partial\n' > "$partial"

    local lsof_state
    for lsof_state in idle active; do
        run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" partial="$partial" \
            lsof_state="$lsof_state" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() {
    [[ "$lsof_state" == "active" ]] && printf 'n%s\n' "$partial"
    [[ "$lsof_state" == "active" ]]
}
run_with_timeout() { shift; "$@"; }
validation_rc=0
validate_path_for_deletion "$partial" || validation_rc=$?
printf 'STATE=%s RC=%s\n' "$lsof_state" "$validation_rc"
EOF

        [ "$status" -eq 0 ] || return 1
        if [[ "$lsof_state" == "idle" ]]; then
            [[ "$output" == *"STATE=idle RC=0"* ]] || return 1
        else
            [[ "$output" == *"STATE=active RC=1"* ]] || return 1
        fi
    done
}

@test "incomplete-download lsof diagnostics are unknown, never idle (#1471)" {
    local partial="$HOME/Downloads/session.crdownload"
    mkdir -p "$(dirname "$partial")"
    printf 'partial\n' > "$partial"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" partial="$partial" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() {
    printf 'lsof: cannot stat requested path\n' >&2
    return 1
}
run_with_timeout() { shift; "$@"; }
open_state=0
_mole_paths_have_open_handle "$partial" || open_state=$?
printf 'STATE=%s\n' "$open_state"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"STATE=2"* ]] || return 1
}

@test "a stuck bundle identifier read times out and counts as unreadable" {
    # The owner-process probe also runs at the final deletion step, so an
    # unbounded plutil on a dataless ~/Applications bundle would hang the
    # clean. A timed-out read must land on the same "unreadable" answer that
    # callers already treat as busy.
    local bundle="$HOME/Applications/Stuck.app"
    local stub_dir="$HOME/stuck-plutil-bin"
    mkdir -p "$bundle/Contents" "$stub_dir"
    printf '#!/bin/bash\nsleep 30\n' > "$stub_dir/plutil"
    chmod +x "$stub_dir/plutil"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" bundle="$bundle" \
        PATH="$stub_dir:$PATH" MOLE_TIMEOUT_QUICK_DETECT_SEC=1 \
        /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
started=$SECONDS
rc=0
_mole_app_bundle_identifier "$bundle" || rc=$?
printf 'RC=%s ID=[%s] ELAPSED=%s\n' "$rc" "$_MOLE_APP_BUNDLE_ID" "$((SECONDS - started))"
EOF

    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" == *"RC=1 ID=[]"* ]] || { echo "$output"; return 1; }
    local elapsed="${output##*ELAPSED=}"
    [[ "$elapsed" -lt 10 ]] || { echo "$output"; return 1; }
}

@test "the debug flag never changes an open-handle verdict (#1439)" {
    # The probe folds lsof stderr into the buffer whose emptiness is what makes
    # rc=1 mean "conclusively idle". run_with_timeout traces to that same stream
    # under MO_DEBUG=1, so --debug left the buffer never empty and downgraded
    # every probe to "could not tell". Measured before the fix: 10 of 25 real
    # cache databases flipped from cleanable to kept, which means the flag meant
    # to explain a run was quietly changing it. The stub below reproduces the
    # trace on purpose; a stub that swallows it cannot see this class at all.
    local idle="$HOME/Library/Caches/example.idle/Cache.db"
    mkdir -p "$(dirname "$idle")"
    printf 'idle\n' > "$idle"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" idle="$idle" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() {
    local duration="$1"
    shift
    if [[ "${MO_DEBUG:-0}" == "1" ]]; then
        echo "[TIMEOUT] Running with ${duration}s timeout: $*" >&2
    fi
    "$@"
}
export MO_DEBUG=0
quiet=0
_mole_paths_have_open_handle "$idle" || quiet=$?
export MO_DEBUG=1
loud=0
_mole_paths_have_open_handle "$idle" || loud=$?
printf 'QUIET=%s LOUD=%s\n' "$quiet" "$loud"
EOF

    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" == *"QUIET=1"* ]] || { echo "$output"; return 1; }
    [[ "$output" == *"LOUD=1"* ]] || { echo "$output"; return 1; }
}

@test "safe_remove rechecks incomplete downloads at the final deletion boundary (#1471)" {
    local partial="$HOME/Downloads/session.part"
    mkdir -p "$(dirname "$partial")"
    printf 'partial\n' > "$partial"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" partial="$partial" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
trace_file=$(mktemp)
size_marker=$(mktemp)
command rm -f "$size_marker"
lsof() {
    printf 'LSOF:%s\n' "$(test -f "$size_marker" && echo live || echo idle)" >> "$trace_file"
    if [[ -f "$size_marker" ]]; then
        printf 'n%s\n' "$partial"
        return 0
    fi
    return 1
}
run_with_timeout() { shift; "$@"; }
get_path_size_kb() {
    printf 'SIZE\n' >> "$trace_file"
    printf 'sized\n' > "$size_marker"
    printf '1\n'
}
oplog_enabled() { return 0; }
rm() { printf 'UNEXPECTED_REMOVE:%s\n' "$*"; return 99; }
remove_rc=0
safe_remove "$partial" true || remove_rc=$?
printf 'RC=%s EXISTS=%s ORDER=%s\n' "$remove_rc" \
    "$(test -f "$partial" && echo yes || echo no)" "$(tr '\n' ',' < "$trace_file")"
command rm -f "$trace_file" "$size_marker"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 EXISTS=yes ORDER=LSOF:idle,SIZE,LSOF:live,"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_REMOVE"* ]] || return 1
}

@test "safe_remove dry-run rechecks incomplete downloads after sizing (#1471)" {
    local partial="$HOME/Downloads/session.download"
    mkdir -p "$(dirname "$partial")"
    printf 'partial\n' > "$partial"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" partial="$partial" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
trace_file=$(mktemp)
size_marker=$(mktemp)
command rm -f "$size_marker"
lsof() {
    printf 'LSOF:%s\n' "$(test -f "$size_marker" && echo live || echo idle)" >> "$trace_file"
    if [[ -f "$size_marker" ]]; then
        printf 'n%s\n' "$partial"
        return 0
    fi
    return 1
}
run_with_timeout() { shift; "$@"; }
get_path_size_kb() {
    printf 'SIZE\n' >> "$trace_file"
    printf 'sized\n' > "$size_marker"
    printf '1\n'
}
record_dry_run_cleanup_target() { printf 'UNEXPECTED_REGISTER:%s\n' "$1"; }
MOLE_DRY_RUN=1
remove_rc=0
safe_remove "$partial" true || remove_rc=$?
printf 'RC=%s EXISTS=%s ORDER=%s\n' "$remove_rc" \
    "$(test -f "$partial" && echo yes || echo no)" "$(tr '\n' ',' < "$trace_file")"
command rm -f "$trace_file" "$size_marker"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 EXISTS=yes ORDER=LSOF:idle,SIZE,LSOF:live,"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_REGISTER"* ]] || return 1
}

@test "safe_remove rechecks non-cache SQLite files at the final deletion boundary (#1471)" {
    local database="$TEST_DIR/state.sqlite"
    printf 'db\n' > "$database"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" database="$database" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
trace_file=$(mktemp)
size_marker=$(mktemp)
command rm -f "$size_marker"
lsof() {
    printf 'LSOF:%s\n' "$(test -f "$size_marker" && echo live || echo idle)" >> "$trace_file"
    if [[ -f "$size_marker" ]]; then
        printf 'n%s\n' "$database"
        return 0
    fi
    return 1
}
run_with_timeout() { shift; "$@"; }
get_path_size_kb() {
    printf 'SIZE\n' >> "$trace_file"
    printf 'sized\n' > "$size_marker"
    printf '1\n'
}
oplog_enabled() { return 0; }
rm() { printf 'UNEXPECTED_REMOVE:%s\n' "$*"; return 99; }
remove_rc=0
safe_remove "$database" true || remove_rc=$?
printf 'RC=%s EXISTS=%s ORDER=%s\n' "$remove_rc" \
    "$(test -f "$database" && echo yes || echo no)" "$(tr '\n' ',' < "$trace_file")"
command rm -f "$trace_file" "$size_marker"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 EXISTS=yes ORDER=LSOF:idle,SIZE,LSOF:live,"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_REMOVE"* ]] || return 1
}

@test "safe_remove binds an incomplete download identity around the final lsof probe (#1471)" {
    local partial="$HOME/Downloads/replaced.part"
    mkdir -p "$(dirname "$partial")"
    printf 'original\n' > "$partial"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" partial="$partial" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
probe_count_file=$(mktemp)
rm_calls=$(mktemp)
: > "$probe_count_file"
: > "$rm_calls"
lsof() {
    printf 'call\n' >> "$probe_count_file"
    probe_count=$(wc -l < "$probe_count_file" | tr -d ' ')
    if [[ $probe_count -eq 2 ]]; then
        mv "$partial" "$partial-original"
        printf 'replacement\n' > "$partial"
    fi
    return 1
}
run_with_timeout() { shift; "$@"; }
oplog_enabled() { return 1; }
rm() { printf 'call\n' >> "$rm_calls"; return 99; }
remove_rc=0
safe_remove "$partial" true || remove_rc=$?
printf 'RC=%s NEW=%s OLD=%s CALLS=%s RM_CALLS=%s\n' "$remove_rc" \
    "$(cat "$partial")" "$(cat "$partial-original")" \
    "$(wc -l < "$probe_count_file" | tr -d ' ')" \
    "$(wc -l < "$rm_calls" | tr -d ' ')"
command rm -f "$probe_count_file" "$rm_calls"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 NEW=replacement OLD=original CALLS=2 RM_CALLS=0"* ]] || return 1
}

@test "safe_remove binds a SQLite identity around the final lsof probe (#1471)" {
    local database="$TEST_DIR/replaced.sqlite"
    printf 'original\n' > "$database"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" database="$database" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
probe_count_file=$(mktemp)
rm_calls=$(mktemp)
: > "$probe_count_file"
: > "$rm_calls"
lsof() {
    printf 'call\n' >> "$probe_count_file"
    probe_count=$(wc -l < "$probe_count_file" | tr -d ' ')
    if [[ $probe_count -eq 2 ]]; then
        mv "$database" "$database-original"
        printf 'replacement\n' > "$database"
    fi
    return 1
}
run_with_timeout() { shift; "$@"; }
oplog_enabled() { return 1; }
rm() { printf 'call\n' >> "$rm_calls"; return 99; }
remove_rc=0
safe_remove "$database" true || remove_rc=$?
printf 'RC=%s NEW=%s OLD=%s CALLS=%s RM_CALLS=%s\n' "$remove_rc" \
    "$(cat "$database")" "$(cat "$database-original")" \
    "$(wc -l < "$probe_count_file" | tr -d ' ')" \
    "$(wc -l < "$rm_calls" | tr -d ' ')"
command rm -f "$probe_count_file" "$rm_calls"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 NEW=replacement OLD=original CALLS=2 RM_CALLS=0"* ]] || return 1
}

@test "safe_remove deletes conclusively idle exact-handle targets (#1471)" {
    local partial="$HOME/Downloads/idle.crdownload"
    local database="$TEST_DIR/idle.sqlite3"
    mkdir -p "$(dirname "$partial")"
    printf 'partial\n' > "$partial"
    printf 'db\n' > "$database"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" partial="$partial" database="$database" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() { shift; "$@"; }
oplog_enabled() { return 1; }
safe_remove "$partial" true
safe_remove "$database" true
printf 'PARTIAL=%s DATABASE=%s\n' \
    "$(test -e "$partial" && echo present || echo removed)" \
    "$(test -e "$database" && echo present || echo removed)"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"PARTIAL=removed DATABASE=removed"* ]] || return 1
}

@test "validate_path_for_deletion refuses open descendants in app and group container caches (#1471)" {
    local app_cache="$HOME/Library/Containers/com.example.Editor/Data/Library/Caches/LiveState"
    local group_cache="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/History"
    mkdir -p "$app_cache/nested" "$group_cache/segments/current"
    printf 'state\n' > "$app_cache/nested/session.json"
    printf 'event\n' > "$group_cache/segments/current/events.jsonl"

    local path
    for path in "$app_cache" "$group_cache"; do
        run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" path="$path" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() {
    [[ "$*" == *"+D $path"* ]] || return 2
    printf 'p901\nf5\nn%s/nested/open.jsonl\n' "$path"
    return 0
}
run_with_timeout() { shift; "$@"; }
validate_path_for_deletion "$path"
EOF
        [ "$status" -eq 1 ] || return 1
    done
}

@test "container cache handle probe is bounded and fails closed on uncertain results (#1471)" {
    local cache_dir="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/History"
    mkdir -p "$cache_dir/segments"
    printf 'event\n' > "$cache_dir/segments/events.jsonl"

    local probe_rc
    for probe_rc in 2 124; do
        run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" probe_rc="$probe_rc" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return "$probe_rc"; }
run_with_timeout() {
    [[ "$1" == "$MOLE_TIMEOUT_QUICK_DETECT_SEC" ]] || return 99
    shift
    "$@"
}
validation_rc=0
validate_path_for_deletion "$cache_dir" || validation_rc=$?
printf 'PROBE=%s RC=%s\n' "$probe_rc" "$validation_rc"
EOF
        [ "$status" -eq 0 ] || return 1
        [[ "$output" == *"PROBE=$probe_rc RC=1"* ]] || return 1
    done

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
PATH=/bin
validate_path_for_deletion "$cache_dir"
EOF
    [ "$status" -eq 1 ] || return 1

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
unset -f run_with_timeout
validate_path_for_deletion "$cache_dir"
EOF
    [ "$status" -eq 1 ] || return 1

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() {
    printf 'lsof: WARNING: cannot stat a descendant\n' >&2
    return 1
}
run_with_timeout() { shift; "$@"; }
validate_path_for_deletion "$cache_dir"
EOF
    [ "$status" -eq 1 ] || return 1

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { printf 'UNEXPECTED_LSOF\n'; return 0; }
run_with_timeout() { printf 'UNEXPECTED_TIMEOUT\n'; return 0; }
_MOLE_CONTAINER_CACHE_PROBE_DEADLINE=$SECONDS
validate_path_for_deletion "$cache_dir"
EOF
    [ "$status" -eq 1 ] || return 1
    [[ "$output" != *"UNEXPECTED_"* ]] || return 1
}

@test "container cache probe accepts fractional cumulative timeout overrides (#1471)" {
    local cache_dir="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/Fractional"
    local lsof_trace="$HOME/fractional-lsof-trace"
    mkdir -p "$cache_dir"
    printf 'idle\n' > "$cache_dir/state.json"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" \
        lsof_trace="$lsof_trace" MOLE_TIMEOUT_MEDIUM_PROBE_SEC=2.5 \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { printf 'call\n' >> "$lsof_trace"; return 1; }
run_with_timeout() { shift; "$@"; }
_MOLE_CONTAINER_CACHE_PROBE_DEADLINE=""
validate_path_for_deletion "$cache_dir"
printf 'DEADLINE=%s\n' "$_MOLE_CONTAINER_CACHE_PROBE_DEADLINE"
EOF

    [ "$status" -eq 0 ] || return 1
    [ "$(wc -l < "$lsof_trace" | tr -d ' ')" -eq 1 ] || return 1
    local deadline="${output##*DEADLINE=}"
    [[ "$deadline" =~ ^[0-9]+$ ]] || return 1
}

@test "safe_remove preserves an interrupted container probe and stops later deletes (#1471)" {
    local cache_root="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches"
    local first="$cache_root/First"
    local second="$cache_root/Second"
    mkdir -p "$first" "$second"
    printf 'first\n' > "$first/state.json"
    printf 'second\n' > "$second/state.json"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" first="$first" second="$second" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof_trace=$(mktemp)
lsof() { printf 'call\n' >> "$lsof_trace"; return 130; }
run_with_timeout() { shift; "$@"; }
rm() { printf 'UNEXPECTED_REMOVE:%s\n' "$*"; return 99; }
MOLE_CURRENT_COMMAND=clean
MOLE_CLEAN_CANCEL_STATUS=0
first_rc=0
safe_remove "$first" true 1 || first_rc=$?
second_rc=0
safe_remove "$second" true 1 || second_rc=$?
lsof_calls=$(wc -l < "$lsof_trace" | tr -d ' ')
command rm -f "$lsof_trace"
printf 'FIRST_RC=%s SECOND_RC=%s CANCEL=%s LSOF=%s FIRST=%s SECOND=%s\n' \
    "$first_rc" "$second_rc" "$MOLE_CLEAN_CANCEL_STATUS" "$lsof_calls" \
    "$(test -d "$first" && echo yes || echo no)" \
    "$(test -d "$second" && echo yes || echo no)"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"FIRST_RC=130 SECOND_RC=130 CANCEL=130 LSOF=1 FIRST=yes SECOND=yes"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_REMOVE"* ]] || return 1
}

@test "container cache probe refuses a path replaced during lsof (#1471)" {
    local cache_dir="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/Race"
    mkdir -p "$cache_dir"
    printf 'old\n' > "$cache_dir/state.json"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" \
        /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() {
    mv "$cache_dir" "$cache_dir-old"
    mkdir -p "$cache_dir"
    printf 'new-live\n' > "$cache_dir/events.jsonl"
    return 1
}
run_with_timeout() { shift; "$@"; }
remove_rc=0
safe_remove "$cache_dir" true 1 || remove_rc=$?
printf 'RC=%s NEW=%s OLD=%s\n' "$remove_rc" \
    "$(test -f "$cache_dir/events.jsonl" && echo yes || echo no)" \
    "$(test -f "$cache_dir-old/state.json" && echo yes || echo no)"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 NEW=yes OLD=yes"* ]] || return 1
}

@test "validate_path_for_deletion allows a conclusively idle container cache (#1471)" {
    local cache_dir="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/Idle"
    mkdir -p "$cache_dir"
    printf 'idle\n' > "$cache_dir/state.json"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof() { return 1; }
run_with_timeout() { shift; "$@"; }
validate_path_for_deletion "$cache_dir"
EOF

    [ "$status" -eq 0 ] || return 1
}

@test "container cache probe fails closed when lsof cannot see root processes (#1471)" {
    local cache_dir="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/InvisibleHelper"
    mkdir -p "$cache_dir"
    printf 'active\n' > "$cache_dir/events.jsonl"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
trace_file=$(mktemp)
lsof() {
    case " $* " in
        *" -p 1 "*)
            printf 'visibility\n' >> "$trace_file"
            return 1
            ;;
        *)
            printf 'target\n' >> "$trace_file"
            return 1
            ;;
    esac
}
run_with_timeout() { shift; "$@"; }
probe_rc=0
validate_path_for_deletion "$cache_dir" || probe_rc=$?
printf 'RC=%s TRACE=%s\n' "$probe_rc" "$(tr '\n' ',' < "$trace_file")"
command rm -f "$trace_file"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 TRACE=visibility,"* ]] || return 1
}

@test "container cache probe uses only an already-authorized sudo lsof fallback (#1471)" {
    local cache_dir="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/PrivilegedHelper"
    mkdir -p "$cache_dir"
    printf 'idle\n' > "$cache_dir/state.json"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
MOLE_TEST_MODE=0
MOLE_TEST_NO_AUTH=0
_mole_user_cache_owner_process_state() { return 1; }
trace_file=$(mktemp)
lsof() {
    printf 'direct:%s\n' "$*" >> "$trace_file"
    return 1
}
sudo() {
    printf 'sudo:%s\n' "$*" >> "$trace_file"
    case " $* " in
        *" -p 1 "*)
            printf 'p1\nu0\n'
            return 0
            ;;
        *" +D $cache_dir "*) return 1 ;;
        *) return 2 ;;
    esac
}
run_with_timeout() { shift; "$@"; }
probe_rc=0
validate_path_for_deletion "$cache_dir" || probe_rc=$?
printf 'RC=%s MODE=%s TRACE=%s\n' "$probe_rc" "$_MOLE_COMPLETE_LSOF_MODE" \
    "$(tr '\n' ',' < "$trace_file")"
command rm -f "$trace_file"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=0 MODE=sudo"* ]] || return 1
    [[ "$output" == *"direct:-F pu -p 1"* ]] || return 1
    [[ "$output" == *"sudo:-n lsof -F pu -p 1"* ]] || return 1
    [[ "$output" == *"sudo:-n lsof -F pfn +D $cache_dir"* ]] || return 1
}

@test "container cache probe budget stops later recursive lsof calls fail closed (#1471)" {
    local cache_root="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches"
    mkdir -p "$cache_root/First" "$cache_root/Second" "$cache_root/Third"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_root="$cache_root" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
timeout_calls=$(mktemp)
lsof_calls=$(mktemp)
_mole_timeout_with_deadline() {
    printf 'call\n' >> "$timeout_calls"
    call_count=$(wc -l < "$timeout_calls" | tr -d ' ')
    [[ $call_count -eq 1 ]] || return 124
    printf '2\n'
}
lsof() {
    printf 'call\n' >> "$lsof_calls"
    return 1
}
run_with_timeout() { shift; "$@"; }
_MOLE_CONTAINER_CACHE_PROBE_DEADLINE=""

states=""
for item in "$cache_root/First" "$cache_root/Second" "$cache_root/Third"; do
    state=0
    validate_path_for_deletion "$item" || state=$?
    states="${states}${state}"
done
lsof_count=$(wc -l < "$lsof_calls" | tr -d ' ')
command rm -f "$timeout_calls" "$lsof_calls"
printf 'STATES=%s LSOF_CALLS=%s\n' "$states" "$lsof_count"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"STATES=011 LSOF_CALLS=1"* ]] || return 1
}

@test "container cache guard detects a real open descendant through bounded lsof (#1471)" {
    command -v lsof > /dev/null 2>&1 || skip "lsof is unavailable"
    local cache_dir="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/RealHandle"
    local live_file="$cache_dir/segments/events.jsonl"
    mkdir -p "${live_file%/*}"
    printf 'event\n' > "$live_file"

    exec 9> "$live_file"
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
validate_path_for_deletion "$cache_dir"
EOF
    exec 9>&-

    [ "$status" -eq 1 ] || return 1
}

@test "safe_remove rechecks container handles at the final deletion boundary (#1471)" {
    local cache_dir="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/History"
    mkdir -p "$cache_dir/segments"
    printf 'event\n' > "$cache_dir/segments/events.jsonl"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$cache_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_user_cache_owner_process_state() { return 1; }
_MOLE_COMPLETE_LSOF_MODE=direct
lsof_calls=$(mktemp)
rm_calls=$(mktemp)
size_marker=$(mktemp)
order_trace=$(mktemp)
command rm -f "$size_marker"
lsof() {
    printf 'call\n' >> "$lsof_calls"
    printf 'LSOF\n' >> "$order_trace"
    [[ -f "$size_marker" ]] || return 2
    printf 'p901\nf5\nn%s/segments/events.jsonl\n' "$TARGET_DIR"
    return 0
}
run_with_timeout() { shift; "$@"; }
get_path_size_kb() {
    printf 'SIZE\n' >> "$order_trace"
    printf 'sized\n' > "$size_marker"
    printf '1\n'
}
oplog_enabled() { return 0; }
rm() { printf 'call\n' >> "$rm_calls"; return 99; }

remove_rc=0
safe_remove "$TARGET_DIR" true || remove_rc=$?
lsof_call_count=$(wc -l < "$lsof_calls" | tr -d ' ')
rm_call_count=$(wc -l < "$rm_calls" | tr -d ' ')
order=$(tr '\n' ',' < "$order_trace")
command rm -f "$lsof_calls" "$rm_calls" "$size_marker" "$order_trace"
printf 'RC=%s LSOF_CALLS=%s EXISTS=%s RM_CALLS=%s ORDER=%s\n' \
    "$remove_rc" "$lsof_call_count" "$(test -d "$TARGET_DIR" && echo yes || echo no)" \
    "$rm_call_count" "$order"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 LSOF_CALLS=1 EXISTS=yes RM_CALLS=0 ORDER=SIZE,LSOF,"* ]] || return 1
}

@test "should_protect_path applies high-risk cleanup denylist" {
    run /bin/bash -c "
        source '$PROJECT_ROOT/lib/core/common.sh'
        should_protect_path '$HOME/Library/Caches/ms-playwright/chromium-123'
        should_protect_path '$HOME/Library/Caches/com.apple.homed/state'
        should_protect_path '$HOME/Library/Group Containers/group.com.apple.notes/NoteStore.sqlite'
        should_protect_path '$HOME/Library/Preferences/com.paceap.eden.iLokLicenseManager.plist'
        should_protect_path '/private/var/folders/aa/bb/C/com.native-instruments.NativeAccess/license'
        should_protect_path '/Library/Audio/Plug-Ins/VST3/Example.vst3'
        should_protect_data 'com.native-instruments.NativeAccess'
        ! should_protect_path '$HOME/Library/Application Support/Example/Cache/item'
    "
    [ "$status" -eq 0 ]
}

@test "should_protect_path keeps Google identity and Clearcut state (#1607)" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
should_protect_path "$HOME/Library/Caches/GIPPseudonymousID" || exit 1
should_protect_path "$HOME/Library/Caches/GIPPseudonymousID/device-id" || exit 1
should_protect_path "$HOME/Library/Caches/CCTClearcutLogger" || exit 1
should_protect_path "$HOME/Library/Caches/CCTClearcutLogger/queue.dat" || exit 1
if should_protect_path "$HOME/Library/Caches/ordinary-app/junk"; then
    exit 1
fi
EOF
    [ "$status" -eq 0 ]
}

@test "should_protect_path allows only the measured WeChat container cache leaves" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
wechat="$HOME/Library/Containers/com.tencent.xinWeChat/Data"
! should_protect_path "$wechat/Documents/app_data/log/wechat.log" || exit 1
! should_protect_path "$wechat/.wxapplet/WMPF/cache.bin" || exit 1
should_protect_path "$wechat/Documents/xwechat_files/account/db_storage/message.db"
should_protect_path "$wechat/Documents/app_data/radium/users/account/state.db"
should_protect_path "$wechat/Documents/app_data/log"
should_protect_path "$wechat/.wxapplet/WMPF"
EOF

    [ "$status" -eq 0 ]
}

@test "is_endpoint_security_cache_path matches only EDR agent var/folders caches" {
    run env PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"

# Deleting anything an EDR agent owns under the per-user Darwin folder trips
# sensor tamper detection (CrowdStrike MacFalconSensorTamper, MITRE T1562.001).
# The matcher covers the vendor bundle id anywhere under var/folders: the C/
# shader cache that triggered the real corporate alert, the X/ code-signature
# clone, and T/ temp. Protection-only, so a wide match within var/folders is
# intentional.
is_endpoint_security_cache_path "/private/var/folders/9d/abc123/C/com.crowdstrike.falcon.App/com.apple.metalfe"
is_endpoint_security_cache_path "/private/var/folders/9d/abc123/X/com.crowdstrike.falcon.App.code_sign_clone"
is_endpoint_security_cache_path "/private/var/folders/aa/bb/T/com.crowdstrike.falcon.App/scratch"
is_endpoint_security_cache_path "/private/var/folders/aa/bb/C/com.sentinelone.agent/com.apple.metal"
is_endpoint_security_cache_path "/private/var/folders/aa/bb/C/com.jamf.management/com.apple.gpuarchiver"
is_endpoint_security_cache_path "/private/var/folders/aa/bb/C/com.paloaltonetworks.GlobalProtect/com.apple.metalfe"
is_endpoint_security_cache_path "/private/var/folders/aa/bb/C/com.eset.endpoint/com.apple.metal"
is_endpoint_security_cache_path "/private/var/folders/aa/bb/C/com.sentinel-labs.agent/com.apple.metalfe"
is_endpoint_security_cache_path "/private/var/folders/aa/bb/C/com.jamfsoftware.selfservice/com.apple.gpuarchiver"
is_endpoint_security_cache_path "/private/var/folders/aa/bb/X/com.cisco.anyconnect.gui.code_sign_clone"
is_endpoint_security_cache_path "/private/var/folders/aa/bb/X/com.cisco.secureclient.gui.code_sign_clone"
# A normal third-party app's cache is not an EDR cache.
! is_endpoint_security_cache_path "/private/var/folders/aa/bb/C/com.example.App/com.apple.metalfe" || exit 1
# Non-security Cisco products (e.g. Webex) are not matched; only the secure-access clients are.
! is_endpoint_security_cache_path "/private/var/folders/aa/bb/X/com.cisco.webex.code_sign_clone" || exit 1
# Paths outside var/folders are out of scope for this predicate.
! is_endpoint_security_cache_path "/Applications/Falcon.app" || exit 1
# A non-Darwin path that merely contains "var/folders" must NOT match (anchored).
! is_endpoint_security_cache_path "/Users/me/project/var/folders/com.crowdstrike.fixture/cache"
EOF

    [ "$status" -eq 0 ]
}

@test "should_protect_path protects endpoint-security / EDR agent caches (CrowdStrike Falcon tamper)" {
    run env PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc << 'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"

# Matched by the dedicated EDR predicate before any bundle/filename fallback,
# so the result is deterministic regardless of nounset/source order.
should_protect_path "/private/var/folders/9d/abc123/C/com.crowdstrike.falcon.App/com.apple.metalfe"
should_protect_path "/private/var/folders/aa/bb/C/com.sentinelone.agent/com.apple.metal"
EOF

    [ "$status" -eq 0 ]
}

@test "should_protect_path protects OrbStack live container data" {
    local orb_group_data="$HOME/Library/Group Containers/HUAQ24HBR6.dev.orbstack/data/data.img.raw"
    local orb_state="$HOME/.orbstack/state.db"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" ORB_GROUP_DATA="$orb_group_data" ORB_STATE="$orb_state" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
should_protect_data "dev.orbstack.OrbStack"
should_protect_data "dev.kdrag0n.MacVirt"
should_protect_path "$ORB_GROUP_DATA"
should_protect_path "$ORB_STATE"
EOF

    [ "$status" -eq 0 ]
}

@test "safe_remove validates path before deletion" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; safe_remove '/System/test' 2>&1"
    [ "$status" -eq 1 ]
}

@test "validate_path_for_deletion rejects symlink to protected system path" {
    local link_path="$TEST_DIR/system-link"
    ln -s "/System" "$link_path"

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; validate_path_for_deletion '$link_path' 2>&1"
    [ "$status" -eq 1 ]
    [[ "$output" == *"protected system path"* ]]
}

@test "safe_remove silent mode hides protected symlink validation warning" {
    local link_path="$TEST_DIR/silent-system-link"
    ln -s "/System" "$link_path"

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; safe_remove '$link_path' true 2>&1"
    [ "$status" -eq 1 ]
    [[ -L "$link_path" ]] || return 1
    [[ "$output" != *"Symlink points to protected system path"* ]]
}

@test "safe_remove successfully removes file" {
    local test_file="$TEST_DIR/test_file.txt"
    echo "test" > "$test_file"

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; safe_remove '$test_file' true"
    [ "$status" -eq 0 ]
    [ ! -f "$test_file" ]
}

@test "safe_remove successfully removes directory" {
    local test_subdir="$TEST_DIR/test_subdir"
    mkdir -p "$test_subdir"
    touch "$test_subdir/file.txt"

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; safe_remove '$test_subdir' true"
    [ "$status" -eq 0 ]
    [ ! -d "$test_subdir" ]
}

@test "safe_remove handles non-existent path gracefully" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; safe_remove '$TEST_DIR/nonexistent' true"
    [ "$status" -eq 0 ]
}

@test "safe_remove preserves interrupt exit codes" {
    local test_file="$TEST_DIR/interrupt_file"
    echo "test" > "$test_file"

    run /bin/bash -c "
        source '$PROJECT_ROOT/lib/core/common.sh'
        rm() { return 130; }
        safe_remove '$test_file' true
    "
    [ "$status" -eq 130 ]
    [ -f "$test_file" ]
}

@test "safe_remove bounds a stalled external rm" {
    local target_file="$TEST_DIR/stalled-rm-file"
    local mock_bin="$TEST_DIR/stalled-rm-bin"
    local trace="$TEST_DIR/stalled-rm.trace"
    mkdir -p "$mock_bin"
    touch "$target_file"

    cat > "$mock_bin/rm" <<'MOCK'
#!/bin/bash
if [[ "$*" == *"$TARGET_FILE"* ]]; then
    printf 'rm %s\n' "$*" >> "$MOLE_RM_TRACE"
    exec sleep 4
fi
exec /bin/rm "$@"
MOCK
    chmod +x "$mock_bin/rm"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_FILE="$target_file" \
        PATH="$mock_bin:$PATH" MOLE_RM_TRACE="$trace" MOLE_TIMEOUT_DISK_VERIFY_SEC=1 \
        /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
get_path_size_kb() { echo 1; }
started=$(date +%s)
rc=0
safe_remove "$TARGET_FILE" true || rc=$?
elapsed=$(( $(date +%s) - started ))
printf 'RC=%s\nELAPSED=%s\n' "$rc" "$elapsed"
SCRIPT

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"RC=124"* ]] || return 1
    [[ "$(< "$trace")" == *"$target_file"* ]] || return 1
    local elapsed="${output##*ELAPSED=}"
    [[ "$elapsed" =~ ^[0-9]+$ ]] || return 1
    [ "$elapsed" -lt 3 ]
    [ -e "$target_file" ]
}

@test "safe_remove refuses a compiled model cache created during size probing" {
    local target_dir="$TEST_DIR/compiled-model-race"
    mkdir -p "$target_dir"
    touch "$target_dir/data"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
oplog_enabled() { return 0; }
get_path_size_kb() {
    mkdir -p "$1/com.apple.e5rt.e5bundlecache"
    echo 1
}
rm() { echo "UNEXPECTED_REMOVE:$*"; return 99; }
safe_remove "$TARGET_DIR" true && rc=0 || rc=$?
printf 'RC=%s\n' "$rc"
[[ -d "$TARGET_DIR/com.apple.e5rt.e5bundlecache" ]]
SCRIPT

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=1"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_REMOVE"* ]]
}

@test "safe_remove dry-run refuses an existing compiled model cache" {
    local target_dir="$TEST_DIR/compiled-model-dry-run"
    mkdir -p "$target_dir/com.apple.e5rt.e5bundlecache"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
MOLE_DRY_RUN=1
record_dry_run_cleanup_target() { echo "UNEXPECTED_REGISTER:$1"; }
safe_remove "$TARGET_DIR" true && rc=0 || rc=$?
printf 'RC=%s\n' "$rc"
SCRIPT

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=1"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_REGISTER"* ]]
}

@test "safe_remove dry-run exercises the production preview eligibility path" {
    local target_dir="$TEST_DIR/cache-eligibility"
    mkdir -p "$target_dir"

    run env PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/bin/clean.sh"
guard_calls=0
_mole_should_refuse_live_user_cache_path() {
    guard_calls=$((guard_calls + 1))
    return 1
}
MOLE_DRY_RUN=1 safe_remove "$TARGET_DIR" true 1
printf 'CALLS=%s EXISTS=%s\n' "$guard_calls" "$(test -d "$TARGET_DIR" && echo yes || echo no)"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"CALLS=1 EXISTS=yes"* ]] || return 1
}

@test "safe_remove dry-run rechecks live cache state after sizing (#1471)" {
    local target_dir="$TEST_DIR/cache-live-after-size"
    mkdir -p "$target_dir"

    run env PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
source "$PROJECT_ROOT/bin/clean.sh"
state_file="$TARGET_DIR/.sized"
trace_file="$TARGET_DIR/.trace"
_mole_should_refuse_live_user_cache_path() {
    [[ "${_MOLE_DEFER_CONTAINER_HANDLE_PROBE:-false}" == "true" ]] && return 1
    printf 'GUARD:%s\n' "$(test -f "$state_file" && echo live || echo idle)" >> "$trace_file"
    [[ -f "$state_file" ]]
}
get_path_size_kb() {
    printf 'SIZE\n' >> "$trace_file"
    touch "$state_file"
    printf '7\n'
}
register_dry_run_cleanup_target() { printf 'UNEXPECTED_REGISTER:%s\n' "$1"; }
append_dry_run_cleanup_target() { printf 'UNEXPECTED_APPEND:%s\n' "$1"; }
MOLE_DRY_RUN=1 safe_remove "$TARGET_DIR" true && rc=0 || rc=$?
printf 'RC=%s\n' "$rc"
cat "$trace_file"
EOF

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1"* ]] || return 1
    [[ "$output" == *$'SIZE\nGUARD:live'* ]] || return 1
    [[ "$(grep -c '^GUARD:' <<< "$output")" -eq 1 ]] || return 1
    [[ "$output" != *"UNEXPECTED_REGISTER"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_APPEND"* ]] || return 1
}

@test "safe_remove in silent mode suppresses error output" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; safe_remove '/System/test' true 2>&1"
    [ "$status" -eq 1 ]
}


@test "safe_find_delete validates base directory" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; safe_find_delete '/nonexistent' '*.tmp' 7 'f' 2>&1"
    [ "$status" -eq 1 ]
}

@test "safe_sudo_remove refuses symlink paths" {
    local target_dir="$TEST_DIR/real"
    local link_dir="$TEST_DIR/link"
    mkdir -p "$target_dir"
    ln -s "$target_dir" "$link_dir"

    run /bin/bash -c "
        source '$PROJECT_ROOT/lib/core/common.sh'
        sudo() { return 0; }
        export -f sudo
        safe_sudo_remove '$link_dir' 2>&1
    "
    [ "$status" -eq 1 ]
    [[ "$output" == *"Refusing to sudo remove symlink"* ]]
}

@test "safe_sudo_remove never opens an interactive sudo prompt" {
    local target_dir="$TEST_DIR/sudo-target"
    mkdir -p "$target_dir"
    touch "$target_dir/file"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"

# This test models a root-owned, immutable system path so it reaches the
# noninteractive sudo authentication branch.
_mole_privileged_path_has_mutable_ancestor() { return 1; }

sudo() {
    if [[ "${1:-}" != "-n" ]]; then
        echo "INTERACTIVE_SUDO:$*" >&2
        return 99
    fi
    shift
    case "${1:-}" in
        test)
            shift
            command test "$@"
            ;;
        du)
            shift
            command du "$@"
            ;;
        rm)
            shift
            command rm "$@"
            ;;
        *)
            "$@"
            ;;
    esac
}
export -f sudo

safe_sudo_remove "$TARGET_DIR"
[[ ! -e "$TARGET_DIR" ]] || exit 1
SCRIPT

    [ "$status" -eq 0 ]
    [[ "$output" != *"INTERACTIVE_SUDO"* ]]
}

@test "safe_sudo_remove bounds a stalled external sudo rm" {
    local target_dir="$TEST_DIR/stalled-sudo-rm-target"
    local mock_bin="$TEST_DIR/stalled-sudo-rm-bin"
    local trace="$TEST_DIR/stalled-sudo-rm.trace"
    mkdir -p "$target_dir" "$mock_bin"
    touch "$target_dir/data"

    cat > "$mock_bin/sudo" <<'MOCK'
#!/bin/bash
set -u
[[ "${1:-}" == "-n" ]] && shift
case "${1:-}" in
    rm)
        printf 'sudo-rm %s\n' "$*" >> "$MOLE_SUDO_RM_TRACE"
        exec sleep 8
        ;;
    *)
        exit 99
        ;;
esac
MOCK
    chmod +x "$mock_bin/sudo"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        PATH="$mock_bin:$PATH" MOLE_SUDO_RM_TRACE="$trace" \
        MOLE_TIMEOUT_DISK_VERIFY_SEC=2 MO_NO_OPLOG=1 \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_privileged_path_has_mutable_ancestor() { return 1; }
started=$(date +%s)
rc=0
safe_sudo_remove "$TARGET_DIR" || rc=$?
elapsed=$(( $(date +%s) - started ))
printf 'RC=%s\nELAPSED=%s\n' "$rc" "$elapsed"
SCRIPT

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"RC=124"* ]] || return 1
    [[ "$(< "$trace")" == *"sudo-rm rm -rf $target_dir"* ]] || return 1
    local elapsed="${output##*ELAPSED=}"
    [[ "$elapsed" =~ ^[0-9]+$ ]] || return 1
    [ "$elapsed" -lt 5 ]
    [ -e "$target_dir/data" ]
}

@test "safe_sudo_remove refuses a compiled model cache created during size probing" {
    local target_dir="$TEST_DIR/compiled-model-sudo-race"
    mkdir -p "$target_dir"
    touch "$target_dir/data"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_privileged_path_has_mutable_ancestor() { return 1; }
oplog_enabled() { return 0; }
sudo() {
    if [[ "${1:-}" == "-n" && "${2:-}" == "test" ]]; then
        shift 2
        command test "$@"
        return $?
    fi
    if [[ "${1:-}" == "-n" && "${2:-}" == "du" ]]; then
        mkdir -p "$TARGET_DIR/com.apple.e5rt.e5bundlecache"
        printf '1 %s\n' "$TARGET_DIR"
        return 0
    fi
    echo "UNEXPECTED_SUDO:$*"
    return 99
}
safe_sudo_remove "$TARGET_DIR" && rc=0 || rc=$?
printf 'RC=%s\n' "$rc"
[[ -d "$TARGET_DIR/com.apple.e5rt.e5bundlecache" ]]
SCRIPT

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=13"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_SUDO"* ]]
}

@test "safe_sudo_remove dry-run refuses an existing compiled model cache" {
    local target_dir="$TEST_DIR/compiled-model-sudo-dry-run"
    mkdir -p "$target_dir/com.apple.e5rt.e5bundlecache"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        MOLE_TEST_MODE=1 MOLE_TEST_NO_AUTH=1 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
MOLE_DRY_RUN=1
_mole_privileged_path_has_mutable_ancestor() { return 1; }
record_dry_run_cleanup_target() { echo "UNEXPECTED_REGISTER:$1"; }
safe_sudo_remove "$TARGET_DIR" && rc=0 || rc=$?
printf 'RC=%s\n' "$rc"
SCRIPT

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=13"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_REGISTER"* ]]
}

@test "safe_sudo_remove returns auth failure when noninteractive sudo expires" {
    local target_dir="$TEST_DIR/sudo-expired"
    mkdir -p "$target_dir"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"

# This test models a root-owned, immutable system path so it reaches the
# noninteractive sudo authentication branch.
_mole_privileged_path_has_mutable_ancestor() { return 1; }

sudo() {
    if [[ "${1:-}" != "-n" ]]; then
        echo "INTERACTIVE_SUDO:$*" >&2
        return 99
    fi
    echo "sudo: a password is required" >&2
    return 1
}
export -f sudo

safe_sudo_remove "$TARGET_DIR" && rc=0 || rc=$?
echo "RC=$rc"
[[ -e "$TARGET_DIR" ]] || exit 1
SCRIPT

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=11"* ]] || return 1
    [[ "$output" != *"INTERACTIVE_SUDO"* ]]
}

@test "safe_sudo_remove returns protected-path code for safety skips" {
    local target_dir="/private/var/folders/9d/abc/C/com.crowdstrike.falcon.App/com.apple.metalfe"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"

safe_sudo_remove "$TARGET_DIR" && rc=0 || rc=$?
echo "RC=$rc"
SCRIPT

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=13"* ]]
}

@test "safe_sudo_find_delete never opens an interactive sudo prompt" {
    local target_dir="$TEST_DIR/sudo-find-target"
    local script="$TEST_DIR/sudo-find-delete-test.sh"
    mkdir -p "$target_dir"
    touch "$target_dir/old.log"

    cat > "$script" <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
TRACE="${TARGET_DIR}.sudo.trace"
> "$TRACE"

sudo() {
    printf 'SUDO:%s\n' "$*" >> "$TRACE"
    if [[ "${1:-}" != "-n" ]]; then
        echo "INTERACTIVE_SUDO:$*" >&2
        return 99
    fi
    shift
    case "${1:-}" in
        test)
            shift
            command test "$@"
            ;;
        find)
            printf '%s\0' "$TARGET_DIR/old.log"
            ;;
        du)
            shift
            command du "$@"
            ;;
        rm)
            return 0
            ;;
        *)
            "$@"
            ;;
    esac
}

export -f sudo

set +e
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f"
rc=$?
set -e
printf 'RC=%s\n' "$rc"
cat "$TRACE" || true
exit 0
SCRIPT
    chmod +x "$script"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc "$script"

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=0"* ]] || return 1
    [[ "$output" == *"SUDO:-n test -d "* ]] || return 1
    [[ "$output" == *"SUDO:-n test -L "* ]] || return 1
    [[ "$output" == *"SUDO:-n find "* ]] || return 1
    [[ "$output" != *"INTERACTIVE_SUDO"* ]]
}

@test "safe_sudo_find_delete bounds a stalled sudo find" {
    local target_dir="$TEST_DIR/sudo-find-timeout-target"
    local mock_bin="$TEST_DIR/sudo-find-timeout-bin"
    local trace="$TEST_DIR/sudo-find-timeout.trace"
    mkdir -p "$target_dir" "$mock_bin"

    cat > "$mock_bin/sudo" <<'MOCK'
#!/bin/bash
set -u
[[ "${1:-}" == "-n" ]] && shift
case "${1:-}" in
    true)
        exit 0
        ;;
    test)
        shift
        /bin/test "$@"
        ;;
    find)
        shift
        printf 'find %s\n' "$*" >> "$MOLE_SUDO_FIND_TRACE"
        exec sleep 4
        ;;
    *)
        exit 99
        ;;
esac
MOCK
    chmod +x "$mock_bin/sudo"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        PATH="$mock_bin:$PATH" MOLE_SUDO_FIND_TRACE="$trace" \
        MOLE_TIMEOUT_DISK_VERIFY_SEC=1 MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 \
        /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
started=$(date +%s)
rc=0
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" "1" || rc=$?
elapsed=$(( $(date +%s) - started ))
printf 'RC=%s\n' "$rc"
printf 'ELAPSED=%s\n' "$elapsed"
SCRIPT

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [ -f "$trace" ] || return 1
    local trace_content
    trace_content=$(< "$trace")
    [[ "$trace_content" == "find $target_dir -maxdepth 1 -name *.log -type f -print0" ]] || {
        echo "TRACE=$trace_content"
        return 1
    }
    [[ "$output" == *"ELAPSED="* ]] || return 1
    [[ "$output" == *"RC=124"* ]] || return 1
    local elapsed="${output##*ELAPSED=}"
    [[ "$elapsed" =~ ^[0-9]+$ ]] || return 1
    [ "$elapsed" -lt 3 ]
}

@test "safe_sudo_find_delete discards partial output when sudo find times out" {
    local target_dir="$TEST_DIR/sudo-find-partial-timeout-target"
    local mock_bin="$TEST_DIR/sudo-find-partial-timeout-bin"
    local trace_dir="$TEST_DIR/sudo-find-partial-timeout-trace"
    mkdir -p "$target_dir" "$mock_bin" "$trace_dir"
    touch "$target_dir/old.log"

    # The sudo shell function below answers every call. A real sudo stays
    # unreachable: anything that slips past it to PATH lands here and fails.
    cat > "$mock_bin/sudo" <<'MOCK'
#!/bin/bash
printf '%s\n' "$*" >> "$MOLE_SUDO_FIND_TRACE_DIR/real-sudo"
exit 99
MOCK
    chmod +x "$mock_bin/sudo"

    # Like safe_find_delete's partial-scan case: the stub leaves what the
    # bounded wrapper leaves on expiry (the printed prefix, then status 124)
    # instead of racing a mock's startup against a one-second budget. The
    # second pass is the positive control: a completed scan must reach the
    # privileged delete batch.
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        PATH="$mock_bin:$PATH" MOLE_SUDO_FIND_TRACE_DIR="$trace_dir" \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 MO_NO_OPLOG=1 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_privileged_path_has_mutable_ancestor() { return 1; }
sudo() {
    printf '%s\n' "$*" >> "$MOLE_SUDO_FIND_TRACE_DIR/scan-$SCAN_RC"
    [[ "${1:-}" == "-n" ]] && shift
    case "${1:-}" in
        true) return 0 ;;
        test)
            shift
            /bin/test "$@"
            ;;
        find)
            printf '%s\0' "$TARGET_DIR/old.log"
            return "$SCAN_RC"
            ;;
        /*) "$@" ;;
        xargs)
            cat > /dev/null
            return 0
            ;;
        *) return 99 ;;
    esac
}
for SCAN_RC in 124 0; do
    rc=0
    safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" "1" || rc=$?
    printf 'SCAN_RC=%s RC=%s\n' "$SCAN_RC" "$rc"
done
SCRIPT

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [ ! -e "$trace_dir/real-sudo" ] || return 1
    [[ "$output" == *"SCAN_RC=124 RC=124"* ]] || return 1
    local timed_out_calls completed_calls
    timed_out_calls=$(< "$trace_dir/scan-124")
    completed_calls=$(< "$trace_dir/scan-0")
    [[ "$timed_out_calls" == *"-n find $target_dir -maxdepth 1 -name *.log -type f -print0"* ]] || return 1
    [[ "$timed_out_calls" != *"xargs"* ]] || return 1
    [[ "$completed_calls" == *"-n xargs -0"* ]] || return 1
    [[ -e "$target_dir/old.log" ]]
}

@test "safe_sudo_find_delete bounds a stalled sudo batch removal" {
    local target_dir="$TEST_DIR/sudo-batch-timeout-target"
    local mock_bin="$TEST_DIR/sudo-batch-timeout-bin"
    local trace="$TEST_DIR/sudo-batch-timeout.trace"
    mkdir -p "$target_dir" "$mock_bin"
    touch "$target_dir/old.log"

    cat > "$mock_bin/sudo" <<'MOCK'
#!/bin/bash
set -u
[[ "${1:-}" == "-n" ]] && shift
case "${1:-}" in
    test)
        shift
        /bin/test "$@"
        ;;
    true)
        exit 0
        ;;
    find)
        printf '%s\0' "$TARGET_DIR/old.log"
        ;;
    */stat)
        exec "$@"
        ;;
    xargs)
        printf 'xargs %s\n' "$*" >> "$MOLE_SUDO_BATCH_TRACE"
        exec sleep 30
        ;;
    *)
        exit 99
        ;;
esac
MOCK
    chmod +x "$mock_bin/sudo"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        PATH="$mock_bin:$PATH" MOLE_SUDO_BATCH_TRACE="$trace" MOLE_TIMEOUT_DISK_VERIFY_SEC=1 \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_privileged_path_has_mutable_ancestor() { return 1; }
started=$(date +%s)
rc=0
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" "1" || rc=$?
elapsed=$(( $(date +%s) - started ))
printf 'RC=%s\nELAPSED=%s\n' "$rc" "$elapsed"
SCRIPT

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"RC=124"* ]] || return 1
    [[ "$(< "$trace")" == *"xargs xargs -0 /bin/sh -c"* ]] || return 1
    local elapsed="${output##*ELAPSED=}"
    [[ "$elapsed" =~ ^[0-9]+$ ]] || return 1
    [ "$elapsed" -lt 10 ]
}

@test "safe_sudo_find_delete stops before scanning when its deadline is exhausted" {
    local target_dir="$TEST_DIR/sudo-deadline-target"
    mkdir -p "$target_dir"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_privileged_path_has_mutable_ancestor() { return 1; }
sudo() {
    printf 'SUDO:%s\n' "$*"
    [[ "${1:-}" == "-n" ]] && shift
    case "${1:-}" in
        true) return 0 ;;
        test)
            shift
            command test "$@"
            ;;
        find | xargs)
            printf 'UNEXPECTED_WORK:%s\n' "$*"
            return 99
            ;;
        *) "$@" ;;
    esac
}
deadline=$SECONDS
rc=0
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" "1" "$deadline" || rc=$?
printf 'RC=%s\nCOUNT=%s\n' "$rc" "${MOLE_SAFE_SUDO_FIND_DELETE_COUNT:-unset}"
SCRIPT

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=124"* ]] || return 1
    [[ "$output" == *"COUNT=0"* ]] || return 1
    [[ "$output" != *"SUDO:"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_WORK"* ]]
}

@test "_mole_timeout_with_deadline clamps fractional timeouts to remaining whole seconds" {
    run env PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
# This case verifies the helper's clamp arithmetic, not command-substitution
# scheduling. Invoke it directly after resetting SECONDS so a loaded runner
# cannot spend part of the remaining window waiting to fork (#1791).
SECONDS=100
printf 'CLAMPED='
_mole_timeout_with_deadline 30.5 105
SECONDS=100
printf 'SHORT='
_mole_timeout_with_deadline 0.5 105
SECONDS=100
printf 'ZERO='
_mole_timeout_with_deadline 0 105
SECONDS=100
printf 'LEADING='
_mole_timeout_with_deadline 08.5 105
SCRIPT

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"CLAMPED=5"* ]] || return 1
    [[ "$output" == *"SHORT=0.5"* ]] || return 1
    [[ "$output" == *"ZERO=5"* ]] || return 1
    [[ "$output" == *"LEADING=5"* ]]
}

@test "get_path_size_kb bounds the app metadata fast path" {
    local app_dir="$TEST_DIR/Stalled.app"
    local mock_bin="$TEST_DIR/stalled-mdls-bin"
    local trace="$TEST_DIR/stalled-mdls.trace"
    mkdir -p "$app_dir" "$mock_bin"

    cat > "$mock_bin/mdls" <<'MOCK'
#!/bin/bash
printf 'mdls %s\n' "$*" >> "$MOLE_MDLS_TRACE"
exec sleep 4
MOCK
    chmod +x "$mock_bin/mdls"
    cat > "$mock_bin/du" <<'MOCK'
#!/bin/bash
printf 'UNEXPECTED_DU %s\n' "$*" >> "$MOLE_MDLS_TRACE"
exec sleep 4
MOCK
    chmod +x "$mock_bin/du"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" APP_DIR="$app_dir" \
        PATH="$mock_bin:$PATH" MOLE_MDLS_TRACE="$trace" \
        /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
started=$(date +%s)
set +e
# Budget must be >= 2s. SECONDS has whole-second granularity, so a 1s budget
# is really "until the next second boundary" and can collapse to nearly zero,
# returning 124 before mdls is ever spawned. Two seconds always leaves at
# least a full second for the probe, which is what this case asserts on.
size=$(get_path_size_kb "$APP_DIR" 2)
size_rc=$?
set -e
elapsed=$(( $(date +%s) - started ))
printf 'SIZE=%s\nRC=%s\nELAPSED=%s\n' "$size" "$size_rc" "$elapsed"
[[ $size_rc -eq 124 ]]
SCRIPT

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"SIZE="* ]] || return 1
    [[ "$output" == *"RC=124"* ]] || return 1
    [[ "$(< "$trace")" == *"$app_dir"* ]] || return 1
    [[ "$(< "$trace")" != *"UNEXPECTED_DU"* ]] || return 1
    local elapsed="${output##*ELAPSED=}"
    [[ "$elapsed" =~ ^[0-9]+$ ]] || return 1
    [ "$elapsed" -lt 4 ]
}

@test "safe_remove stops when a size probe is interrupted" {
    local app_dir="$TEST_DIR/Interrupted.app"
    mkdir -p "$app_dir"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" APP_DIR="$app_dir" \
        /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
run_with_timeout() {
    local _duration="$1"
    shift
    if [[ "${1:-}" == "mdls" ]]; then
        return 130
    fi
    "$@"
}
rm() {
    printf 'UNEXPECTED_REMOVE:%s\n' "$*"
    return 99
}
rc=0
safe_remove "$APP_DIR" true || rc=$?
printf 'RC=%s\n' "$rc"
[[ -d "$APP_DIR" ]]
SCRIPT

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=130"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_REMOVE"* ]]
}

@test "safe_sudo_find_delete propagates interrupts from every sudo preflight" {
    local target_dir="$TEST_DIR/sudo-preflight-interrupt-target"
    mkdir -p "$target_dir"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"

for fail_stage in initial_auth base base_auth link link_auth; do
    true_calls=0
    sudo() {
        [[ "${1:-}" == "-n" ]] && shift
        case "${1:-}" in
            true)
                true_calls=$((true_calls + 1))
                if [[ "$fail_stage" == "initial_auth" && $true_calls -eq 1 ]] || \
                    [[ "$fail_stage" == "base_auth" && $true_calls -eq 2 ]] || \
                    [[ "$fail_stage" == "link_auth" && $true_calls -eq 2 ]]; then
                    return 130
                fi
                return 0
                ;;
            test)
                shift
                if [[ "${1:-}" == "-d" ]]; then
                    [[ "$fail_stage" == "base" ]] && return 130
                    [[ "$fail_stage" == "base_auth" ]] && return 1
                elif [[ "${1:-}" == "-L" ]]; then
                    [[ "$fail_stage" == "link" ]] && return 130
                    [[ "$fail_stage" == "link_auth" ]] && return 1
                fi
                command test "$@"
                ;;
            find | xargs | rm)
                printf 'UNEXPECTED_PRIVILEGED_ACTION:%s\n' "$*"
                return 99
                ;;
            *) return 0 ;;
        esac
    }

    rc=0
    safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" || rc=$?
    printf '%s:%s\n' "$fail_stage" "$rc"
done
SCRIPT

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"initial_auth:130"* ]] || return 1
    [[ "$output" == *"base:130"* ]] || return 1
    [[ "$output" == *"base_auth:130"* ]] || return 1
    [[ "$output" == *"link:130"* ]] || return 1
    [[ "$output" == *"link_auth:130"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_PRIVILEGED_ACTION"* ]]
}

@test "safe_sudo_find_delete keeps a file refreshed after the initial age scan" {
    local target_dir="$TEST_DIR/sudo-age-refresh-target"
    local target_file="$target_dir/old.log"
    mkdir -p "$target_dir"
    touch "$target_file"
    touch -t "$(date -v-8d '+%Y%m%d%H%M.%S')" "$target_file"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" TARGET_FILE="$target_file" \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_privileged_path_has_mutable_ancestor() { return 1; }
sudo() {
    [[ "${1:-}" == "-n" ]] && shift
    case "${1:-}" in
        true) return 0 ;;
        test)
            shift
            command test "$@"
            ;;
        find)
            printf '%s\0' "$TARGET_FILE"
            touch "$TARGET_FILE"
            ;;
        */stat) "$@" ;;
        xargs)
            shift
            command xargs "$@"
            ;;
        *) "$@" ;;
    esac
}
rc=0
safe_sudo_find_delete "$TARGET_DIR" "*.log" "1" "f" "1" || rc=$?
printf 'RC=%s\nCOUNT=%s\n' "$rc" "${MOLE_SAFE_SUDO_FIND_DELETE_COUNT:-unset}"
[[ -e "$TARGET_FILE" ]] && printf 'SURVIVED\n'
cat "$HOME/Library/Logs/mole/operations.log" 2> /dev/null || true
SCRIPT

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1"* ]] || return 1
    [[ "$output" == *"COUNT=0"* ]] || return 1
    [[ "$output" == *"SURVIVED"* ]] || return 1
    [[ "$output" != *"REMOVED $target_file"* ]]
}

@test "safe_sudo_find_delete keeps a path replaced after identity capture" {
    local target_dir="$TEST_DIR/sudo-identity-replace-target"
    local target_file="$target_dir/old.log"
    mkdir -p "$target_dir"
    printf 'original\n' > "$target_file"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" TARGET_FILE="$target_file" \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_privileged_path_has_mutable_ancestor() { return 1; }
sudo() {
    [[ "${1:-}" == "-n" ]] && shift
    case "${1:-}" in
        true) return 0 ;;
        test)
            shift
            command test "$@"
            ;;
        find) printf '%s\0' "$TARGET_FILE" ;;
        */stat)
            identity=$("$@")
            if [[ ! -e "$TARGET_DIR/replaced.marker" ]]; then
                : > "$TARGET_DIR/replaced.marker"
                /bin/rm -f "$TARGET_FILE"
                printf 'replacement\n' > "$TARGET_FILE"
            fi
            printf '%s\n' "$identity"
            ;;
        xargs)
            shift
            command xargs "$@"
            ;;
        *) "$@" ;;
    esac
}
rc=0
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" "1" || rc=$?
printf 'RC=%s\nCOUNT=%s\nCONTENT=%s\n' "$rc" \
    "${MOLE_SAFE_SUDO_FIND_DELETE_COUNT:-unset}" "$(< "$TARGET_FILE")"
SCRIPT

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1"* ]] || return 1
    [[ "$output" == *"COUNT=0"* ]] || return 1
    [[ "$output" == *"CONTENT=replacement"* ]]
}

@test "safe_sudo_find_delete does not run an accumulated batch after a probe timeout" {
    local target_dir="$TEST_DIR/sudo-probe-timeout-target"
    local first_file="$target_dir/first.log"
    local second_file="$target_dir/second.log"
    local marker="$target_dir/first-stat-complete"
    mkdir -p "$target_dir"
    touch "$first_file" "$second_file"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        FIRST_FILE="$first_file" SECOND_FILE="$second_file" MARKER="$marker" \
        /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
MOLE_TEST_MODE=0
MOLE_TEST_NO_AUTH=0
_mole_privileged_path_has_mutable_ancestor() { return 1; }
should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
sudo() {
    [[ "${1:-}" == "-n" ]] && shift
    case "${1:-}" in
        true) return 0 ;;
        test) command "$@" ;;
        find) printf '%s\0%s\0' "$FIRST_FILE" "$SECOND_FILE" ;;
        /usr/bin/stat)
            if [[ ! -e "$MARKER" ]]; then
                touch "$MARKER"
                command "$@"
            else
                printf 'STAT_TIMEOUT\n'
                return 124
            fi
            ;;
        xargs)
            printf 'UNEXPECTED_BATCH\n'
            return 99
            ;;
        *) command "$@" ;;
    esac
}

rc=0
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" "1" || rc=$?
printf 'RC=%s\n' "$rc"
[[ -e "$FIRST_FILE" && -e "$SECOND_FILE" ]]
SCRIPT

    [ "$status" -eq 0 ] || return 1
    [ -e "$marker" ] || return 1
    [[ "$output" == *"RC=124"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_BATCH"* ]]
}

@test "safe_sudo_find_delete logs only acknowledged removals from a timed-out batch" {
    local target_dir="$TEST_DIR/sudo-partial-ack-target"
    local mock_bin="$TEST_DIR/sudo-partial-ack-bin"
    local trace="$TEST_DIR/sudo-partial-ack.trace"
    mkdir -p "$target_dir" "$mock_bin"
    touch "$target_dir/a.log" "$target_dir/b.log"

    cat > "$mock_bin/sudo" <<'MOCK'
#!/bin/bash
set -u
[[ "${1:-}" == "-n" ]] && shift
case "${1:-}" in
    true) exit 0 ;;
    test)
        shift
        /bin/test "$@"
        ;;
    find)
        printf '%s\0' "$TARGET_DIR/a.log" "$TARGET_DIR/b.log"
        ;;
    */stat) exec "$@" ;;
    xargs)
        printf 'xargs-started\n' >> "$MOLE_PARTIAL_ACK_TRACE"
        IFS= read -r -d '' record || exit 1
        rest=${record#*:}
        rest=${rest#*:}
        path=${rest#*:}
        /bin/rm -f -- "$path" || exit 1
        printf '%s\0' "$path"
        exec sleep 4
        ;;
    *) exit 99 ;;
esac
MOCK
    chmod +x "$mock_bin/sudo"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        PATH="$mock_bin:$PATH" MOLE_PARTIAL_ACK_TRACE="$trace" \
        MOLE_TIMEOUT_DISK_VERIFY_SEC=1 MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 \
        /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_privileged_path_has_mutable_ancestor() { return 1; }
rc=0
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" "1" || rc=$?
printf 'RC=%s\nCOUNT=%s\n' "$rc" "${MOLE_SAFE_SUDO_FIND_DELETE_COUNT:-unset}"
cat "$HOME/Library/Logs/mole/operations.log" 2> /dev/null || true
SCRIPT

    [ "$status" -eq 0 ] || return 1
    [[ "$(< "$trace")" == "xargs-started" ]] || return 1
    [[ "$output" == *"RC=124"* ]] || return 1
    [[ "$output" == *"COUNT=1"* ]] || return 1
    [ ! -e "$target_dir/a.log" ] || return 1
    [ -e "$target_dir/b.log" ] || return 1
    [[ "$output" == *"REMOVED $target_dir/a.log (batch)"* ]] || return 1
    [[ "$output" != *"REMOVED $target_dir/b.log (batch)"* ]]
}

@test "safe_sudo_find_delete rejects an oversized privileged batch before deletion" {
    local target_dir="$TEST_DIR/sudo-batch-limit-target"
    mkdir -p "$target_dir"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        MO_NO_OPLOG=1 MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 \
        /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_mole_privileged_path_has_mutable_ancestor() { return 1; }
_mole_privileged_batch_max_items() { printf '4\n'; }
sudo() {
    [[ "${1:-}" == "-n" ]] && shift
    case "${1:-}" in
        true) return 0 ;;
        test)
            shift
            command test "$@"
            ;;
        find)
            i=0
            while [[ $i -lt 5 ]]; do
                printf '%s\0' "$TARGET_DIR/item-$i.log"
                i=$((i + 1))
            done
            ;;
        */stat) printf '1:2:3\n' ;;
        xargs)
            printf 'UNEXPECTED_BATCH:%s\n' "$*"
            return 99
            ;;
        *) "$@" ;;
    esac
}
rc=0
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" "1" || rc=$?
printf 'RC=%s\nCOUNT=%s\n' "$rc" "${MOLE_SAFE_SUDO_FIND_DELETE_COUNT:-unset}"
SCRIPT

    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1"* ]] || return 1
    [[ "$output" == *"COUNT=0"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_BATCH"* ]]
}

@test "safe_sudo_find_delete never previews or removes active powerlog database aliases" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"

active_db="/private/var/db/powerlog/Library/PerfPowerTelemetry/BackgroundProcessing/CurrentBackgroundProcessingDB.BGSQL"
active_dot_alias="${active_db%/*}/./${active_db##*/}"
active_case_alias="${active_db%/*}/currentbackgroundprocessingdb.bgsql"
archived_db="/private/var/db/powerlog/Library/PerfPowerTelemetry/BackgroundProcessing/ArchivedBackgroundProcessingDB.BGSQL"
xcode_db="/private/var/db/powerlog/Library/PerfPowerTelemetry/XcodeOrganizer/CurrentXcodeOrganizerDB.XCSQL"

should_protect_path() { return 1; }
is_path_whitelisted() { return 1; }
_mole_privileged_path_has_mutable_ancestor() { return 1; }
record_dry_run_cleanup_target() { printf 'PREVIEW:%s\n' "$1"; }
safe_sudo_remove() { printf 'REMOVE:%s\n' "$1"; }
append_log_lines() {
    shift
    printf '%s\n' "$@"
}

sudo() {
    [[ "${1:-}" == "-n" ]] && shift
    case "${1:-}" in
        test)
            [[ "${2:-}" == "-d" ]]
            ;;
        find)
            printf '%s\0' "$active_db" "$active_db-wal" "$active_db-shm" "$active_dot_alias" "$active_case_alias" "$archived_db" "$xcode_db"
            ;;
        */stat)
            printf '1:2:3\n'
            ;;
        xargs)
            while IFS= read -r -d '' record; do
                rest=${record#*:}
                rest=${rest#*:}
                rest=${rest#*:}
                printf '%s\0' "$rest"
            done
            ;;
        *)
            return 0
            ;;
    esac
}

MOLE_DRY_RUN=1
safe_sudo_find_delete "/private/var/db/powerlog" "*" "7" "f"
MOLE_DRY_RUN=0
safe_sudo_find_delete "/private/var/db/powerlog/." "*" "7" "f"
SCRIPT

    [ "$status" -eq 0 ]
    [[ "$output" == *"PREVIEW:/private/var/db/powerlog/Library/PerfPowerTelemetry/BackgroundProcessing/ArchivedBackgroundProcessingDB.BGSQL"* ]] || return 1
    [[ "$output" == *"REMOVED /private/var/db/powerlog/Library/PerfPowerTelemetry/BackgroundProcessing/ArchivedBackgroundProcessingDB.BGSQL (batch)"* ]] || return 1
    [[ "$output" != *"CurrentBackgroundProcessingDB.BGSQL"* ]] || return 1
    [[ "$output" != *"currentbackgroundprocessingdb.bgsql"* ]] || return 1
    [[ "$output" != *"/./CurrentBackgroundProcessingDB.BGSQL"* ]] || return 1
    [[ "$output" != *"CurrentXcodeOrganizerDB.XCSQL"* ]]
}

@test "safe_sudo_find_delete batches file removals into one xargs rm" {
    local target_dir="$TEST_DIR/sudo-batch-target"
    local script="$TEST_DIR/sudo-batch-test.sh"
    mkdir -p "$target_dir"
    touch "$target_dir/a.log" "$target_dir/b.log" "$target_dir/keep.log"

    cat > "$script" <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
: > "$OPERATIONS_LOG_FILE"
log_operation_session_start clean
TRACE="$TARGET_DIR/sudo.trace"
> "$TRACE"

# This test models a root-owned, non-user-writable log tree.
_mole_privileged_path_has_mutable_ancestor() { return 1; }

WHITELIST_PATTERNS=("$TARGET_DIR/keep.log")

sudo() {
    printf 'SUDO:%s\n' "$*" >> "$TRACE"
    if [[ "${1:-}" != "-n" ]]; then
        echo "INTERACTIVE_SUDO:$*" >&2
        return 99
    fi
    shift
    case "${1:-}" in
        test)
            shift
            command test "$@"
            ;;
        find)
            printf '%s\0' "$TARGET_DIR/a.log" "$TARGET_DIR/b.log" "$TARGET_DIR/keep.log"
            ;;
        xargs)
            shift
            command xargs "$@"
            ;;
        rm)
            echo "SINGLE_FILE_RM:$*"
            return 0
            ;;
        *)
            "$@"
            ;;
    esac
}
export -f sudo

set +e
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f"
rc=$?
set -e
printf 'RC=%s\n' "$rc"
[[ -e "$TARGET_DIR/a.log" ]] && echo "A_SURVIVED" || echo "A_REMOVED"
[[ -e "$TARGET_DIR/b.log" ]] && echo "B_SURVIVED" || echo "B_REMOVED"
[[ -e "$TARGET_DIR/keep.log" ]] && echo "KEEP_SURVIVED" || echo "KEEP_REMOVED"
printf 'XARGS_CALLS=%s\n' "$(grep -c 'SUDO:-n xargs' "$TRACE" || true)"
cat "$TRACE"
echo "--OPLOG--"
cat "$HOME/Library/Logs/mole/operations.log" 2> /dev/null || true
log_operation_session_end clean 2 0
exit 0
SCRIPT
    chmod +x "$script"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc "$script"

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=0"* ]] || return 1
    [[ "$output" == *"A_REMOVED"* ]] || return 1
    [[ "$output" == *"B_REMOVED"* ]] || return 1
    [[ "$output" == *"KEEP_SURVIVED"* ]] || return 1
    [[ "$output" == *"XARGS_CALLS=1"* ]] || return 1
    [[ "$output" != *"SINGLE_FILE_RM"* ]] || return 1
    [[ "$output" == *"REMOVED $target_dir/a.log (batch)"* ]] || return 1
    [[ "$output" == *"REMOVED $target_dir/b.log (batch)"* ]] || return 1
    [[ "$output" != *"INTERACTIVE_SUDO"* ]] || return 1

    run env HOME="$HOME" MOLE_TEST_NO_AUTH=1 "$PROJECT_ROOT/mole" history --json
    [[ "$status" -eq 0 ]] || { echo "$output"; return 1; }
    printf '%s\n' "$output" | python3 -c '
import json, sys
sessions = json.load(sys.stdin)["sessions"]
assert len(sessions) == 1, sessions
assert sessions[0]["run_id"], sessions
assert sessions[0]["actions"]["removed"] == 2, sessions
'
}

@test "safe_sudo_find_delete reports a failed batch without logging REMOVED" {
    local target_dir="$TEST_DIR/sudo-batch-lapsed"
    local script="$TEST_DIR/sudo-batch-lapsed-test.sh"
    mkdir -p "$target_dir"
    touch "$target_dir/a.log" "$target_dir/b.log"

    cat > "$script" <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"

# This test models a root-owned, non-user-writable log tree.
_mole_privileged_path_has_mutable_ancestor() { return 1; }

# Simulate a credential that dies at the batch xargs rm. Nothing was deleted,
# so the helper must return the failure and no REMOVED lines may be logged.
sudo() {
    if [[ "${1:-}" != "-n" ]]; then
        echo "INTERACTIVE_SUDO:$*" >&2
        return 99
    fi
    shift
    case "${1:-}" in
        true)
            return 0
            ;;
        test)
            shift
            command test "$@"
            ;;
        find)
            printf '%s\0' "$TARGET_DIR/a.log" "$TARGET_DIR/b.log"
            ;;
        xargs)
            return 1
            ;;
        *)
            return 1
            ;;
    esac
}
export -f sudo

set +e
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f"
rc=$?
set -e
printf 'RC=%s\n' "$rc"
[[ -e "$TARGET_DIR/a.log" ]] && echo "A_SURVIVED" || echo "A_REMOVED"
echo "--OPLOG--"
cat "$HOME/Library/Logs/mole/operations.log" 2> /dev/null || true
exit 0
SCRIPT
    chmod +x "$script"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc "$script"

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=1"* ]] || return 1
    [[ "$output" == *"A_SURVIVED"* ]] || return 1
    # Scope to this test's paths: the oplog HOME is shared across tests and
    # earlier batch tests legitimately log their own "(batch)" lines.
    [[ "$output" != *"REMOVED $target_dir/a.log (batch)"* ]] || return 1
    [[ "$output" != *"REMOVED $target_dir/b.log (batch)"* ]] || return 1
    [[ "$output" != *"INTERACTIVE_SUDO"* ]] || return 1
}

@test "safe_sudo_find_delete batch path survives set -e with oplog disabled" {
    local target_dir="$TEST_DIR/sudo-batch-nooplog"
    local script="$TEST_DIR/sudo-batch-nooplog-test.sh"
    mkdir -p "$target_dir"
    touch "$target_dir/a.log"

    cat > "$script" <<'SCRIPT'
set -euo pipefail
# Diagnostic breadcrumbs: this test fails only on some CI images, so record
# which bash runs the script and every mock invocation on a side channel.
printf 'DIAG_BASH:%s (%s)\n' "$BASH_VERSION" "$(command -v bash || true)"
source "$PROJECT_ROOT/lib/core/common.sh"
echo "DIAG_SOURCED"

# This test models a root-owned, non-user-writable log tree.
_mole_privileged_path_has_mutable_ancestor() { return 1; }

sudo() {
    printf 'MOCK_CALL:%s\n' "$*" >> "$TARGET_DIR/mock.trace" || true
    if [[ "${1:-}" != "-n" ]]; then
        echo "INTERACTIVE_SUDO:$*" >&2
        return 99
    fi
    shift
    case "${1:-}" in
        test)
            shift
            command test "$@"
            ;;
        find)
            printf '%s\0' "$TARGET_DIR/a.log"
            ;;
        xargs)
            shift
            command xargs "$@"
            ;;
        *)
            "$@"
            ;;
    esac
}
export -f sudo

echo "DIAG_MOCK_READY"
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f"
# Reaching this line proves the disabled-oplog branch did not trip set -e.
echo "SURVIVED_SET_E"
[[ -e "$TARGET_DIR/a.log" ]] && echo "A_SURVIVED" || echo "A_REMOVED"
exit 0
SCRIPT
    chmod +x "$script"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        MO_NO_OPLOG=1 MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc "$script"

    # This test is environment-sensitive (errexit active during the call); on
    # failure surface the exit status, captured output, and an xtrace replay
    # so CI logs show where the inner script died instead of a bare rc check.
    if [ "$status" -ne 0 ]; then
        echo "inner script exit status: $status"
        echo "--- captured output ---"
        echo "$output"
        echo "--- mock call trace ---"
        cat "$target_dir/mock.trace" 2> /dev/null || echo "(no mock trace)"
        echo "--- xtrace replay (tail) ---"
        env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
            MO_NO_OPLOG=1 MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 \
            /bin/bash --noprofile --norc -x "$script" 2>&1 | tail -60 || true
        return 1
    fi
    [[ "$output" == *"SURVIVED_SET_E"* ]] || return 1
    [[ "$output" == *"A_REMOVED"* ]] || return 1
}

@test "safe_sudo_find_delete reports batch failure without a second removal pass" {
    local target_dir="$TEST_DIR/sudo-batch-fallback"
    local script="$TEST_DIR/sudo-batch-fallback-test.sh"
    mkdir -p "$target_dir"
    touch "$target_dir/stuck.log"

    cat > "$script" <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
TRACE="$TARGET_DIR/sudo.trace"
> "$TRACE"

# This test models a root-owned, non-user-writable log tree.
_mole_privileged_path_has_mutable_ancestor() { return 1; }

sudo() {
    printf 'SUDO:%s\n' "$*" >> "$TRACE"
    if [[ "${1:-}" != "-n" ]]; then
        echo "INTERACTIVE_SUDO:$*" >&2
        return 99
    fi
    shift
    case "${1:-}" in
        test)
            shift
            command test "$@"
            ;;
        find)
            printf '%s\0' "$TARGET_DIR/stuck.log"
            ;;
        xargs)
            # Simulate a batch failure without deleting anything.
            return 1
            ;;
        du)
            shift
            command du "$@"
            ;;
        rm)
            return 0
            ;;
        *)
            "$@"
            ;;
    esac
}
export -f sudo

set +e
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f"
rc=$?
set -e
printf 'RC=%s\n' "$rc"
cat "$TRACE"
exit 0
SCRIPT
    chmod +x "$script"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc "$script"

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=1"* ]] || return 1
    [[ "$output" == *"SUDO:-n xargs -0 /bin/sh -c"* ]] || return 1
    [[ "$output" != *"SUDO:-n rm -rf $target_dir/stuck.log"* ]] || return 1
    [[ "$output" != *"INTERACTIVE_SUDO"* ]] || return 1
}

@test "safe_sudo_find_delete never elevates deletion below a user-writable parent" {
    local target_dir="$TEST_DIR/sudo-mutable-parent"
    local script="$TEST_DIR/sudo-mutable-parent-test.sh"
    mkdir -p "$target_dir"
    touch "$target_dir/old.log"

    cat > "$script" <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
TRACE="$TARGET_DIR/sudo.trace"
> "$TRACE"

sudo() {
    printf 'SUDO:%s\n' "$*" >> "$TRACE"
    [[ "${1:-}" == "-n" ]] || return 99
    shift
    case "${1:-}" in
        test)
            shift
            command test "$@"
            ;;
        find)
            printf '%s\0' "$TARGET_DIR/old.log"
            ;;
        xargs | rm)
            echo "PRIVILEGED_DELETE:$*"
            return 0
            ;;
        *)
            "$@"
            ;;
    esac
}
export -f sudo

rc=0
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" || rc=$?
printf 'RC=%s\n' "$rc"
[[ -e "$TARGET_DIR/old.log" ]] && echo "TARGET_SURVIVED" || echo "TARGET_REMOVED"
cat "$TRACE"
SCRIPT
    chmod +x "$script"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc "$script"

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=0"* ]] || return 1
    [[ "$output" == *"TARGET_REMOVED"* ]] || return 1
    [[ "$output" != *"PRIVILEGED_DELETE"* ]] || return 1
    [[ "$output" != *"SUDO:-n xargs"* ]] || return 1
    [[ "$output" != *"SUDO:-n rm"* ]] || return 1
}

@test "safe_sudo_find_delete treats a user-owned 0555 parent as mutable" {
    local target_dir="$TEST_DIR/sudo-owner-mutable-parent"
    local script="$TEST_DIR/sudo-owner-mutable-parent-test.sh"
    mkdir -p "$target_dir"
    touch "$target_dir/old.log"
    chmod 0555 "$target_dir"

    cat > "$script" <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
TRACE="${TARGET_DIR}.sudo.trace"
> "$TRACE"

sudo() {
    printf 'SUDO:%s\n' "$*" >> "$TRACE"
    [[ "${1:-}" == "-n" ]] || return 99
    shift
    case "${1:-}" in
        test)
            shift
            command test "$@"
            ;;
        find)
            printf '%s\0' "$TARGET_DIR/old.log"
            ;;
        xargs | rm)
            echo "PRIVILEGED_DELETE:$*"
            return 0
            ;;
        *)
            "$@"
            ;;
    esac
}
export -f sudo

rc=0
safe_sudo_find_delete "$TARGET_DIR" "*.log" "0" "f" || rc=$?
printf 'RC=%s\n' "$rc"
[[ -e "$TARGET_DIR/old.log" ]] && echo "TARGET_SURVIVED" || echo "TARGET_REMOVED"
cat "$TRACE"
SCRIPT
    chmod +x "$script"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc "$script"
    chmod 0755 "$target_dir"

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=1"* ]] || return 1
    [[ "$output" == *"TARGET_SURVIVED"* ]] || return 1
    [[ "$output" != *"PRIVILEGED_DELETE"* ]] || return 1
    [[ "$output" != *"SUDO:-n xargs"* ]] || return 1
    [[ "$output" != *"SUDO:-n rm"* ]] || return 1
}

@test "safe_sudo_remove honours the cleanup whitelist before sudo" {
    local target="$TEST_DIR/whitelisted-sudo-target"
    mkdir -p "$target"
    touch "$target/data"

    # shellcheck disable=SC2016  # The inner bash expands TARGET and PROJECT_ROOT.
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET="$target" \
        MOLE_TEST_MODE=0 MOLE_TEST_NO_AUTH=0 /bin/bash --noprofile --norc -c '
            set -euo pipefail
            source "$PROJECT_ROOT/lib/core/common.sh"
            is_path_whitelisted() { [[ "$1" == "$TARGET" ]]; }
            sudo() {
                echo "UNEXPECTED_SUDO:$*"
                return 99
            }
            set +e
            safe_sudo_remove "$TARGET"
            rc=$?
            set -e
            printf "RC=%s\n" "$rc"
            [[ -e "$TARGET/data" ]] && echo "TARGET_SURVIVED"
        '

    [ "$status" -eq 0 ]
    [[ "$output" == *"RC=1"* ]] || return 1
    [[ "$output" == *"TARGET_SURVIVED"* ]] || return 1
    [[ "$output" != *"UNEXPECTED_SUDO"* ]]
}

@test "safe_find_delete rejects symlinked directory" {
    local real_dir="$TEST_DIR/real"
    local link_dir="$TEST_DIR/link"
    mkdir -p "$real_dir"
    ln -s "$real_dir" "$link_dir"

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; safe_find_delete '$link_dir' '*.tmp' 7 'f' 2>&1"
    [ "$status" -eq 1 ]
    [[ "$output" == *"symlink"* ]] || return 1

    rm -rf "$link_dir" "$real_dir"
}

@test "safe_find_delete validates type filter" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; safe_find_delete '$TEST_DIR' '*.tmp' 7 'x' 2>&1"
    [ "$status" -eq 1 ]
    [[ "$output" == *"Invalid type filter"* ]]
}

@test "safe_find_delete deletes old files" {
    local old_file="$TEST_DIR/old.tmp"
    local new_file="$TEST_DIR/new.tmp"

    touch "$old_file"
    touch "$new_file"

    touch -t "$(date -v-8d '+%Y%m%d%H%M.%S' 2>/dev/null || date -d '8 days ago' '+%Y%m%d%H%M.%S')" "$old_file" 2>/dev/null || true

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; safe_find_delete '$TEST_DIR' '*.tmp' 7 'f'"
    [ "$status" -eq 0 ]
    [ ! -e "$old_file" ] || return 1
    [ -e "$new_file" ]
}

@test "safe_find_delete discards a timed-out partial scan" {
    local target_dir="$TEST_DIR/find-partial-target"
    local target_file="$target_dir/old.tmp"
    local trace="$TEST_DIR/find-partial.trace"
    mkdir -p "$target_dir"
    touch "$target_file"

    # run_with_timeout is replaced by what it leaves behind on expiry: the
    # prefix the child printed, then status 124. A real mock find under a
    # real budget raced its own startup against the clock, and the real
    # wrapper has its own cases in core_timeout.bats. The second pass is the
    # positive control: the same output with status 0 must reach the delete.
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_DIR="$target_dir" \
        TARGET_FILE="$target_file" MOLE_FIND_TRACE="$trace" \
        MOLE_TIMEOUT_DISK_VERIFY_SEC=7 /bin/bash --noprofile --norc <<'SCRIPT'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
run_with_timeout() {
    printf '%s\n' "$*" >> "$MOLE_FIND_TRACE"
    printf '%s\0' "$TARGET_FILE"
    return "$SCAN_RC"
}
safe_remove() {
    printf 'DELETE:%s\n' "$1"
}
for SCAN_RC in 124 0; do
    rc=0
    safe_find_delete "$TARGET_DIR" "*.tmp" "0" "f" || rc=$?
    printf 'SCAN_RC=%s RC=%s\n' "$SCAN_RC" "$rc"
done
SCRIPT

    [ "$status" -eq 0 ] || return 1
    local first_call
    read -r first_call < "$trace"
    [[ "$first_call" == "7 find $target_dir -maxdepth 5 -name *.tmp -type f -print0" ]] || return 1
    [[ "$output" == *"SCAN_RC=124 RC=124"* ]] || return 1
    local timed_out_pass="${output%%SCAN_RC=124 RC=124*}"
    [[ "$timed_out_pass" != *"DELETE:"* ]] || return 1
    [[ "$output" == *"DELETE:$target_file"*"SCAN_RC=0 RC=0"* ]]
}

@test "safe_find_delete works when app protection is not loaded" {
    local old_file="$TEST_DIR/file-ops-only.tmp"
    touch "$old_file"
    touch -t "$(date -v-8d '+%Y%m%d%H%M.%S' 2>/dev/null || date -d '8 days ago' '+%Y%m%d%H%M.%S')" "$old_file" 2>/dev/null || true

    run /bin/bash --noprofile --norc <<EOF
set -euo pipefail
source "$PROJECT_ROOT/lib/core/file_ops.sh"
safe_find_delete "$TEST_DIR" "*.tmp" 7 "f"
EOF

    [ "$status" -eq 0 ]
    [ ! -e "$old_file" ]
}

@test "MOLE_* constants are defined" {
    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; echo \$MOLE_TEMP_FILE_AGE_DAYS"
    [ "$status" -eq 0 ]
    [ "$output" = "7" ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; echo \$MOLE_MAX_PARALLEL_JOBS"
    [ "$status" -eq 0 ]
    [ "$output" = "15" ]

    run /bin/bash -c "source '$PROJECT_ROOT/lib/core/common.sh'; echo \$MOLE_TM_BACKUP_SAFE_HOURS"
    [ "$status" -eq 0 ]
    [ "$output" = "48" ]
}

# One vendor's Squirrel `ShipIt` used to claim another vendor's cache: the old
# probe accepted the bare last DNS label (`pgrep -x ShipIt`), and Claude's
# running ShipIt made Mole treat VS Code's idle cache as live. Measured on a
# real process table, leaf-only matching called 34 of 59 idle caches busy.
# Parity with the Mac app's ProcessGuard.processListMentionsCacheOwner.
@test "cache owner probe requires corroboration for a shared leaf name (#1390)" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/file_ops.sh"
# Squirrel passes the owning bundle id as argv[1], which is the real reason
# the running copy is identifiable at all. Copied from an actual `ps` line.
ps() {
    cat <<'TABLE'
  PID  PPID COMM             ARGS
  501     1 /Applications/Claude.app/Contents/Frameworks/Squirrel.framework/Resources/ShipIt /Applications/Claude.app/Contents/Frameworks/Squirrel.framework/Resources/ShipIt com.anthropic.claudefordesktop.ShipIt
  502     1 /System/Library/PrivateFrameworks/DataAccess.framework/Support/dataaccessd /System/Library/PrivateFrameworks/DataAccess.framework/Support/dataaccessd
  503     1 /usr/libexec/syncdefaultsd /usr/libexec/syncdefaultsd
TABLE
}
state=0
_mole_user_cache_owner_process_state "com.microsoft.VSCode.ShipIt" || state=$?
printf 'SHIPIT=%s\n' "$state"
state=0
_mole_user_cache_owner_process_state "com.plausiblelabs.crashreporter.data" || state=$?
printf 'DATA=%s\n' "$state"
state=0
_mole_user_cache_owner_process_state "com.anthropic.claudefordesktop.ShipIt" || state=$?
printf 'CLAUDE=%s\n' "$state"
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"SHIPIT=1"* ]] || return 1
    [[ "$output" == *"DATA=1"* ]] || return 1
    # The same line names both `ShipIt` and `Claude`, so this one is real.
    [[ "$output" == *"CLAUDE=0"* ]]
}

# The reason the probe exists: AcCoreConsole registers no NSRunningApplication
# and its cache dir is com.autodesk.AcCoreConsole, so the leaf plus the vendor
# on the same argv line is the only available evidence.
@test "cache owner probe still catches a corroborated helper (#1390)" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/file_ops.sh"
ps() {
    cat <<'TABLE'
  PID  PPID COMM             ARGS
  601     1 /Applications/Autodesk Fusion.app/Contents/MacOS/AcCoreConsole /Applications/Autodesk Fusion.app/Contents/MacOS/AcCoreConsole
TABLE
}
state=0
_mole_user_cache_owner_process_state "com.autodesk.AcCoreConsole" || state=$?
printf 'HELPER=%s\n' "$state"
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
	[[ "$output" == *"HELPER=0"* ]]
}

# Shape 2 reads every "Brave Origin Nightly" line as com.brave.Browser.nightly:
# same vendor, same last label, different app, so one channel kept the other's
# cache busy for as long as it ran. A line whose executable lives in an app
# bundle, at any depth below an application root, is attributed by that
# bundle's identifier instead, taken from the first field in line order. The
# owner's own bundle (even when a later argument names another app), a nested
# app that extends the owner's id, an executable named after the label (the
# AcCoreConsole shape) and an unreadable bundle all still count. The comm
# column is the 16-byte kernel name, as ps prints it.
@test "cache owner probe attributes an app bundle's lines by its identifier" {
    local apps="$HOME/Applications"
    local name id
    while IFS='|' read -r name id; do
        mkdir -p "$apps/$name/Contents/MacOS"
        [[ -z "$id" ]] || /usr/libexec/PlistBuddy -c "Add :CFBundleIdentifier string $id" \
            "$apps/$name/Contents/Info.plist" > /dev/null
    done <<'APPS'
Brave Browser Nightly.app|com.brave.Browser.nightly
Browsers/Brave Origin Nightly.app|com.brave.Browser.origin.nightly
Karabiner-Elements.app|org.pqrs.Karabiner-Elements
Autodesk Fusion.app|com.autodesk.fusion360
Broken.app|
APPS
    # Any readable bundle under /Applications stands in for an unrelated app
    # that a later argument can name.
    local installed="" candidate
    for candidate in /Applications/*.app; do
        plutil -extract CFBundleIdentifier raw -o - "$candidate/Contents/Info.plist" > /dev/null 2>&1 || continue
        installed="$candidate"
        break
    done
    [[ -n "$installed" ]] || skip "no readable app bundle under /Applications"
    local origin="$apps/Browsers/Brave Origin Nightly.app/Contents/MacOS/Brave Origin Nightly"
    local origin_helper="$apps/Browsers/Brave Origin Nightly.app/Contents/Frameworks/Brave Origin Nightly Framework.framework/Versions/154.1.98.11/Helpers/Brave Origin Nightly Helper (Renderer).app/Contents/MacOS/Brave Origin Nightly Helper (Renderer)"
    local nightly="$apps/Brave Browser Nightly.app/Contents/MacOS/Brave Browser Nightly"
    local settings="$apps/Karabiner-Elements.app/Contents/Resources/Karabiner-Elements Settings.app/Contents/MacOS/Karabiner-Elements Settings"
    local console="$apps/Autodesk Fusion.app/Contents/MacOS/AcCoreConsole"
    local broken="$apps/Broken.app/Contents/MacOS/Brave Nightly Beta"
    printf '  PID  PPID COMM ARGS\n  701     1 %s %s\n  702     1 %s %s --type=renderer\n' \
        "${origin:0:16}" "$origin" "${origin_helper:0:16}" "$origin_helper" > "$HOME/table-sibling"
    printf '  PID  PPID COMM ARGS\n  701     1 %s %s\n  703     1 %s %s\n' \
        "${origin:0:16}" "$origin" "${nightly:0:16}" "$nightly" > "$HOME/table-owner"
    printf '  PID  PPID COMM ARGS\n  704     1 %s %s %s/Contents/MacOS/Unrelated\n' \
        "${nightly:0:16}" "$nightly" "$installed" > "$HOME/table-later"
    printf '  PID  PPID COMM ARGS\n  705     1 %s %s\n' "${settings:0:16}" "$settings" > "$HOME/table-nested"
    printf '  PID  PPID COMM ARGS\n  706     1 %s %s\n' "${console:0:16}" "$console" > "$HOME/table-helper"
    printf '  PID  PPID COMM ARGS\n  707     1 %s %s\n' "${broken:0:16}" "$broken" > "$HOME/table-broken"

    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/file_ops.sh"
ps() { cat "$HOME/$TABLE"; }
probe() {
    local state=0
    _mole_reset_process_snapshot
    TABLE="$1"
    _mole_user_cache_owner_process_state "$2" || state=$?
    printf '%s %s=%s\n' "$1" "$2" "$state"
}
probe table-sibling com.brave.Browser.nightly
probe table-sibling com.brave.Browser.origin.nightly
probe table-owner com.brave.Browser.nightly
probe table-later com.brave.Browser.nightly
probe table-nested org.pqrs.Karabiner-Elements.Settings
probe table-helper com.autodesk.AcCoreConsole
probe table-broken com.brave.Browser.nightly
printf '  PID PPID COMM ARGS\n  708 1 /opt/BraveNightly /opt/BraveNightly --label Brave --channel Nightly --open %s/Contents/MacOS/Other\n' "$HOME/Applications/Brave Browser Nightly.app" > "$HOME/table-outside"
probe table-outside com.brave.Browser.origin.nightly
printf '  PID PPID COMM ARGS\n  709 1 /Applications/Br /Applications/BraveLauncher --label Brave --channel Nightly --open %s/Contents/MacOS/Other\n' "$HOME/Applications/Brave Browser Nightly.app" > "$HOME/table-launcher"
probe table-launcher com.brave.Browser.origin.nightly
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"table-sibling com.brave.Browser.nightly=1"* ]] || return 1
    [[ "$output" == *"table-sibling com.brave.Browser.origin.nightly=0"* ]] || return 1
    [[ "$output" == *"table-owner com.brave.Browser.nightly=0"* ]] || return 1
    [[ "$output" == *"table-later com.brave.Browser.nightly=0"* ]] || return 1
    [[ "$output" == *"table-nested org.pqrs.Karabiner-Elements.Settings=0"* ]] || return 1
    [[ "$output" == *"table-helper com.autodesk.AcCoreConsole=0"* ]] || return 1
    [[ "$output" == *"table-outside com.brave.Browser.origin.nightly=0"* ]] || return 1
    [[ "$output" == *"table-launcher com.brave.Browser.origin.nightly=0"* ]] || return 1
    [[ "$output" == *"table-broken com.brave.Browser.nightly=0"* ]]
}

@test "cache owner probe attributes a rewritten argv by the executable ps reports" {
    # Helpers can rewrite argv so no bundle path is left in the args column.
    # `ps -o comm=` as the last column still names the full executable, which
    # is what the owner probe attributes by; a pid missing from that read keeps
    # the argv heuristic, which stays busy for a line it cannot place.
    local case_home="$HOME/rewritten-argv"
    local apps="$case_home/Applications"
    local name id
    rm -rf "$case_home"
    while IFS='|' read -r name id; do
        mkdir -p "$apps/$name/Contents/MacOS"
        /usr/libexec/PlistBuddy -c "Add :CFBundleIdentifier string $id" \
            "$apps/$name/Contents/Info.plist" > /dev/null
    done <<'APPS'
Brave Browser Nightly.app|com.brave.Browser.nightly
Brave Origin Nightly.app|com.brave.Browser.origin.nightly
Autodesk Fusion.app|com.autodesk.fusion360
APPS
    local origin_helper="$apps/Brave Origin Nightly.app/Contents/MacOS/Brave Origin Nightly Helper"
    local nightly="$apps/Brave Browser Nightly.app/Contents/MacOS/Brave Browser Nightly"
    local console="$apps/Autodesk Fusion.app/Contents/MacOS/AcCoreConsole"
    printf '  PID  PPID COMM ARGS\n  801     1 %s Brave Origin Nightly Helper --type=renderer\n' \
        "${origin_helper:0:16}" > "$case_home/rewritten-table"
    printf '  801 %s\n' "$origin_helper" > "$case_home/rewritten-exe"
    : > "$case_home/rewritten-exe-missing"
    printf '  PID  PPID COMM ARGS\n  802     1 %s Brave Browser Nightly --restore\n' \
        "${nightly:0:16}" > "$case_home/owner-table"
    printf '  802 %s\n' "$nightly" > "$case_home/owner-exe"
    printf '  PID  PPID COMM ARGS\n  803     1 %s AcCoreConsole --vendor autodesk\n' \
        "${console:0:16}" > "$case_home/helper-table"
    printf '  803 %s\n' "$console" > "$case_home/helper-exe"

    run env HOME="$case_home" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/file_ops.sh"
ps() {
    case "$*" in
        *comm=*) cat "$HOME/$EXE" ;;
        *) cat "$HOME/$TABLE" ;;
    esac
}
probe() {
    local state=0
    _mole_reset_process_snapshot
    TABLE="$1"
    EXE="$2"
    _mole_user_cache_owner_process_state "$3" || state=$?
    printf '%s/%s %s=%s\n' "$1" "$2" "$3" "$state"
}
probe rewritten-table rewritten-exe com.brave.Browser.nightly
probe rewritten-table rewritten-exe-missing com.brave.Browser.nightly
probe owner-table owner-exe com.brave.Browser.nightly
probe helper-table helper-exe com.autodesk.AcCoreConsole
EOF

    [ "$status" -eq 0 ] || { echo "$output"; return 1; }
    [[ "$output" == *"rewritten-table/rewritten-exe com.brave.Browser.nightly=1"* ]] || { echo "$output"; return 1; }
    [[ "$output" == *"rewritten-table/rewritten-exe-missing com.brave.Browser.nightly=0"* ]] || { echo "$output"; return 1; }
    [[ "$output" == *"owner-table/owner-exe com.brave.Browser.nightly=0"* ]] || { echo "$output"; return 1; }
    [[ "$output" == *"helper-table/helper-exe com.autodesk.AcCoreConsole=0"* ]]
}

@test "cache owner probes reuse one process table snapshot" {
	run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/file_ops.sh"
ps_calls=$(mktemp)
ps() {
	printf '%s\n' "$*" >> "$ps_calls"
	cat <<'TABLE'
  PID  PPID COMM             ARGS
  601     1 /Applications/Example.app/Contents/MacOS/Example /Applications/Example.app/Contents/MacOS/Example com.example.First
TABLE
}
first_state=0
_mole_user_cache_owner_process_state "com.example.First" || first_state=$?
second_state=0
_mole_user_cache_owner_process_state "com.example.Second" || second_state=$?
# One snapshot is one table read plus one executable-path read.
table_calls=$(grep -c 'pid,ppid,comm,args' "$ps_calls" || true)
exe_calls=$(grep -c 'pid=,comm=' "$ps_calls" || true)
call_count="${table_calls}+${exe_calls}"
command rm -f "$ps_calls"
printf 'FIRST=%s SECOND=%s CALLS=%s STATE=%s\n' \
	"$first_state" "$second_state" "$call_count" "$_MOLE_PROCESS_TABLE_STATE"
EOF

	[ "$status" -eq 0 ] || return 1
	[[ "$output" == "FIRST=0 SECOND=1 CALLS=1+1 STATE=ok" ]] || return 1
}

@test "safe_remove refreshes process evidence at the final deletion boundary" {
	mole_test_fake_command lsof 'exit 1'
	local cache_dir="$HOME/Library/Caches/com.example.LateHelper"
	local target_file="$cache_dir/Cache.db"
	mkdir -p "$cache_dir"
	touch "$target_file"

	run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" TARGET_FILE="$target_file" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
_MOLE_COMPLETE_LSOF_MODE=direct
owner_calls=$(mktemp)
rm_calls=$(mktemp)
owner_live="$TARGET_FILE.owner-live"
_mole_user_cache_owner_process_state() {
	printf 'call\n' >> "$owner_calls"
	[[ -f "$owner_live" ]]
}
get_path_size_kb() {
	touch "$owner_live"
	printf '1\n'
}
oplog_enabled() { return 0; }
rm() { printf 'call\n' >> "$rm_calls"; return 99; }

remove_rc=0
safe_remove "$TARGET_FILE" true || remove_rc=$?
call_count=$(wc -l < "$owner_calls" | tr -d ' ')
rm_call_count=$(wc -l < "$rm_calls" | tr -d ' ')
command rm -f "$owner_calls" "$owner_live" "$rm_calls"
printf 'RC=%s CALLS=%s EXISTS=%s RM_CALLS=%s\n' \
	"$remove_rc" "$call_count" "$(test -f "$TARGET_FILE" && echo yes || echo no)" \
	"$rm_call_count"
EOF

	[ "$status" -eq 0 ] || return 1
	[[ "$output" == *"RC=1 CALLS=2 EXISTS=yes RM_CALLS=0"* ]] || {
		echo "$output"
		return 1
	}
}

# Mole's own size probe runs `du` over the very directory it is judging, so the
# cache id appears in the table because Mole is looking at it. Counting that as
# ownership would hide every cache that takes long enough to measure.
@test "cache owner probe ignores Mole's own measurement processes" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/file_ops.sh"
ps() {
    cat <<TABLE
  PID  PPID COMM             ARGS
  701     1 /usr/bin/du du -skPx $HOME/Library/Caches/com.example.SampleApp
  702     1 /bin/sh sh -c mole clean
TABLE
}
state=0
_mole_user_cache_owner_process_state "com.example.SampleApp" || state=$?
printf 'SELF=%s\n' "$state"
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"SELF=1"* ]]
}

# An unreadable process table is not proof the owner is idle.
@test "cache owner probe fails closed when the process table is unreadable" {
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/file_ops.sh"
ps() { return 1; }
state=0
_mole_user_cache_owner_process_state "com.example.SampleApp" || state=$?
printf 'UNREADABLE=%s\n' "$state"
EOF

    [ "$status" -eq 0 ] || {
        echo "$output"
        return 1
    }
    [[ "$output" == *"UNREADABLE=2"* ]]
}

@test "SQLite handle timeout keeps the file without cancelling later cleanup (#1595)" {
    local database="$TEST_DIR/timeout.sqlite"
    printf 'database' > "$database"
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" database="$database" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
MOLE_CURRENT_COMMAND=clean
MOLE_CLEAN_CANCEL_STATUS=0
_MOLE_COMPLETE_LSOF_MODE=direct
_mole_run_complete_lsof() { return 124; }
rc=0
safe_remove "$database" true || rc=$?
printf 'RC=%s CANCEL=%s EXISTS=%s\n' "$rc" "$MOLE_CLEAN_CANCEL_STATUS" "$(test -f "$database" && echo yes || echo no)"
next="${database%.sqlite}.log"
printf 'stale' > "$next"
safe_remove "$next" true 0 || exit 1
[[ ! -e "$next" ]] || exit 1
printf 'LATER_REMOVED\n'
EOF
    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 CANCEL=0 EXISTS=yes"* ]] || return 1
    [[ "$output" == *"LATER_REMOVED"* ]]
}

@test "SQLite handle interruption still cancels cleanup (#1595)" {
    local database="$TEST_DIR/interrupted.sqlite"
    printf 'database' > "$database"
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" database="$database" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
MOLE_CURRENT_COMMAND=clean
MOLE_CLEAN_CANCEL_STATUS=0
_MOLE_COMPLETE_LSOF_MODE=direct
_mole_run_complete_lsof() { return 130; }
rc=0
safe_remove "$database" true || rc=$?
printf 'RC=%s CANCEL=%s EXISTS=%s\n' "$rc" "$MOLE_CLEAN_CANCEL_STATUS" "$(test -f "$database" && echo yes || echo no)"
EOF
    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=130 CANCEL=130 EXISTS=yes"* ]]
}

@test "SQLite timeout after sizing keeps the file without cancellation (#1595)" {
    local database="$TEST_DIR/final-timeout.sqlite"
    printf 'database' > "$database"
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" database="$database" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
MOLE_CURRENT_COMMAND=clean
MOLE_CLEAN_CANCEL_STATUS=0
_MOLE_COMPLETE_LSOF_MODE=direct
_mole_run_complete_lsof() {
    [[ -e "${database}.sized" ]] && return 124
    return 1
}
oplog_enabled() { return 0; }
get_path_size_kb() { touch "${database}.sized"; printf '1\n'; }
rc=0
safe_remove "$database" true || rc=$?
printf 'RC=%s CANCEL=%s EXISTS=%s SIZED=%s\n' "$rc" "$MOLE_CLEAN_CANCEL_STATUS" \
    "$(test -f "$database" && echo yes || echo no)" "$(test -f "${database}.sized" && echo yes || echo no)"
EOF
    [ "$status" -eq 0 ] || return 1
    [[ "$output" == *"RC=1 CANCEL=0 EXISTS=yes SIZED=yes"* ]]
}


@test "container probe timeout keeps its target and permits later cleanup (#1653)" {
    local stage
    for stage in visibility query final; do
        check_handle_probe_outcome container 124 "$stage" || return 1
    done
}

@test "group container probe timeout keeps its target and permits later cleanup (#1653)" {
    local stage
    for stage in visibility query final; do
        check_handle_probe_outcome group 124 "$stage" || return 1
    done
}

@test "download probe timeout keeps its target and permits later cleanup (#1653)" {
    local stage
    for stage in visibility query final; do
        check_handle_probe_outcome download 124 "$stage" || return 1
    done
}

@test "handle probe timeouts keep targets out of dry-run previews (#1653)" {
    local kind stage
    for kind in container group download; do
        for stage in visibility query final; do
            check_handle_probe_outcome "$kind" 124 "$stage" 1 || return 1
        done
    done
}

@test "handle probe signals remain sticky and prevent a later eligible sink (#1653)" {
    local kind stage scripted_rc
    for kind in container group download; do
        for stage in visibility query final; do
            for scripted_rc in 130 143; do
                check_handle_probe_outcome "$kind" "$scripted_rc" "$stage" || return 1
            done
        done
    done
}

@test "read-only handle timeouts retain paths without cancelling cleanup (#1653)" {
    local cache_dir="$HOME/Library/Group Containers/TEAM.com.example.shared/Library/Caches/Timeout"
    mkdir -p "$cache_dir"
    touch "$cache_dir/payload"
    run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" cache_dir="$cache_dir" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
source "$PROJECT_ROOT/lib/core/common.sh"
lsof() { return 1; }
run_with_timeout() { return "$PROBE_STATUS"; }
for probe in _mole_paths_have_open_handle _mole_container_cache_has_open_handle; do
    for visibility in direct unknown; do
        for PROBE_STATUS in 124 130 143; do
            if [[ "$visibility" == direct ]]; then
                _MOLE_COMPLETE_LSOF_MODE=direct
            else
                unset _MOLE_COMPLETE_LSOF_MODE
            fi
            rc=0
            "$probe" "$cache_dir" || rc=$?
            printf '%s:%s:%s=%s\n' "$probe" "$visibility" "$PROBE_STATUS" "$rc"
            [[ "$PROBE_STATUS" != 124 || "$rc" == 2 ]] || exit 1
            [[ "$PROBE_STATUS" == 124 || "$rc" == "$PROBE_STATUS" ]] || exit 1
        done
    done
done
EOF
    [ "$status" -eq 0 ] || return 1
    [[ -e "$cache_dir/payload" ]] || return 1
}
