#!/usr/bin/env bats

load helpers/common

setup_file() {
	mole_test_setup_project_root

	ORIGINAL_HOME="${HOME:-}"
	export ORIGINAL_HOME

	# Capture real GOCACHE before HOME is replaced with a temp dir.
	# Without this, go build would use $HOME/Library/Caches/go-build inside the
	# temp dir (empty), causing a full cold rebuild on every test run (~6s).
	ORIGINAL_GOCACHE="$(go env GOCACHE 2>/dev/null || true)"
	ORIGINAL_GOPATH="$(go env GOPATH 2>/dev/null || true)"
	ORIGINAL_GOMODCACHE="$(go env GOMODCACHE 2>/dev/null || true)"
	export ORIGINAL_GOCACHE ORIGINAL_GOPATH ORIGINAL_GOMODCACHE

	HOME="$(mktemp -d "${BATS_TEST_DIRNAME}/tmp-cli-home.XXXXXX")"
	export HOME

	mkdir -p "$HOME"

	CLI_OWNS_GO_HELPERS=0
	export CLI_OWNS_GO_HELPERS

	if [[ -x "${MOLE_TEST_ANALYZE_BIN:-}" && -x "${MOLE_TEST_STATUS_BIN:-}" ]]; then
		ANALYZE_BIN="$MOLE_TEST_ANALYZE_BIN"
		STATUS_BIN="$MOLE_TEST_STATUS_BIN"
		export ANALYZE_BIN STATUS_BIN
	elif command -v go > /dev/null 2>&1; then
		# Build Go binaries from current source for JSON tests.
		# Reuse the Go caches resolved before HOME moved (the shared harness may
		# already have moved it off the account home) so local focused runs
		# reuse caches when the full runner did not prebuild helpers.
		ANALYZE_BIN="$(mktemp "${TMPDIR:-/tmp}/analyze-go.XXXXXX")"
		STATUS_BIN="$(mktemp "${TMPDIR:-/tmp}/status-go.XXXXXX")"
		GOPATH="${ORIGINAL_GOPATH}" GOMODCACHE="${ORIGINAL_GOMODCACHE}" \
			GOCACHE="${ORIGINAL_GOCACHE}" \
			go build -o "$ANALYZE_BIN" "$PROJECT_ROOT/cmd/analyze" 2>/dev/null
		GOPATH="${ORIGINAL_GOPATH}" GOMODCACHE="${ORIGINAL_GOMODCACHE}" \
			GOCACHE="${ORIGINAL_GOCACHE}" \
			go build -o "$STATUS_BIN" "$PROJECT_ROOT/cmd/status" 2>/dev/null
		CLI_OWNS_GO_HELPERS=1
		export ANALYZE_BIN STATUS_BIN
	fi
}

teardown_file() {
	if [[ "$HOME" == "${BATS_TEST_DIRNAME}/tmp-"* ]]; then
		rm -rf "$HOME/.config/mole"
		rm -rf "$HOME"
	fi
	if [[ -n "${ORIGINAL_HOME:-}" ]]; then
		export HOME="$ORIGINAL_HOME"
	fi
	if [[ "${CLI_OWNS_GO_HELPERS:-0}" == "1" ]]; then
		rm -f "${ANALYZE_BIN:-}" "${STATUS_BIN:-}"
	fi
}

create_fake_utils() {
	local dir="$1"
	mkdir -p "$dir"

	cat >"$dir/sudo" <<'SCRIPT'
#!/usr/bin/env bash
if [[ "$1" == "-n" || "$1" == "-v" ]]; then
    exit 0
fi
exec "$@"
SCRIPT
	chmod +x "$dir/sudo"

	cat >"$dir/bioutil" <<'SCRIPT'
#!/usr/bin/env bash
if [[ "$1" == "-r" ]]; then
    echo "Touch ID: 1"
    exit 0
fi
exit 0
SCRIPT
	chmod +x "$dir/bioutil"

	cat >"$dir/chown" <<'SCRIPT'
#!/usr/bin/env bash
exit 0
SCRIPT
	chmod +x "$dir/chown"

	cat >"$dir/install" <<'SCRIPT'
#!/usr/bin/env bash
args=()
skip_next=""
for arg in "$@"; do
    if [[ -n "$skip_next" ]]; then skip_next=""; continue; fi
    case "$arg" in -o|-g) skip_next=1 ;; *) args+=("$arg") ;; esac
done
exec /usr/bin/install "${args[@]}"
SCRIPT
	chmod +x "$dir/install"
}

setup() {
	# Safety: refuse to operate on a real home directory.
	if [[ "$HOME" != "${BATS_TEST_DIRNAME}/tmp-"* ]]; then
		printf 'FATAL: HOME is not a test temp dir: %s\n' "$HOME" >&2
		return 1
	fi
	rm -rf "$HOME/.config/mole"
	mkdir -p "$HOME/.config/mole"
}

@test "mole --help prints command overview" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" --help
	[ "$status" -eq 0 ]
	[[ "$output" == *"mo clean"* ]] || return 1
	[[ "$output" == *"mo optimize"* ]] || return 1
	[[ "$output" == *"mo analyze"* ]] || return 1
	[[ "$output" != *"mo optimise"* ]]
}

@test "mole refuses a deleted cwd before loading user state (#1679)" {
	local vanished
	vanished=$(mktemp -d "$HOME/cwd-gone.XXXXXX")
	run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" VANISHED="$vanished" /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
cd "$VANISHED"
rmdir "$VANISHED"
exec "$PROJECT_ROOT/mole" clean --dry-run --debug
EOF
	[ "$status" -eq 1 ] || { echo "$output"; return 1; }
	[[ "$output" == *"Cannot access the current directory"* ]] || return 1
	[[ "$output" == *'cd ~'* ]] || return 1
	[[ "$output" != *"Starting developer cleanup step"* ]] || return 1
	[[ "$output" != *"Debug logging enabled"* ]]
}

@test "mole still answers version and help probes from a deleted cwd (#1679)" {
	local vanished
	vanished=$(mktemp -d "$HOME/cwd-probe.XXXXXX")
	run env HOME="$HOME" PROJECT_ROOT="$PROJECT_ROOT" VANISHED="$vanished" /bin/bash --noprofile --norc <<'EOF'
set -uo pipefail
cd "$VANISHED"
rmdir "$VANISHED"
# install.sh and mo update verify a fresh install with these two probes.
"$PROJECT_ROOT/mole" --version > "$HOME/probe-version.out" 2>&1; echo "VERSION_RC=$?"
"$PROJECT_ROOT/mole" --help > "$HOME/probe-help.out" 2>&1; echo "HELP_RC=$?"
"$PROJECT_ROOT/mole" clean --dry-run > /dev/null 2>&1; echo "CLEAN_RC=$?"
EOF
	[[ "$output" == *"VERSION_RC=0"* ]] || { echo "$output"; cat "$HOME/probe-version.out"; return 1; }
	[[ "$output" == *"HELP_RC=0"* ]] || { echo "$output"; cat "$HOME/probe-help.out"; return 1; }
	# Every other command keeps refusing an unknown working directory.
	[[ "$output" == *"CLEAN_RC=1"* ]] || { echo "$output"; return 1; }
	grep -q 'Mole version' "$HOME/probe-version.out" || return 1
	! grep -q 'Cannot access the current directory' "$HOME/probe-version.out" || return 1
}

@test "mole --version reports script version" {
	expected_version="$(grep '^VERSION=' "$PROJECT_ROOT/mole" | head -1 | sed 's/VERSION=\"\(.*\)\"/\1/')"
	run env HOME="$HOME" "$PROJECT_ROOT/mole" --version
	[ "$status" -eq 0 ]
	[[ "$output" == *"$expected_version"* ]]
}

@test "mole --version does not hang on slow Homebrew detection" {
	local fake_bin
	fake_bin="$(mktemp -d "${BATS_TEST_TMPDIR}/fake-bin.XXXXXX")"
	ln -s "$PROJECT_ROOT/mole" "$fake_bin/mole"
	cat > "$fake_bin/brew" <<'SCRIPT'
#!/usr/bin/env bash
sleep 3
exit 1
SCRIPT
	chmod +x "$fake_bin/brew"

	run env HOME="$HOME" PATH="$fake_bin:$PATH" MOLE_HOMEBREW_DETECT_TIMEOUT=1 "$PROJECT_ROOT/mole" --version
	[ "$status" -eq 0 ]
	[[ "$output" == *"Install: Manual"* ]]
}

@test "mole --version names the commit of a Homebrew HEAD build" {
	local prefix keg
	prefix="$(mktemp -d "${BATS_TEST_TMPDIR}/mole-brew-head.XXXXXX")"
	for keg in HEAD-1a2b3c4 9.9.9; do
		mkdir -p "$prefix/Cellar/mole/$keg/libexec"
		cp "$PROJECT_ROOT/mole" "$prefix/Cellar/mole/$keg/libexec/mole"
		ln -s "$PROJECT_ROOT/lib" "$prefix/Cellar/mole/$keg/libexec/lib"
		ln -s "$PROJECT_ROOT/bin" "$prefix/Cellar/mole/$keg/libexec/bin"
	done
	mkdir -p "$prefix/bin"

	ln -s "$prefix/Cellar/mole/HEAD-1a2b3c4/libexec/mole" "$prefix/bin/mole"
	run env HOME="$HOME" MOLE_HOMEBREW_DETECT_TIMEOUT=1 "$prefix/bin/mole" --version
	[ "$status" -eq 0 ] || { echo "$output"; return 1; }
	[[ "$output" == *"Install: Homebrew (HEAD 1a2b3c4)"* ]] || { echo "$output"; return 1; }

	ln -sf "$prefix/Cellar/mole/9.9.9/libexec/mole" "$prefix/bin/mole"
	run env HOME="$HOME" MOLE_HOMEBREW_DETECT_TIMEOUT=1 "$prefix/bin/mole" --version
	[ "$status" -eq 0 ] || { echo "$output"; return 1; }
	[[ "$output" == *"Install: Homebrew"$'\n'* ]] || { echo "$output"; return 1; }
}

@test "mole invoked through a cross-directory symlink still sources lib" {
	local link_dir
	link_dir="$(mktemp -d "${BATS_TEST_TMPDIR}/mole-abs-link.XXXXXX")"
	ln -s "$PROJECT_ROOT/mole" "$link_dir/mole"
	run env HOME="$HOME" "$link_dir/mole" --help
	[ "$status" -eq 0 ] || { echo "$output"; return 1; }
	[[ "$output" == *"mo clean"* ]] || return 1
}

@test "mole invoked through a Homebrew-style prefix symlink still sources lib" {
	local prefix cellar
	prefix="$(mktemp -d "${BATS_TEST_TMPDIR}/mole-brew-prefix.XXXXXX")"
	cellar="$prefix/Cellar/mole/9.9.9/bin"
	mkdir -p "$prefix/bin" "$cellar"
	cp "$PROJECT_ROOT/mole" "$cellar/mole"
	chmod +x "$cellar/mole"
	cp -R "$PROJECT_ROOT/lib" "$prefix/bin/lib"
	ln -s "$cellar/mole" "$prefix/bin/mole"
	run env HOME="$HOME" "$prefix/bin/mole" --help
	[ "$status" -eq 0 ] || { echo "$output"; return 1; }
	[[ "$output" == *"mo clean"* ]] || return 1
}

@test "mole --version shows nightly channel metadata" {
	expected_version="$(grep '^VERSION=' "$PROJECT_ROOT/mole" | head -1 | sed 's/VERSION=\"\(.*\)\"/\1/')"
	mkdir -p "$HOME/.config/mole"
	cat > "$HOME/.config/mole/install_channel" <<'EOF'
CHANNEL=nightly
EOF

	run env HOME="$HOME" "$PROJECT_ROOT/mole" --version
	[ "$status" -eq 0 ]
	[[ "$output" == *"Mole version $expected_version"* ]] || return 1
	[[ "$output" == *"Channel: Nightly"* ]]
}

@test "mole unknown command returns error" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" unknown-command
	[ "$status" -ne 0 ]
	[[ "$output" == *"Unknown command: unknown-command"* ]]
}

@test "mole unknown command writes the diagnostic to stderr" {
	local out="$BATS_TEST_TMPDIR/unknown.out"
	local err="$BATS_TEST_TMPDIR/unknown.err"
	run env HOME="$HOME" bash -c "'$PROJECT_ROOT/mole' unknown-command > '$out' 2> '$err'"
	[ "$status" -ne 0 ]
	[ ! -s "$out" ] || { cat "$out"; return 1; }
	grep -q "Unknown command: unknown-command" "$err" || { cat "$err"; return 1; }
}

# Every subcommand that rejects an option must do it the way bin/history.sh
# already did: nothing on stdout, so `mo <cmd> --bogus > out` leaves the reason
# on the terminal instead of burying it in the redirected file. analyze and
# status are left to cmd/*/usage_test.go: their wrapper reports a missing
# bundled binary instead, on jobs that do not build the Go helpers.
@test "every subcommand sends its unknown-option diagnostic to stderr" {
	local cmd out err
	for cmd in "update --bogus" "remove --bogus" "optimize --bogus" \
		"purge --bogus" "installer --bogus" "uninstall --bogus" \
		"uninstall --whitelist" "history --bogus"; do
		out="$BATS_TEST_TMPDIR/opt.out"
		err="$BATS_TEST_TMPDIR/opt.err"
		run env HOME="$HOME" bash -c "'$PROJECT_ROOT/mole' $cmd > '$out' 2> '$err'"
		[ "$status" -ne 0 ] || { echo "mo $cmd exited 0"; return 1; }
		[ ! -s "$out" ] || { echo "mo $cmd wrote to stdout:"; cat "$out"; return 1; }
		grep -qiE "unknown|not defined" "$err" || { echo "mo $cmd stderr:"; cat "$err"; return 1; }
	done
}

@test "mole --help does not list check command" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" --help
	[ "$status" -eq 0 ]
	[[ "$output" != *"mo check"* ]]
}

@test "mole --help documents history command" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" --help
	[ "$status" -eq 0 ]
	[[ "$output" == *"mo history"* ]]
}

@test "mole check is not a public command" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" check --help
	[ "$status" -ne 0 ]
	[[ "$output" == *"Unknown command: check"* ]]
}

@test "mole doctor is not a public command" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" doctor --help
	[ "$status" -ne 0 ]
	[[ "$output" == *"Unknown command: doctor"* ]]
}

@test "mole optimize --check is not a public option" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" optimize --check
	[ "$status" -ne 0 ]
	[[ "$output" == *"Unknown optimize option: --check"* ]]
}

@test "mole uninstall --whitelist returns unsupported option error" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" uninstall --whitelist
	[ "$status" -ne 0 ]
	[[ "$output" == *"Unknown uninstall option: --whitelist"* ]]
}

@test "main menu controls line shows the update shortcut only when an update is available" {
	# The controls line is rendered only under a tty, so test the pure builder
	# directly. Both the negative and positive cases run so the assertion
	# cannot pass vacuously.
	run /bin/bash --noprofile --norc -c "MOLE_TEST_MODE=1 MOLE_SKIP_MAIN=1 HOME=\"\$(mktemp -d)\" source '$PROJECT_ROOT/mole'; _main_menu_controls_line true false"
	[ "$status" -eq 0 ] || return 1
	[[ "$output" != *"U Update"* ]] || return 1

	run /bin/bash --noprofile --norc -c "MOLE_TEST_MODE=1 MOLE_SKIP_MAIN=1 HOME=\"\$(mktemp -d)\" source '$PROJECT_ROOT/mole'; _main_menu_controls_line true true"
	[ "$status" -eq 0 ] || return 1
	[[ "$output" == *"U Update"* ]] || return 1

	# TouchID setup and an available update both retain their shortcuts.
	run /bin/bash --noprofile --norc -c "MOLE_TEST_MODE=1 MOLE_SKIP_MAIN=1 HOME=\"\$(mktemp -d)\" source '$PROJECT_ROOT/mole'; _main_menu_controls_line false true"
	[ "$status" -eq 0 ] || return 1
	[[ "$output" == *"T TouchID"* ]] || return 1
	[[ "$output" == *"U Update"* ]] || return 1
}

@test "show_main_menu keeps history out of the primary menu" {
	run /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
HOME="$(mktemp -d)"
export HOME MOLE_TEST_MODE=1 MOLE_SKIP_MAIN=1
source "$PROJECT_ROOT/mole"
show_brand_banner() { printf 'banner\n'; }
show_menu_option() { printf '%s\n' "$2"; }
MAIN_MENU_BANNER=""
MAIN_MENU_UPDATE_MESSAGE=""
MAIN_MENU_SHOW_UPDATE=false
show_main_menu 1 true
EOF

	[ "$status" -eq 0 ]
	[[ "$output" == *"Clean        Free up disk space"* ]] || return 1
	[[ "$output" != *"History"* ]] || return 1
	[[ "$output" != *"history"* ]]
}

@test "show_main_menu sets the update notice off with a blank line and a green command" {
	run /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
unset NO_COLOR
HOME="$(mktemp -d)"
export HOME MOLE_TEST_MODE=1 MOLE_SKIP_MAIN=1
source "$PROJECT_ROOT/mole"
[[ -n "$GREEN" && -n "$NC" ]] || exit 1
show_menu_option() { printf '%s' "$2"; }
line=$'\r\033[2K'
render() {
    MAIN_MENU_BANNER=""
    MAIN_MENU_UPDATE_MESSAGE="$1"
    MAIN_MENU_SHOW_UPDATE=true
    show_main_menu 1 true
}
tagline="${GREEN}${MOLE_TAGLINE}${NC}"$'\n'

# The real banner is used: command substitution strips its trailing blank line,
# so the separator has to come from the notice itself.
out="$(render 'Update 9.8.7 available, run mo update')"
[[ "$out" == *"${tagline}${line}"$'\n'"${line}Update 9.8.7 available, run ${GREEN}mo update${NC}"$'\n'"${line}"$'\n'"${line}Clean"* ]] || { printf '%q\n' "$out"; exit 1; }
out="$(render 'New nightly commit abc1234 available, run mo update --nightly')"
[[ "$out" == *"${tagline}${line}"$'\n'"${line}New nightly commit abc1234 available, run ${GREEN}mo update --nightly${NC}"$'\n'"${line}"$'\n'"${line}Clean"* ]] || { printf '%q\n' "$out"; exit 1; }

# Control: without a notice no extra rows appear between banner and options.
out="$(render '')"
[[ "$out" == *"${tagline}${line}"$'\n'"${line}Clean"* ]] || { printf '%q\n' "$out"; exit 1; }

# Rendering must not rewrite the stored text: the idle refresh compares it
# against the plain cache contents on every tick.
MAIN_MENU_BANNER=""
MAIN_MENU_UPDATE_MESSAGE='Update 9.8.7 available, run mo update'
show_main_menu 1 true > /dev/null
[[ "$MAIN_MENU_UPDATE_MESSAGE" == 'Update 9.8.7 available, run mo update' ]] || exit 1
EOF

	[ "$status" -eq 0 ] || { echo "$output"; return 1; }
}

@test "interactive_main_menu ignores U shortcut when update notice is hidden" {
	run /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
HOME="$(mktemp -d)"
export HOME MOLE_TEST_MODE=1 MOLE_SKIP_MAIN=1
source "$PROJECT_ROOT/mole"
show_brand_banner() { :; }
show_main_menu() { :; }
hide_cursor() { :; }
show_cursor() { :; }
clear() { :; }
update_mole() { echo "UPDATE_CALLED"; }
state_file="$HOME/read_key_state"
read_key() {
    if [[ ! -f "$state_file" ]]; then
        : > "$state_file"
        echo "UPDATE"
    else
        echo "QUIT"
    fi
}
interactive_main_menu
EOF

	[ "$status" -eq 0 ]
	[[ "$output" != *"UPDATE_CALLED"* ]]
}

@test "read_update_message_cache ignores notices older than current script" {
	run /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
HOME="$(mktemp -d)"
export HOME MOLE_TEST_MODE=1 MOLE_SKIP_MAIN=1
mkdir -p "$HOME/.cache/mole"
msg_cache="$HOME/.cache/mole/update_message"
printf 'Update 1.43.0 available, run mo update\n' > "$msg_cache"
touch -t 200001010000 "$msg_cache"
source "$PROJECT_ROOT/mole"
message="$(read_update_message_cache "$msg_cache")"
[[ -z "$message" ]] || exit 1
[[ -s "$msg_cache" ]] || exit 1
EOF

	[ "$status" -eq 0 ]
}

@test "interactive_main_menu accepts U shortcut when update notice is visible" {
	run /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
HOME="$(mktemp -d)"
export HOME MOLE_TEST_MODE=1 MOLE_SKIP_MAIN=1
mkdir -p "$HOME/.cache/mole"
printf 'update available\n' > "$HOME/.cache/mole/update_message"
source "$PROJECT_ROOT/mole"
show_brand_banner() { :; }
show_main_menu() { :; }
hide_cursor() { :; }
show_cursor() { :; }
clear() { :; }
update_mole() { echo "UPDATE_CALLED"; }
read_key() { echo "UPDATE"; }
interactive_main_menu
EOF

	[ "$status" -eq 0 ]
	[[ "$output" == *"UPDATE_CALLED"* ]]
}

@test "interactive_main_menu quits on EOF but keeps running through idle ticks" {
	# The body runs from a file: Bash 3.2 misreads a script fed on stdin once a
	# function returns from inside a loop here, replaying the tail of a comment.
	cat > "$BATS_TEST_TMPDIR/menu-eof.sh" <<'EOF'
set -euo pipefail
HOME="$(mktemp -d)"
export HOME PROJECT_ROOT MOLE_TEST_MODE=1 MOLE_SKIP_MAIN=1
script='source "$PROJECT_ROOT/mole"; show_main_menu() { :; }; hide_cursor() { :; }; show_cursor() { :; }; drain_pending_input() { :; }; interactive_main_menu'

# Wait up to eight seconds for the background menu; a menu that is still alive
# is killed and reported so a spinning loop cannot hang the suite.
wait_for_menu() {
    local pid="$1" _
    for _ in $(seq 1 80); do
        kill -0 "$pid" 2> /dev/null || return 0
        sleep 0.1
    done
    kill -KILL "$pid" 2> /dev/null || true
    wait "$pid" 2> /dev/null || true
    return 1
}

# read_key tells an idle one-second tick from EOF only by elapsed time, and the
# two need opposite handling: EOF must quit, a tick must keep the menu alive.
/bin/bash --noprofile --norc -c "$script" < /dev/null > /dev/null 2>&1 &
pid=$!
wait_for_menu "$pid" || { echo "menu kept running after EOF"; exit 1; }
wait "$pid" || { echo "menu exited non-zero on EOF"; exit 1; }

# Control: stdin that stays open and idle for three seconds is not EOF, so the
# menu must still be there after two idle ticks and quit once the pipe closes.
/bin/bash --noprofile --norc -c "$script" < <(sleep 3) > /dev/null 2>&1 &
pid=$!
sleep 2
kill -0 "$pid" 2> /dev/null || { echo "menu quit during an idle tick"; exit 1; }
wait_for_menu "$pid" || { echo "menu kept running after the idle pipe closed"; exit 1; }
wait "$pid" || { echo "menu exited non-zero after the idle pipe closed"; exit 1; }
EOF

	run env PROJECT_ROOT="$PROJECT_ROOT" /bin/bash --noprofile --norc "$BATS_TEST_TMPDIR/menu-eof.sh"
	[ "$status" -eq 0 ] || { echo "$output"; return 1; }
}

@test "interactive_main_menu drains numeric shortcut Enter before launching uninstall" {
	run /bin/bash --noprofile --norc <<'EOF'
set -euo pipefail
HOME="$(mktemp -d)"
export HOME MOLE_TEST_MODE=1 MOLE_SKIP_MAIN=1
source "$PROJECT_ROOT/mole"

fake_root="$HOME/fake-mole"
mkdir -p "$fake_root/bin"
cat > "$fake_root/bin/uninstall.sh" <<'SCRIPT'
#!/usr/bin/env bash
# Use an integer timeout: macOS Bash 3.2 rejects fractional values, which
# would report NO_LEAK without checking whether Enter remained on stdin.
if IFS= read -r -s -n1 -t 1 key; then
    if [[ -z "$key" ]]; then
        echo "LEAK:ENTER"
    else
        printf 'LEAK:%s\n' "$key"
    fi
else
    echo "NO_LEAK"
fi
SCRIPT
chmod +x "$fake_root/bin/uninstall.sh"

SCRIPT_DIR="$fake_root"
show_brand_banner() { :; }
show_main_menu() { :; }
hide_cursor() { :; }
show_cursor() { :; }

interactive_main_menu < <(printf '2\n')
EOF

	[ "$status" -eq 0 ]
	[[ "$output" == *"NO_LEAK"* ]] || return 1
	[[ "$output" != *"LEAK:"* ]]
}

@test "touchid status reports current configuration" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" touchid status
	[ "$status" -eq 0 ]
	[[ "$output" == *"Touch ID"* ]]
}

@test "mo optimize command is recognized" {
	run /bin/bash -c "grep -Eq '\"optimi[sz]e\"[[:space:]]*\\|[[:space:]]*\"optimi[sz]e\"' '$PROJECT_ROOT/mole'"
	[ "$status" -eq 0 ]
}

@test "mo analyze binary is valid" {
	if [[ -f "$PROJECT_ROOT/bin/analyze-go" ]]; then
		[ -x "$PROJECT_ROOT/bin/analyze-go" ]
		run file "$PROJECT_ROOT/bin/analyze-go"
		[[ "$output" == *"Mach-O"* ]] || [[ "$output" == *"executable"* ]] || return 1
	else
		skip "analyze-go binary not built"
	fi
}

@test "mo clean --debug creates debug log file" {
	mkdir -p "$HOME/.config/mole"
	run env HOME="$HOME" TERM="xterm-256color" MOLE_TEST_MODE=1 MO_DEBUG=1 "$PROJECT_ROOT/mole" clean --dry-run
	[ "$status" -eq 0 ]
	MOLE_OUTPUT="$output"

	DEBUG_LOG="$HOME/Library/Logs/mole/mole_debug_session.log"
	[ -f "$DEBUG_LOG" ]

	run grep "Mole Debug Session" "$DEBUG_LOG"
	[ "$status" -eq 0 ]

	[[ "$MOLE_OUTPUT" =~ "Debug session log saved to" ]]
}

@test "mo clean without debug does not show debug log path" {
	mkdir -p "$HOME/.config/mole"
	run env HOME="$HOME" TERM="xterm-256color" MOLE_TEST_MODE=1 MO_DEBUG=0 "$PROJECT_ROOT/mole" clean --dry-run
	[ "$status" -eq 0 ]

	[[ "$output" != *"Debug session log saved to"* ]]
}

@test "mo clean --debug logs system info" {
	mkdir -p "$HOME/.config/mole"
	run env HOME="$HOME" TERM="xterm-256color" MOLE_TEST_MODE=1 MO_DEBUG=1 "$PROJECT_ROOT/mole" clean --dry-run
	[ "$status" -eq 0 ]

	DEBUG_LOG="$HOME/Library/Logs/mole/mole_debug_session.log"

	run grep "User:" "$DEBUG_LOG"
	[ "$status" -eq 0 ]

	run grep "Architecture:" "$DEBUG_LOG"
	[ "$status" -eq 0 ]
}

@test "mo clean --help includes external volume option" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" clean --help
	[ "$status" -eq 0 ]
	[[ "$output" == *"--external PATH"* ]] || return 1
	[[ "$output" == *"already-uninstalled apps"* ]]
}

@test "mo uninstall --help directs leftover-only cleanup to clean" {
	run env HOME="$HOME" "$PROJECT_ROOT/mole" uninstall --help
	[ "$status" -eq 0 ]
	[[ "$output" == *"already gone, use mo clean"* ]]
}

@test "mo clean --external accepts canonicalized custom root" {
	real_root="$(mktemp -d "$HOME/ext-real.XXXXXX")"
	link_root="$HOME/ext-link"
	ln -s "$real_root" "$link_root"
	mkdir -p "$link_root/USB/.Trashes"
	touch "$link_root/USB/.Trashes/cache.tmp"

	mock_bin="$HOME/mock-bin"
	mkdir -p "$mock_bin"
	cat > "$mock_bin/diskutil" <<'EOF'
#!/usr/bin/env bash
exit 0
EOF
	chmod +x "$mock_bin/diskutil"

	run env HOME="$HOME" PATH="$mock_bin:$PATH" MOLE_EXTERNAL_VOLUMES_ROOT="$link_root" \
		MOLE_TEST_NO_AUTH=1 "$PROJECT_ROOT/mole" clean --external "$link_root/USB" --dry-run
	[ "$status" -eq 0 ]
	[[ "$output" == *"Clean External Volume"* ]] || return 1
	[[ "$output" == *"External volume cleanup"* ]]
}

@test "touchid status reflects pam file contents" {
	pam_file="$HOME/pam_test"
	cat >"$pam_file" <<'EOF'
auth       sufficient     pam_opendirectory.so
EOF

	run env MOLE_PAM_SUDO_FILE="$pam_file" "$PROJECT_ROOT/bin/touchid.sh" status
	[ "$status" -eq 0 ]
	[[ "$output" == *"not configured"* ]] || return 1

	cat >"$pam_file" <<'EOF'
auth       sufficient     pam_tid.so
EOF

	run env MOLE_PAM_SUDO_FILE="$pam_file" "$PROJECT_ROOT/bin/touchid.sh" status
	[ "$status" -eq 0 ]
	[[ "$output" == *"enabled"* ]]
}

@test "enable_touchid inserts pam_tid line in pam file" {
	pam_file="$HOME/pam_enable"
	cat >"$pam_file" <<'EOF'
auth       sufficient     pam_opendirectory.so
EOF

	fake_bin="$HOME/fake-bin"
	create_fake_utils "$fake_bin"

	run env PATH="$fake_bin:$PATH" MOLE_PAM_SUDO_FILE="$pam_file" "$PROJECT_ROOT/bin/touchid.sh" enable
	[ "$status" -eq 0 ]
	grep -q "pam_tid.so" "$pam_file"
	[[ -f "${pam_file}.mole-backup" ]]
}

@test "disable_touchid removes pam_tid line" {
	pam_file="$HOME/pam_disable"
	cat >"$pam_file" <<'EOF'
auth       sufficient     pam_tid.so
auth       sufficient     pam_opendirectory.so
EOF

	fake_bin="$HOME/fake-bin-disable"
	create_fake_utils "$fake_bin"

	run env PATH="$fake_bin:$PATH" MOLE_PAM_SUDO_FILE="$pam_file" "$PROJECT_ROOT/bin/touchid.sh" disable
	[ "$status" -eq 0 ]
	run grep "pam_tid.so" "$pam_file"
	[ "$status" -ne 0 ]
}

@test "touchid enable and disable each leave an operations.log row" {
	pam_file="$HOME/pam_logged"
	cat >"$pam_file" <<'EOF'
auth       sufficient     pam_opendirectory.so
EOF
	rm -f "$HOME/Library/Logs/mole/operations.log"

	fake_bin="$HOME/fake-bin-logged"
	create_fake_utils "$fake_bin"

	run env HOME="$HOME" PATH="$fake_bin:$PATH" MOLE_PAM_SUDO_FILE="$pam_file" "$PROJECT_ROOT/bin/touchid.sh" enable
	[ "$status" -eq 0 ]
	run env HOME="$HOME" PATH="$fake_bin:$PATH" MOLE_PAM_SUDO_FILE="$pam_file" "$PROJECT_ROOT/bin/touchid.sh" disable
	[ "$status" -eq 0 ]

	run cat "$HOME/Library/Logs/mole/operations.log"
	[[ "$output" == *"[touchid] REBUILT $pam_file (touchid enabled)"* ]] || return 1
	[[ "$output" == *"[touchid] REBUILT $pam_file (touchid disabled)"* ]] || return 1
}

@test "touchid enable --dry-run does not modify pam file" {
	pam_file="$HOME/pam_enable_dry_run"
	cat >"$pam_file" <<'EOF'
auth       sufficient     pam_opendirectory.so
EOF

	run env MOLE_PAM_SUDO_FILE="$pam_file" "$PROJECT_ROOT/bin/touchid.sh" enable --dry-run
	[ "$status" -eq 0 ]
	[[ "$output" == *"DRY RUN MODE"* ]] || return 1

	run grep "pam_tid.so" "$pam_file"
	[ "$status" -ne 0 ]
}

@test "enable_touchid sets correct file permissions on pam file" {
	pam_file="$HOME/pam_perms_enable"
	cat >"$pam_file" <<'EOF'
auth       sufficient     pam_opendirectory.so
EOF

	fake_bin="$HOME/fake-bin-perms-enable"
	create_fake_utils "$fake_bin"

	run env PATH="$fake_bin:$PATH" MOLE_PAM_SUDO_FILE="$pam_file" "$PROJECT_ROOT/bin/touchid.sh" enable
	[ "$status" -eq 0 ]
	grep -q "pam_tid.so" "$pam_file"

	local perms
	perms=$(stat -f "%Lp" "$pam_file" 2>/dev/null || stat -c "%a" "$pam_file" 2>/dev/null)
	[ "$perms" = "444" ]
}

@test "disable_touchid sets correct file permissions on pam file" {
	pam_file="$HOME/pam_perms_disable"
	cat >"$pam_file" <<'EOF'
auth       sufficient     pam_tid.so
auth       sufficient     pam_opendirectory.so
EOF

	fake_bin="$HOME/fake-bin-perms-disable"
	create_fake_utils "$fake_bin"

	run env PATH="$fake_bin:$PATH" MOLE_PAM_SUDO_FILE="$pam_file" "$PROJECT_ROOT/bin/touchid.sh" disable
	[ "$status" -eq 0 ]

	local perms
	perms=$(stat -f "%Lp" "$pam_file" 2>/dev/null || stat -c "%a" "$pam_file" 2>/dev/null)
	[ "$perms" = "444" ]
}

@test "enable_touchid sets correct permissions on sudo_local file" {
	pam_file="$HOME/pam_perms_sudolocal"
	pam_local="$(dirname "$pam_file")/sudo_local_perms"
	cat >"$pam_file" <<'EOF'
# sudo: auth account password session
auth       include        sudo_local
auth       sufficient     pam_opendirectory.so
EOF

	fake_bin="$HOME/fake-bin-perms-sudolocal"
	create_fake_utils "$fake_bin"

	run env PATH="$fake_bin:$PATH" \
		MOLE_PAM_SUDO_FILE="$pam_file" \
		MOLE_PAM_SUDO_LOCAL_FILE="$pam_local" \
		"$PROJECT_ROOT/bin/touchid.sh" enable
	[ "$status" -eq 0 ]
	grep -q "pam_tid.so" "$pam_local"

	local perms
	perms=$(stat -f "%Lp" "$pam_local" 2>/dev/null || stat -c "%a" "$pam_local" 2>/dev/null)
	[ "$perms" = "444" ]
}

# --- JSON output mode tests ---

@test "mo analyze --json outputs valid JSON with expected fields" {
	if [[ ! -x "${ANALYZE_BIN:-}" ]]; then
		skip "analyze binary not available (go not installed?)"
	fi

	run "$ANALYZE_BIN" --json /tmp
	[ "$status" -eq 0 ]

	# Validate it is parseable JSON
	echo "$output" | python3 -c "import sys, json; json.load(sys.stdin)"

	# Check required top-level keys
	echo "$output" | python3 -c "
import sys, json
data = json.load(sys.stdin)
assert 'path' in data, 'missing path'
assert 'overview' in data, 'missing overview'
assert 'entries' in data, 'missing entries'
assert 'total_size' in data, 'missing total_size'
assert 'total_files' in data, 'missing total_files'
assert isinstance(data['entries'], list), 'entries is not a list'
"
}

@test "mo analyze --json entries contain required fields" {
	if [[ ! -x "${ANALYZE_BIN:-}" ]]; then
		skip "analyze binary not available (go not installed?)"
	fi

	run "$ANALYZE_BIN" --json /tmp
	[ "$status" -eq 0 ]

	echo "$output" | python3 -c "
import sys, json
data = json.load(sys.stdin)
assert data['overview'] is False, 'explicit path should not be overview mode'
for entry in data['entries']:
    assert 'name' in entry, 'entry missing name'
    assert 'path' in entry, 'entry missing path'
    assert 'size' in entry, 'entry missing size'
    assert 'is_dir' in entry, 'entry missing is_dir'
"
}

@test "mo analyze --json path reflects target directory" {
	if [[ ! -x "${ANALYZE_BIN:-}" ]]; then
		skip "analyze binary not available (go not installed?)"
	fi

	run "$ANALYZE_BIN" --json /tmp
	[ "$status" -eq 0 ]

	echo "$output" | python3 -c "
import sys, json
data = json.load(sys.stdin)
assert data['path'] == '/tmp' or data['path'] == '/private/tmp', \
    f\"unexpected path: {data['path']}\"
"
}

@test "mo status --json outputs valid JSON with expected fields" {
	if [[ ! -x "${STATUS_BIN:-}" ]]; then
		skip "status binary not available (go not installed?)"
	fi

	run "$STATUS_BIN" --json
	[ "$status" -eq 0 ]

	# Validate it is parseable JSON
	echo "$output" | python3 -c "import sys, json; json.load(sys.stdin)"

	# Check required top-level keys
	echo "$output" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for key in ['cpu', 'memory', 'disks', 'health_score', 'host', 'uptime']:
    assert key in data, f'missing key: {key}'
"
}

@test "mo status --json cpu section has expected structure" {
	if [[ ! -x "${STATUS_BIN:-}" ]]; then
		skip "status binary not available (go not installed?)"
	fi

	run "$STATUS_BIN" --json
	[ "$status" -eq 0 ]

	echo "$output" | python3 -c "
import sys, json
data = json.load(sys.stdin)
cpu = data['cpu']
assert 'usage' in cpu, 'cpu missing usage'
assert 'logical_cpu' in cpu, 'cpu missing logical_cpu'
assert isinstance(cpu['usage'], (int, float)), 'cpu usage is not a number'
"
}

@test "mo status --json memory section has expected structure" {
	if [[ ! -x "${STATUS_BIN:-}" ]]; then
		skip "status binary not available (go not installed?)"
	fi

	run "$STATUS_BIN" --json
	[ "$status" -eq 0 ]

	echo "$output" | python3 -c "
import sys, json
data = json.load(sys.stdin)
mem = data['memory']
assert 'total' in mem, 'memory missing total'
assert 'used' in mem, 'memory missing used'
assert 'used_percent' in mem, 'memory missing used_percent'
assert mem['total'] > 0, 'memory total should be positive'
"
}

@test "mo status --json piped to stdout auto-detects JSON mode" {
	if [[ ! -x "${STATUS_BIN:-}" ]]; then
		skip "status binary not available (go not installed?)"
	fi

	# When piped (not a tty), status should auto-detect and output JSON
	output=$("$STATUS_BIN" 2>/dev/null)
	echo "$output" | python3 -c "import sys, json; json.load(sys.stdin)"
}

@test "mo status --watch streams newline-delimited JSON" {
	if [[ ! -x "${STATUS_BIN:-}" ]]; then
		skip "status binary not available (go not installed?)"
	fi

	run python3 - "$STATUS_BIN" <<'PY'
import json
import subprocess
import sys

status_bin = sys.argv[1]
proc = subprocess.Popen(
    [status_bin, "--watch", "--interval", "200ms"],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
)
lines = []
try:
    for _ in range(3):
        line = proc.stdout.readline()
        if not line:
            raise RuntimeError("missing watch output")
        snapshot = json.loads(line)
        for key in ("collected_at", "cpu", "memory", "disk_io", "network", "health_score"):
            if key not in snapshot:
                raise RuntimeError(f"missing key: {key}")
        lines.append(snapshot)
finally:
    proc.terminate()
    try:
        proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=3)

if proc.stderr.read():
    raise RuntimeError("watch wrote to stderr")
print(f"watch_lines={len(lines)}")
PY
	[ "$status" -eq 0 ]
	[[ "$output" == *"watch_lines=3"* ]]
}

@test "user CLI entrypoints refuse root before loading shared user state" {
    for entry in mole bin/clean.sh bin/optimize.sh bin/purge.sh bin/uninstall.sh bin/installer.sh bin/touchid.sh bin/completion.sh; do
        # Only the EUID guard. Stopping at the first SCRIPT_DIR= assignment
        # would pull the mole symlink walker into a bash -c prefix, where
        # BASH_SOURCE is not a real file.
        prefix=$(awk '
            /^if \[\[ "\$EUID"/ { keep=1 }
            keep { print }
            /^fi$/ && keep { exit }
        ' "$PROJECT_ROOT/$entry")
        # Execute the actual source prefix, substituting only the read-only UID
        # so the test never requests root or runs a maintenance command.
        run /bin/bash -c "${prefix//\$EUID/0}"
        [ "$status" -eq 1 ] || return 1
        [[ "$output" == *"Run Mole without sudo"* ]] || return 1
        run /bin/bash -c "${prefix//\$EUID/501}"
        [ "$status" -eq 0 ] || return 1
    done
}

@test "interactive terminal contract: menu restore, update notice wrapper and signals (PTY)" {
	command -v python3 >/dev/null 2>&1 || skip "python3 not available"
	run python3 "$PROJECT_ROOT/tests/main_menu_pty.py"
	[ "$status" -eq 0 ] || { echo "$output"; return 1; }
}
