#!/usr/bin/env bats

load helpers/common

setup_file() {
    mole_test_setup_home installers-home

    if command -v zip > /dev/null 2>&1; then
        export ZIP_AVAILABLE=1
    else
        export ZIP_AVAILABLE=0
    fi
    if command -v zipinfo > /dev/null 2>&1 || command -v unzip > /dev/null 2>&1; then
        export ZIP_LIST_AVAILABLE=1
    else
        export ZIP_LIST_AVAILABLE=0
    fi
    if command -v unzip > /dev/null 2>&1; then
        export UNZIP_AVAILABLE=1
    else
        export UNZIP_AVAILABLE=0
    fi
}

teardown_file() {
    mole_test_teardown_home
}

setup() {
    # Safety: refuse to operate on a real home directory.
    if [[ "$HOME" != "${BATS_TEST_DIRNAME}/tmp-"* ]]; then
        printf 'FATAL: HOME is not a test temp dir: %s\n' "$HOME" >&2
        return 1
    fi
    export TERM="xterm-256color"
    export MO_DEBUG=0

    # Create standard scan directories
    mkdir -p "$HOME/Downloads"
    mkdir -p "$HOME/Desktop"
    mkdir -p "$HOME/Documents"
    mkdir -p "$HOME/Public"
    mkdir -p "$HOME/Library/Downloads"

    # Clear previous test files
    rm -rf "${HOME:?}/Downloads"/*
    rm -rf "${HOME:?}/Desktop"/*
    rm -rf "${HOME:?}/Documents"/*
}

zip_list_available() {
    [[ "${ZIP_LIST_AVAILABLE:-0}" -eq 1 ]]
}

require_zip_list() {
    zip_list_available
}

require_zip_support() {
    [[ "${ZIP_AVAILABLE:-0}" -eq 1 && "${ZIP_LIST_AVAILABLE:-0}" -eq 1 ]]
}

require_unzip_support() {
    [[ "${ZIP_AVAILABLE:-0}" -eq 1 && "${UNZIP_AVAILABLE:-0}" -eq 1 ]]
}

# Test ZIP installer detection

@test "is_installer_zip: detects ZIP with installer content even with many entries" {
    if ! require_zip_support; then
        return 0
    fi

    # Create a ZIP with many files (more than old MAX_ZIP_ENTRIES=5)
    # Include a .app file to have installer content
    mkdir -p "$HOME/Downloads/large-app"
    touch "$HOME/Downloads/large-app/MyApp.app"
    for i in {1..9}; do
        touch "$HOME/Downloads/large-app/file$i.txt"
    done
    (cd "$HOME/Downloads" && zip -q -r large-installer.zip large-app)

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        if is_installer_zip "'"$HOME/Downloads/large-installer.zip"'"; then
            echo "INSTALLER"
        else
            echo "NOT_INSTALLER"
        fi
    ' bash "$PROJECT_ROOT/bin/installer.sh"

    [ "$status" -eq 0 ]
    [[ "$output" == "INSTALLER" ]]
}

@test "is_installer_zip: detects ZIP with app content" {
    if ! require_zip_support; then
        return 0
    fi

    mkdir -p "$HOME/Downloads/app-content"
    touch "$HOME/Downloads/app-content/MyApp.app"
    (cd "$HOME/Downloads" && zip -q -r app.zip app-content)

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        if is_installer_zip "'"$HOME/Downloads/app.zip"'"; then
            echo "INSTALLER"
        else
            echo "NOT_INSTALLER"
        fi
    ' bash "$PROJECT_ROOT/bin/installer.sh"

    [ "$status" -eq 0 ]
    [[ "$output" == "INSTALLER" ]]
}

@test "is_installer_zip: rejects ZIP when installer pattern appears after MAX_ZIP_ENTRIES" {
    if ! require_zip_support; then
        return 0
    fi

    # Create a ZIP where .app appears after the 50th entry
    mkdir -p "$HOME/Downloads/deep-content"
    local -a ordered_entries=()
    for i in {1..51}; do
        touch "$HOME/Downloads/deep-content/file$i.txt"
        ordered_entries+=("deep-content/file$i.txt")
    done
    # Explicit ZIP argument order avoids relying on filesystem traversal order.
    touch "$HOME/Downloads/deep-content/MyApp.app"
    ordered_entries+=("deep-content/MyApp.app")
    (cd "$HOME/Downloads" && zip -q deep.zip "${ordered_entries[@]}")

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        if is_installer_zip "'"$HOME/Downloads/deep.zip"'"; then
            echo "INSTALLER"
        else
            echo "NOT_INSTALLER"
        fi
    ' bash "$PROJECT_ROOT/bin/installer.sh"

    [ "$status" -eq 0 ]
    [[ "$output" == "NOT_INSTALLER" ]]
}

@test "is_installer_zip: detects ZIP with real app bundle structure" {
    if ! require_zip_support; then
        return 0
    fi

    # Create a realistic .app bundle structure (directory, not just a file)
    mkdir -p "$HOME/Downloads/RealApp.app/Contents/MacOS"
    mkdir -p "$HOME/Downloads/RealApp.app/Contents/Resources"
    echo "#!/bin/bash" > "$HOME/Downloads/RealApp.app/Contents/MacOS/RealApp"
    chmod +x "$HOME/Downloads/RealApp.app/Contents/MacOS/RealApp"
    cat > "$HOME/Downloads/RealApp.app/Contents/Info.plist" << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>RealApp</string>
</dict>
</plist>
EOF
    (cd "$HOME/Downloads" && zip -q -r realapp.zip RealApp.app)

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        if is_installer_zip "'"$HOME/Downloads/realapp.zip"'"; then
            echo "INSTALLER"
        else
            echo "NOT_INSTALLER"
        fi
    ' bash "$PROJECT_ROOT/bin/installer.sh"

    [ "$status" -eq 0 ]
    [[ "$output" == "INSTALLER" ]]
}

@test "is_installer_zip: rejects ZIP with only regular files" {
    if ! require_zip_support; then
        return 0
    fi

    mkdir -p "$HOME/Downloads/data"
    touch "$HOME/Downloads/data/file1.txt"
    touch "$HOME/Downloads/data/file2.pdf"
    (cd "$HOME/Downloads" && zip -q -r data.zip data)

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        if is_installer_zip "'"$HOME/Downloads/data.zip"'"; then
            echo "INSTALLER"
        else
            echo "NOT_INSTALLER"
        fi
    ' bash "$PROJECT_ROOT/bin/installer.sh"

    [ "$status" -eq 0 ]
    [[ "$output" == "NOT_INSTALLER" ]]
}

@test "is_installer_zip: returns NOT_INSTALLER when ZIP list command is unavailable" {
    touch "$HOME/Downloads/empty.zip"

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        ZIP_LIST_CMD=()
        if is_installer_zip "$2"; then
            echo "INSTALLER"
        else
            echo "NOT_INSTALLER"
        fi
    ' bash "$PROJECT_ROOT/bin/installer.sh" "$HOME/Downloads/empty.zip"

    [ "$status" -eq 0 ]
    [[ "$output" == "NOT_INSTALLER" ]]
}

@test "is_installer_zip: works with unzip list command" {
    if ! require_unzip_support; then
        return 0
    fi

    mkdir -p "$HOME/Downloads/app-content"
    touch "$HOME/Downloads/app-content/MyApp.app"
    (cd "$HOME/Downloads" && zip -q -r app.zip app-content)

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        ZIP_LIST_CMD=(unzip -Z -1)
        if is_installer_zip "$2"; then
            echo "INSTALLER"
        else
            echo "NOT_INSTALLER"
        fi
    ' bash "$PROJECT_ROOT/bin/installer.sh" "$HOME/Downloads/app.zip"

    [ "$status" -eq 0 ]
    [[ "$output" == "INSTALLER" ]]
}

# Integration tests: ZIP scanning inside scan_all_installers

@test "scan_all_installers: finds installer ZIP in Downloads" {
    if ! require_zip_support; then
        return 0
    fi

    # Create a valid installer ZIP (contains .app)
    mkdir -p "$HOME/Downloads/app-content"
    touch "$HOME/Downloads/app-content/MyApp.app"
    (cd "$HOME/Downloads" && zip -q -r installer.zip app-content)

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        scan_all_installers
    ' bash "$PROJECT_ROOT/bin/installer.sh"

    [ "$status" -eq 0 ]
    [[ "$output" == *"installer.zip"* ]]
}

@test "scan_all_installers: ignores non-installer ZIP in Downloads" {
    if ! require_zip_support; then
        return 0
    fi

    # Create a non-installer ZIP (only regular files)
    mkdir -p "$HOME/Downloads/data"
    touch "$HOME/Downloads/data/file1.txt"
    touch "$HOME/Downloads/data/file2.pdf"
    (cd "$HOME/Downloads" && zip -q -r data.zip data)

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        scan_all_installers
    ' bash "$PROJECT_ROOT/bin/installer.sh"

    [ "$status" -eq 0 ]
    [[ "$output" != *"data.zip"* ]]
}

# Failure path tests for scan_installers_in_path

@test "scan_installers_in_path: skips corrupt ZIP files" {
    if ! require_zip_list; then
        return 0
    fi

    # Create a corrupt ZIP file by just writing garbage data
    echo "This is not a valid ZIP file" > "$HOME/Downloads/corrupt.zip"

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        scan_installers_in_path "$2"
    ' bash "$PROJECT_ROOT/bin/installer.sh" "$HOME/Downloads"

    # Should succeed (return 0) and silently skip the corrupt ZIP
    [ "$status" -eq 0 ]
    # Output should be empty since corrupt.zip is not a valid installer
    [[ -z "$output" ]]
}

@test "scan_installers_in_path: handles permission-denied files" {
    if ! require_zip_support; then
        return 0
    fi

    # Create a valid installer ZIP
    mkdir -p "$HOME/Downloads/app-content"
    touch "$HOME/Downloads/app-content/MyApp.app"
    (cd "$HOME/Downloads" && zip -q -r readable.zip app-content)

    # Create a readable installer ZIP alongside a permission-denied file
    mkdir -p "$HOME/Downloads/restricted-app"
    touch "$HOME/Downloads/restricted-app/App.app"
    (cd "$HOME/Downloads" && zip -q -r restricted.zip restricted-app)

    # Remove read permissions from restricted.zip
    chmod 000 "$HOME/Downloads/restricted.zip"

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        scan_installers_in_path "$2"
    ' bash "$PROJECT_ROOT/bin/installer.sh" "$HOME/Downloads"

    # Should succeed and find the readable.zip but skip restricted.zip
    [ "$status" -eq 0 ]
    [[ "$output" == *"readable.zip"* ]] || return 1
    [[ "$output" != *"restricted.zip"* ]] || return 1

    # Cleanup: restore permissions for teardown
    chmod 644 "$HOME/Downloads/restricted.zip"
}

@test "scan_installers_in_path: finds installer ZIP alongside corrupt ZIPs" {
    if ! require_zip_support; then
        return 0
    fi

    # Create a valid installer ZIP
    mkdir -p "$HOME/Downloads/app-content"
    touch "$HOME/Downloads/app-content/MyApp.app"
    (cd "$HOME/Downloads" && zip -q -r valid-installer.zip app-content)

    # Create a corrupt ZIP
    echo "garbage data" > "$HOME/Downloads/corrupt.zip"

    run /bin/bash -euo pipefail -c '
        export MOLE_TEST_MODE=1
        source "$1"
        scan_installers_in_path "$2"
    ' bash "$PROJECT_ROOT/bin/installer.sh" "$HOME/Downloads"

    # Should find the valid ZIP and silently skip the corrupt one
    [ "$status" -eq 0 ]
    [[ "$output" == *"valid-installer.zip"* ]] || return 1
    [[ "$output" != *"corrupt.zip"* ]]
}

@test "ZIP inspection consumes a complete large listing without losing an early match" {
    # shellcheck disable=SC2016 # Expanded by the fake command at execution time.
    mole_test_fake_command zipinfo 'printf "Installer.app/\n"; i=0; while [[ $i -lt 12000 ]]; do printf "ordinary-file-%s.txt\n" "$i"; i=$((i + 1)); done'
    run /bin/bash --noprofile --norc -c '
        export MOLE_TEST_MODE=1
        source "$1"
        is_installer_zip "$HOME/Downloads/large.zip"
    ' bash "$PROJECT_ROOT/bin/installer.sh"
    [ "$status" -eq 0 ]
}

@test "one stalled ZIP inspection is skipped and the rest still publish" {
    touch "$HOME/Downloads/first.dmg" "$HOME/Downloads/stalled.zip"
    # shellcheck disable=SC2016 # Expanded by the fake command at execution time.
    mole_test_fake_command fd 'printf "%s\0" "$HOME/Downloads/first.dmg" "$HOME/Downloads/stalled.zip"'
    mole_test_fake_command zipinfo 'printf "Installer.app/\n"; exec sleep 30'
    # shellcheck disable=SC2016 # The child shell evaluates this script.
    run env MOLE_TIMEOUT_SHORT_QUERY_SEC=2 /bin/bash --noprofile --norc -c '
        export MOLE_TEST_MODE=1
        source "$1"
        scan_all_installers() { scan_installers_in_path "$HOME/Downloads" "$1"; }
        rc=0
        collect_installers || rc=$?
        [[ $rc -eq 0 ]] || { echo "rc=$rc"; exit 1; }
        [[ ${#INSTALLER_PATHS[@]} -eq 1 && "${INSTALLER_PATHS[0]}" == "$HOME/Downloads/first.dmg" ]] || exit 1
        [[ -f "$HOME/Downloads/first.dmg" && -f "$HOME/Downloads/stalled.zip" ]] || exit 1
        [[ $SECONDS -lt 6 ]] || exit 1
    ' bash "$PROJECT_ROOT/bin/installer.sh"
    [ "$status" -eq 0 ]
}

@test "ZIP inspections share one cumulative budget across candidates" {
    touch "$HOME/Downloads/first.zip" "$HOME/Downloads/second.zip" "$HOME/Downloads/third.zip"
    export INSTALLER_TRACE="$BATS_TEST_TMPDIR/archive-trace"
    # shellcheck disable=SC2016 # Expanded by the fake command at execution time.
    mole_test_fake_command fd 'printf "%s\0" "$HOME/Downloads/first.zip" "$HOME/Downloads/second.zip" "$HOME/Downloads/third.zip"'
    mole_test_fake_command zipinfo 'printf "Installer.app/\n"'
    # shellcheck disable=SC2016 # The child shell evaluates this script.
    run env MOLE_TIMEOUT_DISK_VERIFY_SEC=6 MOLE_TIMEOUT_SHORT_QUERY_SEC=7 /bin/bash --noprofile --norc -c '
        export MOLE_TEST_MODE=1
        source "$1"
        # Isolate cumulative deadline arithmetic from shell startup and scheduling.
        # Unsetting SECONDS removes its automatic clock before assigning test time.
        unset SECONDS
        SECONDS=0
        run_with_timeout() {
            local duration="$1"
            shift
            if [[ "$1" == zipinfo ]]; then
                printf "%s %s\n" "$duration" "${3##*/}" >> "$INSTALLER_TRACE"
                SECONDS=$((SECONDS + 3))
            fi
            "$@"
        }
        rc=0
        scan_installers_in_path "$HOME/Downloads" > "$2" || rc=$?
        mole_rc_timeout "$rc" || exit 1
        [[ ! -s "$2" && $SECONDS -eq 6 ]] || exit 1
        [[ "$(cat "$INSTALLER_TRACE")" == "$(printf "6 first.zip\n3 second.zip")" ]] || exit 1
    ' bash "$PROJECT_ROOT/bin/installer.sh" "$BATS_TEST_TMPDIR/scan-output"
    [ "$status" -eq 0 ]
}
